
import axios from "axios";
import { ApplicationCommandType, ActivityType, AttachmentBuilder } from "discord.js";
import { CreateRow, CreateButton, CreateEmbed, InteractionHandler, CreateModal, CreateSelect } from "ease-discord-js";
import { api_auth_utils, getCanvasChartBuffer, databases, getUserHasPermissionByID, getMainTotalSales } from "#utils";

export default {
    name: "config",
    description: "Configure o sistema de autenticação",
    type: ApplicationCommandType.ChatInput,

    run: async(client, interaction) => {
        if (!getUserHasPermissionByID(interaction.user.id)){
            return interaction.reply({ content: `❌ | Você não possui permissão para usar esse comando!`, ephemeral: true})
        }

        const [ verified_members, app_info ] = await Promise.all([
            await api_auth_utils.getVerifiedUsers().catch(e => console.log(`Erro ao buscar usuários: ${e?.response?.data || e.message}`)),
            await api_auth_utils.getApplicationConfig(),
        ])

        if (!app_info) return client.easeClient.invokeInteraction("setup_application_message", interaction);
        if (!verified_members || !verified_members?.data) return interaction.followUp({content: "Erro ao buscar usuários", ephemeral: true})

        const botInfo = await axios.get(`https://discord.com/api/v10/applications/${app_info.bot_id}`, {
            headers: { Authorization: `Bot ${app_info.bot_token}` }
        }).catch(() => null);

        const type = databases.config.get("chart_type") || "line";

        const translateDateObject = {
            "Monday": "Segunda",
            "Tuesday": "Terça",
            "Wednesday": "Quarta",
            "Thursday": "Quinta",
            "Sunday": "Domingo",
            "Saturday": "Sábado",
            "Friday": "Sexta"
        }

        const labels = [];
        const values = [];

        verified_members.usersByDay.map((day) => {
            const dayName = Object.keys(day)[0]
            const translatedDayName = translateDateObject[dayName] || dayName;

            labels.push(`${translatedDayName}(${day[dayName].dayNumber})`)
            values.push(day[dayName].verifiedCount)
        })

        const canvasChartBuffer = getCanvasChartBuffer({ labels: labels.reverse(), values: values.reverse(), type, width: 440, height: 250, beginAtZero: false});
        const attachment = new AttachmentBuilder(canvasChartBuffer, {name: "chart.png"});
        const sales = getMainTotalSales();

        const messagesArray = [
            `# Auth System`,
            `- Olá, Bem vindo a configuração do sistema de autenticação\n`,
            `> Usuarios Verificados: \`${verified_members.totalUsersCount} Usuarios\``,
            `> Saldo Atual: \`${sales.balance.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\``,
        ]

        if (!botInfo) messagesArray.push(`- ❌ Token Inválido\n - Parece que o Token do seu bot está inválido, para corrigir esse problema  acesse o [Discord Developers](https://discord.com/developers/applications/${app_info.bot_id}/bot), gere outro token e adicione ele no botão 'configurar credenciais'`)

        const components = [
            new CreateRow([
                new CreateButton({ label: "Sistema de Vendas", customId: "config_sales", emoji: "1237511066955546688"}),
                new CreateButton({ label: "Sistema de Autenticação", customId: "config_servers", emoji: "1237510942086926400"}),
                new CreateButton({ label: "Atualizar Painel", customId: "back_to_config", emoji: "1237511023389315123"})
            ]),
            new CreateRow([
                new CreateButton({ label: "Puxar Membros", customId: "pull_users", style: "2", emoji: "1237510953311146044"}),
                new CreateButton({ label: "Consultar Usuário", customId: "send_email", style: "2", emoji: "1237511034722320424" }),
                new CreateButton({ label: "Configurações", customId: "config_bot_panel", style: "2", emoji: "1237510877238919231"}),
            ])
        ]

        if (!interaction.message){
            return interaction.reply({ content: messagesArray.join("\n"), embeds: [], components, files: [attachment], ephemeral: true});
        }

        if (interaction.deferred || interaction.replied){
            interaction.editReply({ content: messagesArray.join("\n"), embeds: [], components, files: [attachment], ephemeral: true});
        }else{
            interaction.update({ content: messagesArray.join("\n"), embeds: [], components, files: [attachment], ephemeral: true});
        }
    }
}

new InteractionHandler({
    customId: "config_bot_panel",

    run: async (client, interaction) => {
        const messages = [
            `# Configurações do BOT`,
            `- Aqui você deve alterar as configurações do seu BOT`
        ];

        const config_bot_select = CreateSelect.StringSelectMenuBuilder({
            placeholder: "Configurar presença",
            customId: "config_bot",
            options: [
                { label: "Alterar nome", value: "change_name", emoji: "📝", description: "Altere como o nome do bot deve ser exibido" },
                { label: "Alterar avatar", value: "change_avatar", emoji: "🖼️", description: "Altere a imagem do avatar do bot" },
                { label: "Alterar rich presence", value: "change_rich_presence", emoji: "🎮", description: "Altere o rich presence do bot" },
                { label: "Configurar estilo do grafio", value: "change_chart_style", emoji: "📊", description: "Altere o estilo do gráfico" },    
            ]
        })

        const components = [
            new CreateRow([config_bot_select]),
            new CreateRow([
                new CreateButton({ label: "Credenciais", customId: "setup_application", emoji: "1237510877238919231" }),
                new CreateButton({ label: "Permissões", customId: "config_perms", emoji: "1237510898722017290"}),
                new CreateButton({ label: "Voltar", customId: "back_to_config", emoji: "1237510920003911791"})
            ])
        ]

        if (interaction.replied || interaction.deferred){
            interaction.editReply({content: messages.join("\n"), embeds: [], components, files: []})
        }else{
            interaction.update({content: messages.join("\n"), embeds: [], components, files: []})
        }
    }
})

new InteractionHandler({
    customId: "setup_application_message",
    run: async (client, interaction) => {
        const messages = [
            `> - Olá, parece que você não configurou seu bot ainda, segue abaixo um passo a passo de como fazer isso\n`,
            `> - **Sugerimos fortemente** que você **não use as mesmas credenciais desse bot (<@${client.user.id}>)** para essa auth que você está criando, para segurança da sua Auth crie outro BOT em uma conta que você não usa.\n`,
            `> - Seus Auth ficarão vinculados a esse bot com as credenciais que você irá passar, caso a conta ou o bot que você criou seja banido, você perderá suas auth também.\n`,
            `> - O Token do bot e o client secret são informações sensíveis, não compartilhe com ninguém.\n`,
            `## **Como configurar:**`,
            `- **1º - ** Crie um bot no [Discord Developer Portal](https://discord.com/developers/applications)\n`,
            `- **2º - ** Na aba "Bot" clique em "Reset Token" (um botão azul), com isso ele gerará um codigo token para você, copie esse codigo, você irá usa-lo em breve.\n`,
            `- **3º - ** Na aba "OAuth2" clique em "Reset Secret", esse botão gerará um codigo que você irá usar em breve, copie ele também.\n`,
            `- **4º - ** Agora clique no botão abaixo para configurar o bot no servidor e **cole o Token e o Client Secret** que foram copiados no passo 2 e 3\nㅤ`, 
        ]

        const embed = new CreateEmbed({
            title: "Configuração do servidor",
            description: messages.join("\n"),
            timestamp: true,
            footer: { text: "Auth System"},
        })

        const components = [
            new CreateRow([
                new CreateButton({ label: "Configurar servidor", customId: "setup_application", emoji: "🛠️" }),
            ])
        ]

        return interaction.reply({ embeds: [embed], components, ephemeral: true });
    }
})

new InteractionHandler({
    customId: "setup_application",

    run: async (client, interaction) => {
        const existConfig = await api_auth_utils.getApplicationConfig();

        const modal = new CreateModal({
            title: "Configuração do servidor",
            description: "Cole o Token e o Client Secret do bot que você criou no Discord Developer Portal",
            customId: "on_modal_submit:setup_application",
            inputs: [
                { type: "text", customId: "new_value0", label: "Digite o Token", placeholder: "Token do bot", style: 1 },
                { type: "text", customId: "new_value1", label: "Digite o Client Secret", placeholder: "Client Secret do bot", style: 1 },
            ]
        })

        existConfig?.bot_token ? modal.modal.components[0].components[0].data.value = existConfig.bot_token : null;
        existConfig?.client_secret ? modal.modal.components[1].components[0].data.value = existConfig.client_secret : null;

        return await modal.show(interaction).catch(async () => await interaction.update({content: ""}));
    }
})

new InteractionHandler({
    customId: "config_bot",

    run: async (client, interaction) => {
        const option = interaction.values[0];

        if (option === "change_name"){
            const modal = new CreateModal({
                title: "Alterar nome",
                description: "Digite o novo nome do bot",
                customId: "on_modal_submit:change_name",
                inputs: [{ type: "text", customId: "new_value0", label: "Digite o novo nome", placeholder: "Melhor Auth", style: 1 }]
            })
            
            return await modal.show(interaction).catch(async () => await interaction.update({content: ""}));
        };

        if (option === "change_avatar"){
            const modal = new CreateModal({
                title: "Alterar avatar",
                description: "Digite o link da imagem do avatar",
                customId: "on_modal_submit:change_avatar",
                inputs: [{ type: "text", customId: "new_value0", label: "Digite o link da imagem", placeholder: "https://example.com/avatar.png", style: 1 }]
            })
            
            return await modal.show(interaction).catch(async () => await interaction.update({content: ""}));
        }

        if (option === "change_rich_presence"){
            const modal = new CreateModal({
                title: "Alterar rich presence",
                description: "Digite o novo rich presence",
                customId: "on_modal_submit:change_rich_presence",
                inputs: [{ type: "text", customId: "new_value0", label: "Digite o novo rich presence", placeholder: "Jogando Minecraft", style: 1 }]
            })
            
            return await modal.show(interaction).catch(async () => await interaction.update({content: ""}));
        }

        if (option === "change_site"){
            const modal = new CreateModal({
                title: "Alterar site",
                description: "Digite o novo site",
                customId: "on_modal_submit:change_site",
                inputs: [{ type: "text", customId: "new_value0", label: "Digite o novo site", placeholder: "https://example.com", style: 1 }]
            })
            
            return await modal.show(interaction).catch(async () => await interaction.update({content: ""}));
        }

        if (option === "change_chart_style"){
            const modal = new CreateModal({
                title: "Alterar estilo do gráfico",
                description: "Digite o novo estilo do gráfico",
                customId: "on_modal_submit:change_chart_style",
                inputs: [{ type: "text", customId: "new_value0", label: "Digite o novo estilo do gráfico", placeholder: "Opções: linha, barra, circulo, pizza", style: 1 }]
            })
            
            return await modal.show(interaction).catch(async () => await interaction.update({content: ""}));
        }
    }
})

new InteractionHandler({
    customId: "on_modal_submit",
    useParams: true,

    run: async (client, interaction, changed_item) => {
        await interaction.deferUpdate();
        const new_value0 = interaction.fields.getTextInputValue("new_value0");
        
        if (changed_item === "change_name"){
            try {
                await client.user.setUsername(new_value0);
                await client.easeClient.invokeCommand('config', interaction);
            }catch{
                return interaction.editReply({ content: "❌ | Erro ao alterar o nome do bot. tente novamente mais tarde!" });
            }
        }

        if (changed_item === "change_avatar"){
            try {
                await client.user.setAvatar(new_value0);
                await client.easeClient.invokeCommand('config', interaction);
            }catch{
                return interaction.editReply({ content: "❌ | Erro ao alterar o avatar, tente novamente mais tarde!" });
            }
        }

        if (changed_item === "change_rich_presence"){
            try {
                await client.user.setActivity(new_value0, { type: ActivityType.Playing })
                await databases.config.set("rich_presence", new_value0);

                await client.easeClient.invokeCommand('config', interaction);
            }catch(error){
                return interaction.editReply({ content: "❌ | Erro ao alterar o rich presence, tente novamente mais tarde!" });
            }
        }

        if (changed_item === "change_site"){
            try {
                await client.easeClient.invokeCommand('config', interaction);
            }catch{
                return interaction.editReply({ content: "❌ | Erro ao alterar o site, tente novamente mais tarde!" });
            }
        }

        if (changed_item === "change_chart_style") {
            try {
                const valid_types = {
                    "linha": "line",
                    "barra": "bar",
                    "pizza": "pie",
                    "circulo": "doughnut"
                };
                
                if (!Object.keys(valid_types).includes(new_value0)) 
                    return interaction.editReply({ content: "❌ | Tipo de gráfico inválido, tente novamente!" });

                
                await databases.config.set("chart_type", valid_types[new_value0]);
                await client.easeClient.invokeCommand('config', interaction);
            } catch (error) {
                return interaction.editReply({ content: "❌ | Erro ao alterar o estilo do gráfico, tente novamente mais tarde!" });
            }
        };

        if (changed_item === "setup_application") {
            try {
                const new_value0 = interaction.fields.getTextInputValue("new_value0");
                const new_value1 = interaction.fields.getTextInputValue("new_value1");

                if (!new_value0 || !new_value1){
                    return interaction.followUp({ content: "❌ | Informe o Token e o Client Secret corretamente!", ephemeral: true });
                }

                const botInfo = await axios.get(`https://discord.com/api/v10/applications/@me`, {  
                    headers: { Authorization: `Bot ${new_value0}` }
                }).catch(() => null);

                if (!botInfo || !botInfo?.data?.id){
                    return interaction.followUp({ content: "❌ | Token inválido, tente novamente!", ephemeral: true });
                }

                const existConfig = await api_auth_utils.getApplicationConfig();
                if (existConfig){
                    if (existConfig.bot_id !== botInfo.data.id){
                        return confirmUpdateConfig(interaction, botInfo.data.id, existConfig.bot_id, new_value0, new_value1);
                    }
                }

                await api_auth_utils.updateApplicationConfig({ bot_token: new_value0, client_secret: new_value1, bot_id: botInfo.data.id});    
                await client.easeClient.invokeCommand('config', interaction);
                await interaction.followUp({ content: "✅ | Configuração realizada com sucesso!", ephemeral: true });
            }catch(e){
                return interaction.followUp({ content: "❌ | Erro ao configurar o servidor, tente novamente mais tarde!", ephemeral: true });
            }
        }
    }
})

new InteractionHandler({
    customId: "back_to_config",
    run: async (client, interaction) => {
        client.easeClient.invokeCommand("config", interaction);
    }
})

async function confirmUpdateConfig(interaction, bot_id, old_id, bot_token, client_secret){
    if (!interaction.deferred && !interaction.replied)
        await interaction.deferReply({ephemeral: true});

    const embed = new CreateEmbed({
        title: "Confirmação",
        description: "Parece que você está tentando alterar as credenciais para um bot diferente do qual você estava usando, deseja continuar? Caso sim, todas seus membros verificados com o outro bot serão perdidos.",
    })

    const components = [
        new CreateRow([
            new CreateButton({ label: "Sim", style: 3, emoji: "✅", onClick: async (client, interaction) => {
                try {
                    await api_auth_utils.updateApplicationConfig({ bot_token, client_secret, bot_id });
                    await api_auth_utils.deleteUsers({ bot_id: old_id }) // Deletando usuarios autenticado com o BOT antigo!!
                    client.easeClient.invokeInteraction("back_to_config", interaction);
                }catch(e){
                    await interaction.reply({content: `❌ | Erro ao trocar as credenciais: ${e.message}`})
                }
            } }),
            new CreateButton({ label: "Não", customId: "back_to_config", style: 4, emoji: "❌" }),
        ])
    ]

    return interaction.editReply({ embeds: [embed], components, files: [] });
}