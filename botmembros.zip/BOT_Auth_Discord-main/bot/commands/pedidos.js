
import axios from "axios";
import { ApplicationCommandType, ActivityType, AttachmentBuilder } from "discord.js";
import { CreateRow, CreateButton, CreateEmbed, InteractionHandler, CreateModal, CreateSelect } from "ease-discord-js";
import { api_auth_utils, getCanvasChartBuffer, databases, getUserHasPermissionByID } from "#utils";

export default {
    name: "pedidos",
    description: "Acompanhe o andamento dos seus pedidos",
    type: ApplicationCommandType.ChatInput,

    run: async(client, interaction) => {
        await client.easeClient.invokeInteraction("queue-orders", interaction)
    }
}

new InteractionHandler({
    customId: "queue-orders",
    useParams: true, 

    run: async (client, interaction, _currentPage = 1) => {
        const carts_server = databases.carts.fetch(`servers.${interaction.guild.id}`) || {};
        const user_queues = databases.users_queue.fetch(`${interaction.guild.id}.${interaction.user.id}`) || [];

        if (user_queues.length === 0){
            return interaction.reply({ content: `\`❌\`・Você não possui membros comprados aqui!`, ephemeral: true})
        }

        const queue_api_info = await api_auth_utils.getQueuePulls();
        const queue_api_list = queue_api_info?.data || [];

        let totalSpent = 0;
        let totalMembers = 0;

        Object.keys(carts_server).map( cart_id => {
            const cart = carts_server[cart_id];

            if (cart.user.id === interaction.user.id){
                if (cart?.payment?.status === "approved" || cart?.payment?.status === "approved-by-admin"){
                    totalSpent += cart?.payment?.price || 0;
                    totalMembers += parseFloat(cart?.quantityMembers) || 0; 
                }
            }
        })

        const contents = [
            `# Seus pedidos`,
            `- Aqui você pode acompanhar seus pedidos, pedir refil e obter o historico de compras nesse servidor.\n`,
            `- **Suas estatisticas:**`,
            ` - Total gasto no servidor: \`${totalSpent.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\``,
            ` - Total de membros comprados: \`${totalMembers}\`\n`,
            `- **Status do seu pedido**`,
            ` - \`(🟢) Pedido Concluido\``,
            ` - \`(🔵) Pedido em Processamento\``,
            ` - \`(🟡) Refil disponível\``,
            ` - \`(🟠) Pedido pendente\``,
            ` - \`(🔴) Finalizado com erro\``,
        ]

        const currentPage = Number(_currentPage);
        const maxOptionsPerPage = 24;
        const totalPages = Math.ceil(user_queues.length / maxOptionsPerPage);

        const options = [];

        user_queues.map((queue) => {
            const queue_api = queue_api_list.find( x => x.id === queue.id );
            let emoji = "❓";

            if (queue_api?.status === "finished"){
                if (queue.canUseRefil){
                    emoji = "🟡";
                }else{
                    emoji = "🟢";
                }   
            }else if (queue_api?.status === "pending"){
                emoji = "🟠";
            }else if (queue_api?.status === "processing"){
                emoji = "🔵";
            }else if (queue_api?.status === "error"){
                emoji = "🔴";
            }

            const label = `Destino: ${queue.to_name || queue.to} ${queue.isRefil ? "(REFIL)" : ""}`
            const description = `Quantidade: ${queue.quantity} Membros - Fila ${queue.id}`

            options.push({ emoji: emoji, label, description, value: `${queue.id}` })
        })

        const users_queue_in_page = options.slice((currentPage - 1) * maxOptionsPerPage, currentPage * maxOptionsPerPage);

        const components = [
            new CreateRow([
                CreateSelect.StringSelectMenuBuilder({customId: "on-select-queue-order", placeholder: "Selecione o pedido", options: users_queue_in_page || [{label: "N/A", value: "N/A"}]}),
            ]),
            new CreateRow([
                new CreateButton({ label: " ", emoji: "⬅️", customId: `queue-orders:${currentPage - 1}`, disabled: currentPage === 1}),
                new CreateButton({ label: `Pagina ${currentPage}/${totalPages}`, style: "Secondary", customId: "234234234", disabled: true }),
                new CreateButton({ label: " ", emoji: "➡️", customId: `queue-orders:${currentPage + 1}`, disabled: currentPage === totalPages}),
                new CreateButton({ label: "Atualizar Painel", customId: `queue-orders:${currentPage}`, emoji: "1237511023389315123"})
            ]),
        ]

        if (!interaction.message){
            return interaction.reply({content: contents.join("\n"), components, ephemeral: true})
        }

        if (interaction.deferred || interaction.replied){
            interaction.editReply({content: contents.join("\n"), components, ephemeral: true})
        }else{
            interaction.update({content: contents.join("\n"), components, ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "on-select-queue-order",

    run: async (client, interaction) => {
        const orders_db = databases.users_queue.fetch(`${interaction.guild.id}.${interaction.user.id}`)

        const queue_id = interaction?.values[0];
        const order_info = orders_db.find(x => String(x.id) === queue_id);

        try {
            const queue_info_api_fetch = await api_auth_utils.getQueuePulls({ id: queue_id });
            const queue_info_api = queue_info_api_fetch?.data[0];

            if (!queue_info_api) throw new Error("Essa fila não foi encontrada no banco de dados da API.");

            const statusDictionary = {
                "finished": "🟢 Finalizado com sucesso",
                "processing": "🔵 Enviando os membros",
                "pending": "🟠 Aguardando chegar a vez",
                "error": "🔴 Finalizado com erro",
            }

            const contents = [
                `# Fila do servidor ${order_info.to_name || order_info.to}`,
                `- ID do Carrinho: \`${order_info.cart_id}\``,
                `- Servidor de Destino: \`${order_info.to}\``,
                `- Membros durante a criação: \`${order_info.membersWhenCreating}\``,
                `- Membros Adquiridos: \`${order_info.quantity}\`\n`,
                `- ID da Fila: \`${order_info.id}\``,
                `- Status da Entrega: \`${statusDictionary[queue_info_api.status]}\``,
                queue_info_api.reason_closure ? `- Razão do fechamento: \`${queue_info_api.reason_closure || ""}\`` : null,
                `- Andamento: \`${queue_info_api.quantity_pulled}/${queue_info_api.quantity_total}\``,
            ]

            // Caso o pedido tenha sido acabado (com erro ou não) e ele tenha comprado o refil, vamos liberar o botão pra ele
            const canUseRefil = order_info.canUseRefil && (queue_info_api.status === "finished" || queue_info_api.status === "error");

            const components = [
                new CreateRow([
                    new CreateButton({ label: "Solicitar Refil", customId: `refil`, emoji: "1237510953311146044", disabled: !canUseRefil}),
                    new CreateButton({ label: "Atualizar fila", customId: `update-select-queue-order:${queue_id}`, emoji: "1237511023389315123"}),
                    new CreateButton({ label: "Voltar", style: "2", customId: "queue-orders", emoji: "1237510920003911791"}),
                ])
            ]

            return interaction.update({ content: contents.filter( c => c !== null ).join("\n"), components })

        }catch(e){
            return interaction.reply({ content:  `\`❌\`・${e.message}`, ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "update-select-queue-order",
    useParams: true, 

    run: async (client, interaction, queue_id) => {
        interaction.values = [queue_id];
        client.easeClient.invokeInteraction("on-select-queue-order", interaction)
    }
})