
import defaultConfig from "#root/defaultConfig.json" with { type: "json" }
import { ApplicationCommandType } from "discord.js";
import { CreateRow, CreateButton, InteractionHandler, CreateSelect, CreateModal, CreateEmbed } from "ease-discord-js";
import { databases, getTotalSalesByServer, getUserHasPermissionByID } from "#utils";

const formatter = new Intl.NumberFormat('pt-BR', {style: 'currency', currency: 'BRL'});

export default {
    name: "configloja",
    description: "Configure o sistema de revenda",
    type: ApplicationCommandType.ChatInput,

    run: async(client, interaction) => {

        const resellers = databases.sales_config.fetch(`servers.${interaction.guild.id}.resellers`) || [];
        if (!resellers.includes(interaction.user.id)){
            return interaction.reply({ content: "❌ | Você não é revendedor dessa loja", ephemeral: true })
        }

        const configured_servers = databases.sales_config.fetch("servers") || {};
        if (!configured_servers[interaction.guild.id]) return interaction.reply({ content: "❌ | Esse servidor não foi configurado", ephemeral: true })

        const guild_config = configured_servers[interaction.guild.id];

        const messages = [
            `# Configurações da loja`,
            `- Aqui você poderá configurar a embed e outras opções relacionada a venda de membros no servidor \`${interaction.guild.name}\`\n`,
            `- Configurações atuais:`,
            ` - Vendas: ${guild_config.sales_on ? "`Ativa`" : "`Desativado`"}`,
            ` - Sistema de Refil: ${guild_config.refil_on ? "`Ativo`" : "`Desativado`"}`,
            ` - Pedido minimo: \`${guild_config.minimum_order} Membros\``,
            ` - Cargo de cliente: \`${guild_config.clientRole || "Não configurado"}\``,
            ` - Cargo da equipe: \`${guild_config.teamRole || "Não configurado"}\``,
            ` - Porcentagem máxima por pedido: \`${guild_config.max_order_porcent}%\``,
            ` - Preço por membro: \`${guild_config.price_per_member.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL', maximumSignificantDigits: 3})}\``,
            ` - Preço por membro (com refil): \`${parseFloat(guild_config.price_per_member_refil).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL', maximumSignificantDigits: 3})}\``,
        ]

        if (!guild_config.webhook){
            messages.push(`\n\`⚠️\` **Webhook não foi configurado, sem ele você não receberá notificação das suas vendas!**`)
        }

        const selectComponent = CreateSelect.StringSelectMenuBuilder({
            customId: `sales_config_server_select:${interaction.guild.id}`,
            placeholder: `Selecione alguma configuração`,
            options: [
                { label: "Status", description: `Clique para ${guild_config.sales_on ? "Desativar" : "Ativar"} as vendas nesse servidor`, emoji: guild_config.sales_on ? "🟢":"🔴", value: "sales_on"},
                { label: "Webhook", description: `Receba as Logs de pagamento realizada no seu servidor`, emoji: "1237510909291663490", value: "webhook"},
                { label: "Pedido minimo", description: `Altere o valor minimo que o cliente pode comprar`, emoji: "🤏🏼", value: "minimum_order"},
                { label: "Cargo de cliente", description: `Altere o cargo da cliente do seu servido`, emoji: "👩‍👧‍👦", value: "clientRole"},
                { label: "Cargo da equipe", description: `Altere o cargo de equipe do seu servidor`, emoji: "👔", value: "teamRole"},
                { label: "Configurar embed", description: "Configure como será o anuncio de venda dos membros", emoji: "📝", value: "embed"},
                { label: "Preço por membro", description: "Defina por qual valor você vai vender cada membro", emoji: "💵", value: "price_per_member"},
            ]
        })

        const components = [
            new CreateRow(selectComponent),
            new CreateRow([
                new CreateButton({ label: "Solicitar Saque", customId: `request_withdrawal`, emoji: "1257069259746709654"}),
                new CreateButton({ label: "Estatisticas", customId: `statistics:${interaction.guild.id}`, emoji: "1256804128311738380"}),
            ]),
        ]

        if (!interaction.message){
            return interaction.reply({ content: messages.join("\n"), embeds: [], components, files: [], ephemeral: true});
        }

        if (interaction.deferred || interaction.replied){
            interaction.editReply({ content: messages.join("\n"), embeds: [], components, files: [], ephemeral: true});
        }else{
            interaction.update({ content: messages.join("\n"), embeds: [], components, files: [], ephemeral: true});
        }
    }
}

new InteractionHandler({
    customId: "request_withdrawal",

    run: async (client, interaction) => {
        const guildSettings = databases.sales_config.fetch(`servers.${interaction.guild.id}`) || {};
        const resaleConfig = databases.sales_config.fetch(`resale_config`);
        const { balance } = getTotalSalesByServer(interaction.guild.id);

        const minAmountToWithdrawal = resaleConfig?.withdraw_settings?.withdraw_min_value || defaultConfig.withdraw_min_value;
        if (parseFloat(balance) <= 0){
            return interaction.reply({ content: `\`❌\` - Você não possui saldo algum para sacar. O Saldo minimo é de ${formatter.format(minAmountToWithdrawal)}`, ephemeral: true})
        }

        if (parseFloat(balance) < parseFloat(minAmountToWithdrawal)){
            return interaction.reply({ content: `\`❌\` - O Valor minimo para poder sacar é de ${formatter.format(minAmountToWithdrawal)}. Você possui: ${formatter.format(balance)}`, ephemeral: true})
        }

        if (!resaleConfig?.withdraw_notification_data){
            return interaction.reply({content: `\`❌\` - O Propietario do BOT ainda não configurou o canal de notificação de saque. peça pra ele configurar antes!`, ephemeral: true});
        }

        const guild = client.guilds.cache.get(resaleConfig.withdraw_notification_data?.guild);
        if (!guild){
            return interaction.reply({content: `\`❌\` - O BOT não está no servidor onde ele envia a log de notificação de saque. Informe o proprietario!`, ephemeral: true});
        }

        const channel = guild.channels.cache.get(resaleConfig.withdraw_notification_data?.channel)
        if (!channel){
            return interaction.reply({content: `\`❌\` - O Canal onde o BOT deveria enviar a mensagem de solicitação de saque não existe mais. Informe o proprietario do BOT para configurar novamente a notificação de saque!`, ephemeral: true});
        }

        const withdraw_settings = databases.sales_config.fetch(`resale_config.withdraw_settings`) || { 
            withdraw_days: defaultConfig.withdraw_days,
            withdraw_hours: defaultConfig.withdraw_hours,
            withdraw_minutes: defaultConfig.withdraw_minutes,
            withdraw_min_value: defaultConfig.withdraw_min_value,
        }

        if (guildSettings.lastWithdrawDate) {
            const now = new Date();
            const lastWithdrawDate = new Date(guildSettings.lastWithdrawDate);

            const withdrawInterval = new Date(
                lastWithdrawDate.getFullYear(),
                lastWithdrawDate.getMonth(),
                lastWithdrawDate.getDate() + parseFloat(withdraw_settings.withdraw_days),
                lastWithdrawDate.getHours() + parseFloat(withdraw_settings.withdraw_hours),
                lastWithdrawDate.getMinutes() + parseFloat(withdraw_settings.withdraw_minutes)
            );

            if (now < withdrawInterval) {
                const remainingTime = withdrawInterval - now;
                const remainingDays = Math.floor(remainingTime / (1000 * 60 * 60 * 24));
                const remainingHours = Math.floor((remainingTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const remainingMinutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));

                return interaction.reply({content: `\`❌\` - Você ainda não pode sacar. Por favor, aguarde ${remainingDays} dias, ${remainingHours} horas e ${remainingMinutes} minutos.`, ephemeral: true});
            }
        }


        const modal = new CreateModal({
            title: "Solicitando Saque",
            customId: "on-submit-request-withdrawal",
            inputs: [
                {type: "text", label: "Qual sua Chave PIX ?", customId: "pix-key", style: "Short", require: true},
            ],
        })

        guildSettings.resellerPix ? modal.modal.components[0].components[0].data.value = String( guildSettings.resellerPix ) : null
        return await modal.show(interaction)
    }
})

new InteractionHandler({
    customId: "on-submit-request-withdrawal",

    run: async (client, interaction) => {
        const guildConfig = databases.sales_config.fetch(`servers.${interaction.guild.id}`);
        const resaleConfig = databases.sales_config.fetch(`resale_config`);

        if (!resaleConfig?.withdraw_notification_data){
            return interaction.reply({content: `\`❌\` - O Propietario do BOT ainda não configurou o canal de notificação de saque. peça pra ele configurar antes!`, ephemeral: true});
        }

        const guild = client.guilds.cache.get(resaleConfig.withdraw_notification_data?.guild);
        if (!guild){
            return interaction.reply({content: `\`❌\` - O BOT não está no servidor onde ele envia a log de notificação de saque. Informe o proprietario!`, ephemeral: true});
        }

        const channel = guild.channels.cache.get(resaleConfig.withdraw_notification_data?.channel)
        if (!channel){
            return interaction.reply({content: `\`❌\` - O Canal onde o BOT deveria enviar a mensagem de solicitação de saque não existe mais. Informe o proprietario do BOT para configurar novamente a notificação de saque!`, ephemeral: true});
        }

        const pix_key = interaction.fields.getTextInputValue("pix-key");
        let resellers = "";

        guildConfig?.resellers.map((reseler_id) => {
            return resellers += `<@${reseler_id}> ${String(reseler_id) === String(interaction.user.id) ? "(Solicitante)" : ""}`;
        })

        const description = [
            `**Servidor:** ${interaction.guild.name} (${interaction.guild.id})`,
            `**Revendedores:** ${resellers}\n`,
            `**Chave PIX:** ${pix_key}`,
        ]

        const embed = new CreateEmbed({
            title: "Nova solicitação de saque!",
            description: description.join("\n"),
            timestamp: true,
            color: "#eb9b10"
        })

        const components = [
            new CreateRow([
                new CreateButton({ label: "Pagar", customId: `pay-resellers-guild:${interaction.guild.id}`, style: 2, emoji: "1256797528129667112"})
            ])
        ]

        await channel.send({ embeds: [embed], components })

        databases.sales_config.set(`servers.${interaction.guild.id}.resellerPix`, pix_key)
        databases.sales_config.set(`servers.${interaction.guild.id}.lastWithdrawDate`, new Date())

        return interaction.reply({content: `\`✅\` - Saque solicitado com sucesso! Deixe sua DM aberta para receber uma notificação quando seu dinheiro for transferido`, ephemeral: true});
    }
})

new InteractionHandler({
    customId: "pay-resellers-guild",
    useParams: true,

    run: async (client, interaction, guild_id_to_paid) => {
        if (!getUserHasPermissionByID(interaction.user.id)){
            return interaction.reply({ content: "`❌` - Você não possui permissão para realizar pagamentos.", ephemeral: true})
        }

        const { balance } = getTotalSalesByServer(guild_id_to_paid);
        const modal = new CreateModal({
            title: "Pagando revendedores",
            customId: `on-submit-pay-resellers-guild:${guild_id_to_paid}`,
            inputs: [
                {type: "text", label: "Qual valor pago", customId: "payment-amount", style: "Short"},
            ],
        })

        balance ? modal.modal.components[0].components[0].data.value = String( balance.toFixed(2) ) : null

        return await modal.show(interaction)
    }
})

new InteractionHandler({
    customId: "on-submit-pay-resellers-guild",
    useParams: true, 

    run: async (client, interaction, guild_id_to_paid) => {
        let payment_amount = interaction.fields.getTextInputValue("payment-amount");
        payment_amount = payment_amount?.replace(",", ".") || undefined;

        if (!payment_amount) {
            return interaction.reply({ content: `\`❌\` O Valor do pagamento não é válido!`, ephemeral: true })
        }

        if (isNaN(payment_amount)) {
            return interaction.reply({ content: `\`❌\` Utilize apenas números no valor pago!`, ephemeral: true })
        }

        if (!guild_id_to_paid){
            return interaction.reply({ content: `\`❌\` Servidor a ser pago não recebido pela interação!`, ephemeral: true })
        }

        if (parseFloat(payment_amount) < 0){
            return interaction.reply({ content: `\`❌\` O Valor a ser pago precisa ser um número positivo ou 0`, ephemeral: true })
        }

        const previusEmbed = interaction.message.embeds[0].data;

        previusEmbed.title = "Transferencia realizada!";
        previusEmbed.description = previusEmbed.description += `\n**Valor transferido:** ${formatter.format(payment_amount)}`
        previusEmbed.color = "8907555";

        await interaction.message.edit({ embeds: [previusEmbed], components: []})

        databases.extracts.push(`extracts.${guild_id_to_paid}`, { action: "remove", amount: parseFloat(payment_amount), transaction_origin: "Pagamento realizado! Forma automatica pelo sistema de solicitar saque.", date: new Date()})
        return interaction.reply({ content: "\`✅\` - Pagamento realizado com sucesso!", ephemeral: true})
    }
})

new InteractionHandler({
    customId: "invoke-configloja-command",

    run: async (client, interaction) => {
        return client.easeClient.invokeCommand("configloja", interaction)
    }
})
