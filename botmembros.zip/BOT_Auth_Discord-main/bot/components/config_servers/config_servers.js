import { InteractionHandler, CreateRow, CreateButton, CreateEmbed, CreateSelect, CreateModal } from "ease-discord-js";
import { api_auth_utils, api_discord_utils } from "#utils";
import axios from "axios";

new InteractionHandler({
    customId: "config_servers",
    useParams: true,

    run: async (client, interaction, _currentPage = 1) => {

        let [app_info, serversAPI, bot_auth_servers] = await Promise.all([
           await api_auth_utils.getApplicationConfig().catch(e => null),
           await api_auth_utils.getAllServers().catch(e => null).then(e => e?.data),
           await api_discord_utils.getGuilds().catch(e => console.error("Erro ao buscar servidores (customId: config_servers): ", e?.response?.data || e.message))
        ])

        if (!app_info) return interaction.reply({ content: "❌ | Parece que seu BOT ainda não está configurado!", ephemeral: true });
        if (!bot_auth_servers) return interaction.reply({ content: "❌ | Erro ao buscar servidores", ephemeral: true });
        if (!serversAPI) serversAPI = [];

        const configured_servers = {};
        const bot_not_present = {};

        serversAPI.map(server => {
            configured_servers[server.server_id] = true;

            if (!bot_auth_servers.find(x => x.id === server.server_id)) {
                bot_not_present[server.server_id] = true;
                bot_auth_servers.push({ id: server.server_id, name: server.server_name })
            }
        })

        const description = [
            `# Servidores Auth`,
            `- Olá, aqui você poderá escolher qual servidores usar para autenticar seus membros.`,
            ` - Para adicionar o servidor na lista, clique em "Adicionar Bot"   `
        ]

        const currentPage = Number(_currentPage);
        const maxServersPerPage = 24;
        const total_servers = bot_auth_servers.length;
        const totalPages = Math.ceil(total_servers / maxServersPerPage);

        bot_auth_servers = bot_auth_servers.map(guild => { 
            let label = "";
            let emoji = "";

            if (configured_servers[guild.id] && !bot_not_present[guild.id]){
                label = "";
                emoji = "🟢"
            }else if(bot_not_present[guild.id] && configured_servers[guild.id]){
                label = "[BOT NÃO PRESENTE]"
                emoji = "🟠"
            }else{
                label = "[NÃO CONFIGURADO]"
                emoji = "🔴"
            }

            return { 
                label: `${label} ${guild.name}`, 
                value: guild.id, 
                description: `ID: ${guild.id}`, 
                emoji: emoji
            }
        })

        bot_auth_servers = bot_auth_servers.sort((a, b) => {
            const order = { "🟢": 1, "🟠": 2, "🔴": 3 };
            return order[a.emoji] - order[b.emoji];
        });
        
        // Separa os servidores da pagina atual
        const serversInCurrentPage = bot_auth_servers.slice((currentPage - 1) * maxServersPerPage, currentPage * maxServersPerPage);

        const select_guilds = CreateSelect.StringSelectMenuBuilder({
            customId: "on_select_config_server",
            placeholder: "Lista de servidores",
            options: serversInCurrentPage
        })

        const components = [
            new CreateRow(select_guilds),
            new CreateRow([
                new CreateButton({ label: " ", emoji: "⬅️", customId: `config_servers:${currentPage - 1}`, disabled: currentPage === 1}),
                new CreateButton({ label: `Pagina ${currentPage}/${totalPages}`, style: "Secondary", customId: "234234234", disabled: true }),
                new CreateButton({ label: " ", emoji: "➡️", customId: `config_servers:${currentPage + 1}`, disabled: currentPage === totalPages}),
                new CreateButton({ label: "Adicionar BOT", style: 5, url: `https://discord.com/oauth2/authorize?client_id=${app_info.bot_id}&permissions=8&scope=bot`, emoji: "1237510953311146044"}),
                new CreateButton({ label: "Voltar", style: "2", customId: "back_to_config", emoji: "1237510920003911791"}),
            ]),
        ]

        if (interaction.deferred || interaction.replied) {
            await interaction.editReply({ content: description.join("\n"), components: components, files: [], embeds: [], ephemeral: true });
        }else{
            await interaction.update({ content: description.join("\n"), components: components, files: [], embeds: [], ephemeral: true });
        }
    }
})

new InteractionHandler({
    customId: "on_select_config_server",
    useParams: true,

    run: async (client, interaction) => {
        const selected_server_id = interaction.values?.[0];
        if (!selected_server_id) return interaction.reply({ content: "❌ | ID Do servidor não encontrado.", ephemeral: true });

        const [server_info_discord, bot_config_discord, server_info_api] = await Promise.all([
            await api_discord_utils.getGuild(selected_server_id).catch(e => null),
            await api_discord_utils.getMe().catch(e => null),
            await api_auth_utils.getServer(selected_server_id, ["verified_role_id", "webhook_notification", "custom_domain", "bot_id"]).then(e => e?.data).catch(e => null)
        ])

        // Cuidar aaqui, se bater aqui o BOT nãao taa no servidor.
        if (!server_info_discord){
            const messages = [
                `# Algo deu errado`,
                `- Parece que o BOT não está mais presente nesse servidor, para voltar a usa-lo adicione ele no servidor e abra esse painel novamente.`
            ]

            const components = [
                new CreateRow([
                    new CreateButton({ label: "Atualizar Painel", customId: `back_to_config_server:${selected_server_id}`, emoji: "1237511023389315123"}),
                    new CreateButton({ label: "Excluir servidor", customId: `try_exclude_server:${selected_server_id}`, style: "Danger", emoji: "1237510974685319220"}),
                    new CreateButton({ label: "Voltar", customId: "config_servers", style: "Danger"})
                ])
            ]

            return interaction.update({ components, content: messages.join("\n"), embeds: [] })
        }



        if (!bot_config_discord) return interaction.reply({ content: "❌ | Bot não encontrado", ephemeral: true });
        if (!server_info_api) return await client.easeClient.invokeInteraction(`on_config_server_without_client_secret:${selected_server_id}`, interaction);

        const redirect_url = process.env.REDIRECT_URI?.replace("$custom_url", server_info_api.custom_domain)
        const exist_redirect = bot_config_discord?.redirect_uris?.includes(redirect_url);

        const messages = [
            `## Configurações de Auth`,
            `- Olá, abaixo você pode configurar a auth do seu servidor!\n`,
        ]
        if (bot_config_discord && !exist_redirect) messages.push(`- ❌ **Redirect URI Não configurado:** \n - Para corrigir, entre no [Discord Developers](<https://discord.com/developers/applications/${server_info_api.bot_id}/oauth2>) e coloque  seguinte URL: \`${redirect_url}\`\nㅤ`)
        if (!bot_config_discord) messages.push(`- Token Invalido: \n - \` ❌ - Token inválido, verifique se o token está correto \` \nㅤ`)

        const recomendations = []
        if (!server_info_api?.verified_role_id) recomendations.push(`  - Adicione um cargo para os usuarios que se autenticarem, para que os usuarios autenticados possam ser identificados`)
        if (!server_info_api?.webhook_notification) recomendations.push(`  - Adicione um webhook para receber as notificações sobre os usuarios autenticados, na dúvida crie um ticket na [AppsSystem](https://barraapps.cloud/discord)`)

        const components = [
            new CreateRow([
                CreateSelect.StringSelectMenuBuilder({
                    customId: `on_config_server:${selected_server_id}`,
                    placeholder: "Selecione uma opção",
                    options: [
                        { label: "Configurar Cargo", value: `role`, emoji: "🔒", description: "Adicione um cargo para usuarios autenticados" },
                        { label: "Configurar Embed", value: `embed`, emoji: "📄", description: "Personalize a mensagem de autenticação" },
                        { label: "Customizar Site", value: `site`, emoji: "🌐", description: "Personalize o site de autenticação" },
                        { label: "Customizar URL", value: `customize_url`, emoji: "🔗", description: "Personalize a URL do site" },
                        { label: "Alterar Webhook", value: `webhook_notification`, emoji: "📡", description: "Alterar o webhook de notificação" },
                    ],
                }),
            ]),
                    

            
            new CreateRow([
                new CreateButton({label: "Atualizar Painel", customId: `back_to_config_server:${selected_server_id}`, emoji: "1237511023389315123"}),
                new CreateButton({label: "Excluir servidor", style: "Danger", customId: `try_exclude_server:${selected_server_id}`, emoji: "1237510974685319220"}),
                new CreateButton({label: "Voltar", style: "Danger", customId: "config_servers", emoji: "1237510920003911791"}),
            ])
        ]
        
        if (interaction.deferred || interaction.replied){
            return interaction.editReply({ content: `${messages.join("\n")}\n${recomendations.length > 0 ? `- Recomendações: \n${recomendations.join("\n")}\nㅤ` : ""}`, components: components, files: [], embeds: [], ephemeral: true });
        }else{
            return interaction.update({ content: `${messages.join("\n")}\n${recomendations.length > 0 ? `- Recomendações: \n${recomendations.join("\n")}\nㅤ` : ""}`, components: components, files: [], embeds: [], ephemeral: true });
        }
    }
})

new InteractionHandler({
    customId: "initilize_config_server",
    useParams: true,

    run: async (client, interaction, server_id) => {
        if (!server_id) return interaction.reply({ content: "❌ | Algo deu errado", ephemeral: true });

        const modal = new CreateModal({
            title: "Configuração de Client Secret",
            customId: `on_config_server_submit_modal:initialize_config:${server_id}`,
            inputs: [ 
                { type: "text", label: "Webhook de Notificação", style: "Short", required: true, placeholder: "Webhook onde será enviado as informações dos autenticados", customId: "new_value0"},
                { type: "text", label: "ID Cargo de Autenticado (OPCIONAL)", style: "Short", required: false, placeholder: "Cargo recebido após se autenticar", customId: "new_value1"}
            ],
        });

        modal.modal.components[1].components[0].data.required = false
        await modal.show(interaction);
    }
})

new InteractionHandler({
    customId: "on_config_server",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const action = interaction.values?.[0];

        if (!action || !server_id) return interaction.reply({ content: "❌ | Algo deu errado", ephemeral: true });

        if (action === "customize_url") {
            const current_url = await api_auth_utils.getServer(server_id, ["custom_domain"]).then(r => r?.data?.custom_domain).catch(e => null);

            const modal = new CreateModal({
                title: "Customizar URL",
                customId: `on_config_server_submit_modal:customize_url:${server_id}`,
                inputs: [
                    { type: "text", label: "URL Personalizada", style: "Short", required: true, placeholder: `Exemplo: apps_system`, customId: "new_value0"}
                ],
            });

            current_url ? modal.modal.components[0].components[0].data.value = current_url : null;
            await modal.show(interaction)
        };

        if (action === "embed") {
            await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
        };

        if (action === "site"){ 
            await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
        }

        if (action === "role") {
            const currentRole = await api_auth_utils.getServer(server_id, ["verified_role_id"]).then(r => r?.data?.verified_role_id).catch(e => null);

            const modal = new CreateModal({
                title: "Configuração de Cargo",
                customId: `on_config_server_submit_modal:role:${server_id}`,
                inputs: [
                    { type: "text", label: "ID Do cargo", style: "Short", placeholder: "ID do cargo no servidor do auth", customId: "new_value0"}
                ],
            });

            currentRole ? modal.modal.components[0].components[0].data.value = currentRole : null;
            modal.modal.components[0].components[0].data.required = false;

            await modal.show(interaction)
        };

        if (action === "webhook_notification") {
            const modal = new CreateModal({
                title: "Configuração de Webhook",
                customId: `on_config_server_submit_modal:webhook_notification:${server_id}`,
                inputs: [
                    { type: "text", label: "Webhook URL", style: "Short", required: true, placeholder: "URL do webhook", customId: "new_value0"}
                ],
            });

            await modal.show(interaction)
        }
    }
})

new InteractionHandler({
    customId: "on_config_server_submit_modal",
    useParams: true,

    run: async (client, interaction, action, server_id) => {
        if (!action || !server_id) return interaction.reply({ content: "❌ | Algo deu errado", ephemeral: true });

        const value0 = interaction.fields.getTextInputValue("new_value0");

        const guild = await api_discord_utils.getGuild(server_id);
        if (!guild) return interaction.reply({ content: "❌ | Servidor não encontrado", ephemeral: true });

        if (action === "initialize_config") {  
            const app_info = await api_auth_utils.getApplicationConfig().catch(e => null);
            if (!app_info) return interaction.reply({ content: "❌ | Aplicação não encontrada", ephemeral: true });

            const webhook = interaction.fields.getTextInputValue("new_value0");
            const role = interaction.fields.getTextInputValue("new_value1");

            const guild_icon = `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`;
            const random_id = Math.floor(Math.random() * 1000000);

            if (role){
                const existRole = await api_discord_utils.getRole(server_id, role).catch(e => console.log(e));
                if (!existRole) return interaction.reply({ content: "❌ | Cargo não encontrado", ephemeral: true });
            }
   
            const webhookExists = await axios.get(webhook).catch(e => null);
            if (!webhookExists) return interaction.reply({ content: "❌ | Webhook não encontrado", ephemeral: true });

            try {
                await api_auth_utils.updateServer(server_id, { 
                    'site_wallpaper': guild_icon, 
                    "site_icon": guild_icon, 
                    'bot_id': app_info.bot_id,
                    "server_name": guild.name,
                    "custom_domain": random_id,
                    "webhook_notification": webhook,
                    "verified_role_id": role || null
                })

                await client.easeClient.invokeInteraction(`back_to_config_server:${server_id}`, interaction);
            }catch(e){
                console.log(`Error on initialize_config: ${e}`)
                interaction.reply({ content: "❌ | Erro ao atualizar o banco de dados", ephemeral: true });
            }
        };

        if (action === "customize_url") {
            await interaction.deferUpdate();

            const valid_url = value0.match(/^[a-zA-Z0-9-_]+$/);
            if (!valid_url) return interaction.followUp({ content: "❌ | URL inválida, use apenas letras, números, - e _", ephemeral: true });

            const response = await api_auth_utils.updateServer(server_id, { custom_domain: value0 }).catch(e => console.log("Error on update server with customize_url!!")).then(true);
            if (!response) return interaction.followUp({ content: "❌ | Erro ao atualizar a URL, tente outra essa pode estar em uso.", ephemeral: true });

            await client.easeClient.invokeInteraction(`back_to_config_server:${server_id}`, interaction);
            await interaction.followUp({ content: "✅ | URL personalizada atualizada com sucesso", ephemeral: true });
        };

        if (action === "role") {
            await interaction.deferUpdate();

            if (value0){
                const roleExists = guild.roles.filter(role => String(role.id) === String(value0))
                if (!roleExists?.length > 0) return interaction.followUp({ content: `❌ | Cargo não encontrado no servidor \`${guild.name}\``, ephemeral: true });
            }

            const response = await api_auth_utils.updateServer(server_id, { verified_role_id: value0 || null }).catch(e => console.log(e)).then(true);
            if (!response) return interaction.reply({ content: "❌ | Erro ao atualizar o cargo", ephemeral: true });

            await client.easeClient.invokeInteraction(`back_to_config_server:${server_id}`, interaction);
            await interaction.followUp({ content: "✅ | Cargo atualizado com sucesso", ephemeral: true });
        };

        if (action === "webhook_notification") {
            const webhookValid = value0.includes("discord.com/api/webhooks/");
            if (!webhookValid) return interaction.reply({ content: `❌ | Webhook inválido`, ephemeral: true });

            const response = await api_auth_utils.updateServer(server_id, {"webhook_notification": value0}).catch(e => console.log(e)).then(true);
            if (!response) return interaction.reply({ content: "❌ | Erro ao atualizar o webhook", ephemeral: true });

            await client.easeClient.invokeInteraction(`back_to_config_server:${server_id}`, interaction);
            await interaction.followUp({ content: "✅ | Webhook atualizado com sucesso", ephemeral: true });
        }
    }
})

new InteractionHandler({
    customId: "on_config_server_without_client_secret",
    useParams: true,

    run: async (client, interaction, server_id) => {

        const bot_in_server = await api_discord_utils.getGuild(server_id);
        if (!bot_in_server) return interaction.reply({ content: "❌ | Bot não está no servidor", ephemeral: true });

        const messages = [
            `# Configurando Servidor ${bot_in_server.name}`,
            `- Olá, parece que você ainda não configurou o servidor \`${bot_in_server.name}\``,
            ` - Para configurar, clique no botão "Configurar", e informe oque for pedido dentro do modal.\n`
        ]

        const components = [
            new CreateRow([
                new CreateButton({label: "Configurar", customId: `initilize_config_server:${server_id}`, emoji: "1237510877238919231"}),
                new CreateButton({label: "Sair do Servidor", style: "Danger", customId: `leave_server:${server_id}`, emoji: "1232544264769114157"}),
                new CreateButton({label: "Voltar", style: "2", customId: "config_servers", emoji: "1237510920003911791"}),
            ]),
        ]

        return interaction.update({ content: messages.join("\n"), components: components, files: [], embeds: [], ephemeral: true });
    }
})

new InteractionHandler({
    customId: "try_exclude_server",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const embed = new CreateEmbed({
            author: {name: "Exclusão do servidor", iconURL: client.user.displayAvatarURL()},
            description: "Confirme abaixo se você realmente deseja excluir o servidor. Toda configuração será perdida permanentemente. Seus membros autenticados nesse servidor continuarão autenticado",
            color: "#FF0000"
        })

        const components = [
            new CreateRow([
                new CreateButton({label: "Sim", customId: `confirm_exclude_server:${server_id}`}),
                new CreateButton({label: "Não", customId: `back_to_config_server:${server_id}`, style: "Danger"})
            ])
        ]

        return interaction.update({ embeds: [embed], components, content: "", ephemeral: true})
    }
})

new InteractionHandler({
    customId: "confirm_exclude_server",
    useParams: true,

    run: async (client, interaction, server_id) => {
        try {
            await interaction.deferUpdate();
            await api_auth_utils.deleteServer(server_id);
            await client.easeClient.invokeInteraction("config_servers", interaction)
            await interaction.followUp({ content: `✅ | Servidor excluido com sucesso!`, ephemeral: true})
        }catch(e){
            return interaction.followUp({content: `❌ | Erro ao excluir o servidor. -> ${e.message}`, ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "leave_server",
    useParams: true,

    run: async (client, interaction, guild_id) => {
        try {
            if (!guild_id){
                throw new Error("Ocorreu um erro inesperado")
            }

            await api_discord_utils.leaveGuildByID(guild_id)
            await interaction.deferUpdate();

            await new Promise(resolve => setTimeout(resolve, 1000)); // Aguarda 1 segundo para não tomar rate-limit!!
            await client.easeClient.invokeInteraction("config_servers", interaction)
        }catch(e){
            return interaction.reply({ content: `❌ | ${e.message}`, ephemeral: true })
        }

    }
})

new InteractionHandler({
    customId: "back_to_config_server",
    useParams: true,

    run: async (client, interaction, server_id) => {
        interaction.values = [server_id];
        client.easeClient.invokeInteraction("on_select_config_server", interaction);
    }
});
