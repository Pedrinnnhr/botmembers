import { InteractionHandler, CreateRow, CreateButton, CreateEmbed, CreateSelect, CreateModal } from "ease-discord-js";
import { getEmbedAuth, setupDefaultEmbedConfig, api_discord_utils, databases } from "#utils";

new InteractionHandler({
    customId: "on_click_customize_embed",
    useParams: true,

    run: async (client, interaction, server_id) => {
        if (!server_id) return interaction.followUp({ content: "❌ | Algo deu errado", ephemeral: true }); 

        const server_info = await api_discord_utils.getGuild(server_id).catch(e => null);
        if (!server_info) return interaction.followUp({ content: "❌ | Servidor não encontrado", ephemeral: true });

        let embed_info = await databases.servers_embed.fetch(server_id);
        if (!embed_info) embed_info = await setupDefaultEmbedConfig(server_id);

        const embed = new CreateEmbed({
            author: { name: `Customização a Embed`, iconURL: client.user.displayAvatarURL() },
            description: `- Aqui você pode a embed da mensagem enviada no servidor \`${server_info.name}\`!`,
            fields: [
                { name: "Titulo", value: `${embed_info.embed_title ? embed_info.embed_title : "Não definido"}`, inline: false },
                { name: "Descrição", value: `${embed_info.embed_description ? embed_info.embed_description : "Não definido"}`, inline: false },
                { name: "Nome do Botão", value: `${embed_info.embed_button_name ? embed_info.embed_button_name : "Não definido"}`, inline: false },
                { name: "Cor da Embed", value: `${embed_info.embed_color ? `[${embed_info.embed_color}](https://www.color-hex.com/color/${(embed_info.embed_color).replace("#", "")})` : "Não definido"}`, inline: false },
                { name: "Banner", value: `${embed_info.embed_image_url ? `[Clique Aqui](${embed_info.embed_image_url})` : "Não definido"}`, inline: false },
                { name: "Footer", value: `${embed_info.embed_footer ? embed_info.embed_footer : "Não definido"}`, inline: false },
                { name: "Emoji", value: `${embed_info.embed_button_emoji ? embed_info.embed_button_emoji : "Não definido"}`, inline: false },
                { name: "Usar timestamp (footer) ? ", value: `${embed_info.embed_timestamp ? "Sim" : "Não"}`, inline: false },
                { name: "ID do Canal", value: `${embed_info.channel_message_id ? embed_info.channel_message_id : "Não definido"}`, inline: false },
            ]
        });

        const components = [
            new CreateRow([
                CreateSelect.StringSelectMenuBuilder({
                    customId: `on_select_customize_embed:${server_id}`,
                    placeholder: "Selecione oque deseja alterar",
                    options: [
                        { label: "ID do Canal", value: "channel_message_id", emoji: "📝", description: "Qual o ID do canal que será postada a embed"},
                        { label: "Titulo", value: "embed_title", emoji: "📜", description: "Titulo que terá na sua embed" },
                        { label: "Descrição", value: "embed_description", emoji: "📝", description: "Conteudo da embed"},
                        { label: "Nome do Botão", value: "embed_button_name", emoji: "🔘", description: "Oque estará escrito no botão de verificar"},
                        { label: "Cor da Embed", value: "embed_color", emoji: "🎨", description: "A Cor da lateral da embed"},
                        { label: "Footer", value: "embed_footer", emoji: "👣", description: "Oque estará escrito no rodapé da embed"},
                        { label: "Emoji", value: "embed_button_emoji", emoji: "🔠", description: "Emoji que ficará no botão"},
                        { label: "Banner", value: "embed_image_url", emoji: "🖼️", description: "Imagem anexada da embed"},
                        { label: "Usar timestamp (footer) ?", value: "embed_timestamp", emoji: "🕒", description: "Defina se irá mostrar o tempo na embed"},
                    ]   
                }),
            ]),
            new CreateRow([
                new CreateButton({label: "Preview Embed", customId: `preview_embed:${server_id}`, emoji: "1237510888253292614"}),
                new CreateButton({label: "Sincronizar Mensagem", customId: `send_message:${server_id}`, emoji: "1237511023389315123"}),
                new CreateButton({label: "Voltar", style: "Danger", customId: `back_to_config_server:${server_id}`, emoji: "1237510920003911791"}),
            ])
        ]

        if (interaction.deferred || interaction.replied) {
            await interaction.editReply({ content: "", components: components, files: [], embeds: [embed], ephemeral: true });
        }else{
            await interaction.update({ content: "", components: components, files: [], embeds: [embed], ephemeral: true });   
        }
    }
})

new InteractionHandler({
    customId: "send_message",
    useParams: true,

    run: async (client, interaction, server_id) => {
        if (!server_id){
            return interaction.reply({ content: "❌ | Algo deu errado", ephemeral: true });
        }

        if (!interaction.deferred) await interaction.deferUpdate();

        const server_info = await api_discord_utils.getGuild(server_id);
        if (!server_info) return interaction.followUp({ content: "❌ | Servidor não encontrado", ephemeral: true });

        const embed_info = await databases.servers_embed.fetch(server_id);
        if (!embed_info) return interaction.followUp({ content: "❌ | Erro ao buscar informações da embed", ephemeral: true });

        const channel_id = embed_info.channel_message_id;
        if (!channel_id) return interaction.followUp({ content: "❌ | Canal não definido", ephemeral: true });

        const channel_exists = await api_discord_utils.getChannel(channel_id).catch(e => null);
        if (!channel_exists) return interaction.followUp({ content: "❌ | Canal não encontrado", ephemeral: true });

        const embed = await getEmbedAuth(server_id);
        if (!embed) return interaction.followUp({ content: "❌ | Erro ao buscar informações da embed", ephemeral: true });

        try {
            const create_or_edit = await api_discord_utils.sendOrEditMessageInChannel(channel_id, embed.componentToSendAPI, embed_info.message_id);
            databases.servers_embed.set(`${server_id}.message_id`, create_or_edit.id);

            return interaction.followUp({ content: `${embed_info.message_id ? "✅ | Mensagem atualizada com sucesso" : "✅ | Mensagem enviada com sucesso"}`, ephemeral: true });
        }catch(e){
            return interaction.followUp({ content: `❌ | Erro ao enviar mensagem ~> ${e.message}`, ephemeral: true });
        }
    }
});

new InteractionHandler({
    customId: "on_select_customize_embed",
    useParams: true,    

    run: async (client, interaction, server_id) => {    
        const selected_option = interaction.values?.[0];    
        if (!selected_option) return interaction.reply({ content: "❌ | Algo deu errado", ephemeral: true });

        if (selected_option === "channel_message_id") {
            let currentChannel = await databases.servers_embed.fetch(server_id);
            currentChannel = currentChannel?.channel_message_id;

            const modal = new CreateModal({
                title: "Configuração de Canal",
                customId: `on_config_embed_submit_modal:channel_message_id:${server_id}`,
                inputs: [
                    { type: "text", label: "ID do Canal", style: "Short", required: true, placeholder: "ID do Canal", customId: "new_value0", value: currentChannel || undefined}
                ],
            });

            currentChannel ? modal.modal.components[0].components[0].data.value = currentChannel : null;
            await modal.show(interaction);
        }

        if (selected_option === "embed_title") {
            let currentTitle = await databases.servers_embed.fetch(server_id);
            currentTitle = currentTitle?.embed_title;

            const modal = new CreateModal({
                title: "Configuração de Título",
                customId: `on_config_embed_submit_modal:embed_title:${server_id}`,
                inputs: [
                    { type: "text", label: "Título", style: "Short", required: true, placeholder: "Título", customId: "new_value0", value: currentTitle || undefined}
                ],
            });

            currentTitle ? modal.modal.components[0].components[0].data.value = currentTitle : null;
            await modal.show(interaction);
        }

        if (selected_option === "embed_description") {
            let currentDescription = await databases.servers_embed.fetch(server_id);
            currentDescription = currentDescription?.embed_description;

            const modal = new CreateModal({
                title: "Configuração de Descrição",
                customId: `on_config_embed_submit_modal:embed_description:${server_id}`,
                inputs: [
                    { type: "text", label: "Descrição", style: "Paragraph", required: true, placeholder: "Descrição", customId: "new_value0", value: currentDescription || undefined}
                ],
            });

            currentDescription ? modal.modal.components[0].components[0].data.value = currentDescription : null;
            await modal.show(interaction);
        }

        if (selected_option === "embed_button_name") {
            let currentButtonName = await databases.servers_embed.fetch(server_id);
            currentButtonName = currentButtonName?.embed_button_name;

            const modal = new CreateModal({
                title: "Configuração de Nome do Botão",
                customId: `on_config_embed_submit_modal:embed_button_name:${server_id}`,
                inputs: [
                    { type: "text", label: "Nome", style: "Short", required: true, placeholder: "Nome do botão", customId: "new_value0", value: currentButtonName || undefined}
                ],
            });

            currentButtonName ? modal.modal.components[0].components[0].data.value = currentButtonName : null;
            await modal.show(interaction);
        }

        if (selected_option === "embed_color") {
            let currentColor = await databases.servers_embed.fetch(server_id);
            currentColor = currentColor?.embed_color;

            const modal = new CreateModal({
                title: "Configuração de Cor da Embed",
                customId: `on_config_embed_submit_modal:embed_color:${server_id}`,
                inputs: [
                    { type: "text", label: "Cor", style: "Short", required: true, placeholder: "Cor em hexadecimal", customId: "new_value0", value: currentColor || undefined}
                ],
            });

            currentColor ? modal.modal.components[0].components[0].data.value = currentColor : null;
            await modal.show(interaction);
        }

        if (selected_option === "embed_footer") {
            let currentFooter = await databases.servers_embed.fetch(server_id);
            currentFooter = currentFooter?.embed_footer;

            const modal = new CreateModal({
                title: "Configuração de Footer",
                customId: `on_config_embed_submit_modal:embed_footer:${server_id}`,
                inputs: [
                    { type: "text", label: "Footer", style: "Short", required: true, placeholder: "Footer", customId: "new_value0", value: currentFooter || undefined}
                ],
            });

            modal.modal.components[0].components[0].data.required = false;
            currentFooter ? modal.modal.components[0].components[0].data.value = currentFooter : null;
            await modal.show(interaction);
        }

        if (selected_option === "embed_button_emoji") {
            let currentEmoji = await databases.servers_embed.fetch(server_id);
            currentEmoji = currentEmoji?.embed_button_emoji;

            const modal = new CreateModal({
                title: "Configuração de Emoji",
                customId: `on_config_embed_submit_modal:embed_button_emoji:${server_id}`,
                inputs: [
                    { type: "text", label: "Emoji", style: "Short", required: true, placeholder: "Emoji", customId: "new_value0", value: currentEmoji || undefined}
                ],
            });

            modal.modal.components[0].components[0].data.required = false;
            currentEmoji ? modal.modal.components[0].components[0].data.value = currentEmoji : null;
            await modal.show(interaction);
        }

        if (selected_option === "embed_image_url") {
            let currentBanner = await databases.servers_embed.fetch(server_id);
            currentBanner = currentBanner?.embed_image_url;

            const modal = new CreateModal({
                title: "Configuração de Banner",
                customId: `on_config_embed_submit_modal:embed_image_url:${server_id}`,
                inputs: [
                    { type: "text", label: "URL da imagem", style: "Short", placeholder: "URL da imagem", customId: "new_value0"}
                ],
            });

            modal.modal.components[0].components[0].data.required = false;
            currentBanner ? modal.modal.components[0].components[0].data.value = currentBanner : null;
            await modal.show(interaction);
        }

        if (selected_option === "embed_timestamp") {
            let currentTimestamp = await databases.servers_embed.fetch(server_id);
            currentTimestamp = currentTimestamp?.embed_timestamp;

            const modal = new CreateModal({
                title: "Configuração de Timestamp",
                customId: `on_config_embed_submit_modal:embed_timestamp:${server_id}`,
                inputs: [
                    { type: "text", label: "Timestamp", style: "Short", placeholder: "Digite sim ou não", customId: "new_value0"}
                ],
            });

            currentTimestamp === true ? currentTimestamp = "Sim" : currentTimestamp === false ? currentTimestamp = "Não" : null;
            currentTimestamp ? modal.modal.components[0].components[0].data.value = currentTimestamp : null;
            await modal.show(interaction);
        }
    }
})

new InteractionHandler({
    customId: "on_config_embed_submit_modal",
    useParams: true,

    run: async (client, interaction, action, server_id) => {
        if (!action || !server_id) return interaction.reply({ content: "❌ | Algo deu errado", ephemeral: true });
        const value0 = interaction.fields.getTextInputValue("new_value0");  

        if (action === "channel_message_id") {
            try {
                if (isNaN(value0)) throw new Error("ID do canal inválido, use um ID válido");

                const channel_exists = await api_discord_utils.getChannelInGuild(server_id, value0).catch( e => null )
                if (!channel_exists) throw new Error(`Canal não encontrado`);

                const response = await databases.servers_embed.set(`${server_id}.channel_message_id`, value0)
                if (!response) throw new Error("Erro ao atualizar o canal");

                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Canal atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o canal -> ${e.message}`, ephemeral: true });
            }
        }

        if (action === "embed_title") {
            try {
                if (value0.length > 256) throw new Error("Título muito longo, use um título menor");

                const response = await databases.servers_embed.set(`${server_id}.embed_title`, value0)
                if (!response) throw new Error("Erro ao atualizar o título");

                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Título atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o título -> ${e.message}`, ephemeral: true });
            }
        }

        if (action === "embed_description") {
            try {
                if (value0.length > 4096) throw new Error("Descrição muito longa, use uma descrição menor");

                const response = await databases.servers_embed.set(`${server_id}.embed_description`, value0)
                if (!response) throw new Error("Erro ao atualizar a descrição");

                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Descrição atualizada com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar a descrição -> ${e.message}`, ephemeral: true });
            }
        }

        if (action === "embed_button_name") {
            try {
                if (value0.length > 20) throw new Error("Nome do botão muito longo, use um nome menor");

                const response = await databases.servers_embed.set(`${server_id}.embed_button_name`, value0)
                if (!response) throw new Error("Erro ao atualizar o nome do botão");

                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Nome do botão atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o nome do botão -> ${e.message}`, ephemeral: true });
            }
        }

        if (action === "embed_color") {
            try {
                const isValidHex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(value0);
                if (!isValidHex) throw new Error("Cor inválida, use um código hexadecimal válido");

                const response = await databases.servers_embed.set(`${server_id}.embed_color`, value0)
                if (!response) throw new Error("Erro ao atualizar a cor da embed");

                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Cor da embed atualizada com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar a cor da embed -> ${e.message}`, ephemeral: true });
            }

        }

        if (action === "embed_footer") {
            try {
                if (value0.length > 2048) throw new Error("Footer muito longo, use um footer menor");

                const response = await databases.servers_embed.set(`${server_id}.embed_footer`, value0)
                if (!response) throw new Error("Erro ao atualizar o footer");

                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Footer atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o footer -> ${e.message}`, ephemeral: true });
            }
        }

        if (action === "embed_button_emoji") {
            try {

                const response = await databases.servers_embed.set(`${server_id}.embed_button_emoji`, value0)
                if (!response) throw new Error("Erro ao atualizar o emoji");

                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Emoji atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o emoji -> ${e.message}`, ephemeral: true });
            }
        }

        if (action === "embed_image_url") {
            try {
                const isValidURL = value0.includes("http") || value0.includes("https");
                if (!isValidURL && value0) throw new Error("URL inválida, use uma URL válida");

                const response = await databases.servers_embed.set(`${server_id}.embed_image_url`, value0)
                if (!response) throw new Error("Erro ao atualizar o banner");

                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Banner atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o banner -> ${e.message}`, ephemeral: true });

            }
        }

        if (action === "embed_timestamp") {
            try {
                const enable = value0.toLowerCase() === "sim" ? true : value0.toLowerCase() === "não" ? false : null;
                if (enable === null) throw new Error("Valor inválido, use sim ou não");

                await databases.servers_embed.set(`${server_id}.embed_timestamp`, enable)

                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Timestamp atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_embed:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o timestamp -> ${e.message}`, ephemeral: true });
            }
        }
    }
}); 

new InteractionHandler({
    customId: "preview_embed",
    useParams: true,

    run: async (client, interaction, server_id) => {
        if (!server_id) return interaction.reply({ content: "❌ | Algo deu errado", ephemeral: true });

        const embedData = await getEmbedAuth(server_id);
        if (!embedData) return interaction.reply({ content: "❌ | Erro ao buscar informações da embed", ephemeral: true });

        embedData.ephemeral = true;
        await interaction.reply(embedData);
    }
});