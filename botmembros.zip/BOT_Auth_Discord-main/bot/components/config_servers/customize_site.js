import { InteractionHandler, CreateRow, CreateButton, CreateEmbed, CreateSelect, CreateModal } from "ease-discord-js";
import { api_auth_utils, api_discord_utils } from "#utils";

new InteractionHandler({
    customId: "on_click_customize_site",
    useParams: true,

    run: async (client, interaction, server_id) => {
        if (!server_id) return interaction.followUp({ content: "❌ | Algo deu errado", ephemeral: true }); 

        const server_info = await api_discord_utils.getGuild(server_id).catch(e => null);
        if (!server_info) return interaction.followUp({ content: "❌ | Servidor não encontrado", ephemeral: true });

        const server_info_api = await api_auth_utils.getServer(server_id, ["site_wallpaper", "site_color", "site_icon", "site_after_auth_message", "server_name"])
            .then(e => e.data)
            .catch(e => null);

        if (!server_info_api) return interaction.followUp({ content: "❌ | Servidor não encontrado", ephemeral: true });

        const embed = new CreateEmbed({
            author: { name: `Customização do Site`, iconURL: client.user.displayAvatarURL() },
            description: `- Aqui você pode customizar o site para o servidor \`${server_info.name}\`!`,
            fields: [
                { name: "Nome do Servidor", value: `${server_info_api.server_name}`, inline: false },
                { name: "Plano de Fundo", value: `${server_info_api.site_wallpaper ? `[Clique Aqui](${server_info_api.site_wallpaper})` : `Não definido`}`, inline: false },
                { name: "Logo", value: `${server_info_api.site_icon ? `[Clique Aqui](${server_info_api.site_icon})` : `Não definido`}`, inline: false },
                { name: "Cor temática", value: `${server_info_api.site_color ? `[${server_info_api.site_color}](${`https://color-hex.com/color/${(server_info_api.site_color).replace("#", "")}`})` : `Não definido`}`, inline: false },
                { name: "Mensagem após autenticação", value: `${server_info_api.site_after_auth_message ? server_info_api.site_after_auth_message : `Não definido`}`, inline: false },    
            ]
        });

        const components = [
            new CreateRow([
                CreateSelect.StringSelectMenuBuilder({
                    customId: `on_select_customize_site:${server_id}`,
                    placeholder: "Selecione oque deseja alterar",
                    options: [
                        { label: "Nome do servidor", value: "server_name", emoji: "📜", description: "Nome que irá aparecer destacado ao se autenticar"},
                        { label: "Plano de Fundo", value: "site_wallpaper", emoji: "🖼️", description: "Imagem que aparece de fundo do site com blur aplicado" },
                        { label: "Cor temática", value: "site_color", emoji: "🎨", description: "A Cor temática do site"},
                        { label: "Logo", value: "site_icon", emoji: "🖌️", description: "Logo do seu servidor que aparecerá em destaque"},
                        { label: "Mensagem", value: "site_after_auth_message", emoji: "📝", description: "Mensagem que aparecerá pro usuario autenticado"},
                    ]   
                }),
            ]),
            new CreateRow([
                new CreateButton({label: "Voltar", style: "Danger", customId: `back_to_config_server:${server_id}`, emoji: "1237510920003911791"}),
            ])
        ]

        if (interaction.deferred || interaction.replied) {
            await interaction.editReply({ content: "", components: components, files: [], embeds: [embed], ephemeral: true });
        }else{
            await interaction.update({ content: "", components: components, files: [], embeds: [embed], ephemeral: true });   
        }
    }
})

new InteractionHandler({
    customId: "on_select_customize_site",
    useParams: true,    

    run: async (client, interaction, server_id) => {    
        const selected_option = interaction.values?.[0];    
        if (!selected_option) return interaction.reply({ content: "❌ | Algo deu errado", ephemeral: true });

        if (selected_option === "site_wallpaper") {
            const currentWallpaper = await api_auth_utils.getServer(server_id, ["site_wallpaper"])
                .then(e => e.data.site_wallpaper)
                .catch(e => null);

            const modal = new CreateModal({
                title: "Configuração de Plano de Fundo",
                customId: `on_config_site_submit_modal:site_wallpaper:${server_id}`,
                inputs: [
                    { type: "text", label: "URL da imagem", style: "Short", required: false, placeholder: "URL da imagem", customId: "new_value0", value: currentWallpaper || undefined}
                ],
            });

            modal.modal.components[0].components[0].data.required = false;    
            currentWallpaper ? modal.modal.components[0].components[0].data.value = currentWallpaper : null;
            await modal.show(interaction);
        }

        if (selected_option === "site_color") {
            const currentColor = await api_auth_utils.getServer(server_id, ["site_color"])
                .then(e => e.data.site_color)
                .catch(e => null)

            const modal = new CreateModal({
                title: "Configuração de Cor Temática",
                customId: `on_config_site_submit_modal:site_color:${server_id}`,
                inputs: [
                    { type: "text", label: "Cor", style: "Short", required: true, placeholder: "Cor em hexadecimal", customId: "new_value0"}
                ],
            });

            currentColor ? modal.modal.components[0].components[0].data.value = currentColor : null;
            await modal.show(interaction);
        }

        if (selected_option === "server_name") {
            const currentName = await api_auth_utils.getServer(server_id, ["server_name"])
                .then(e => e.data.server_name)
                .catch(e => null)

            const modal = new CreateModal({
                title: "Configuração de Nome do Servidor",
                customId: `on_config_site_submit_modal:server_name:${server_id}`,
                inputs: [
                    { type: "text", label: "Nome", style: "Short", required: true, placeholder: "Nome do servidor", customId: "new_value0", value: currentName || undefined}
                ],
            });

            currentName ? modal.modal.components[0].components[0].data.value = currentName : null;
            await modal.show(interaction);
        }

        if (selected_option === "site_icon") {
            const currentIcon = await api_auth_utils.getServer(server_id, ["site_icon"])
                .then(e => e.data.site_icon)
                .catch(e => null);

            const modal = new CreateModal({
                title: "Configuração de Logo",
                customId: `on_config_site_submit_modal:site_icon:${server_id}`,
                inputs: [
                    { type: "text", label: "URL da imagem", style: "Short", placeholder: "URL da imagem", customId: "new_value0", value: currentIcon || undefined}
                ],
            });

            modal.modal.components[0].components[0].data.required = false;
            currentIcon ? modal.modal.components[0].components[0].data.value = currentIcon : null;
            await modal.show(interaction);
        }

        if (selected_option === "site_after_auth_message") {
            const currentMessage = await api_auth_utils.getServer(server_id, ["site_after_auth_message"])
                .then(e => e.data.site_after_auth_message)
                .catch(e => null)

            const modal = new CreateModal({
                title: "Configuração de Mensagem após autenticação",
                customId: `on_config_site_submit_modal:site_after_auth_message:${server_id}`,
                inputs: [
                    { type: "text", label: "Mensagem", style: "Paragraph", required: true, placeholder: "Mensagem", customId: "new_value0", value: currentMessage || undefined}
                ],
            });

            currentMessage ? modal.modal.components[0].components[0].data.value = currentMessage : null;
            await modal.show(interaction);
        }
    }
})

new InteractionHandler({
    customId: "on_config_site_submit_modal",
    useParams: true,

    run: async (client, interaction, action, server_id) => {
        if (!action || !server_id) return interaction.reply({ content: "❌ | Algo deu errado", ephemeral: true });
        const value0 = interaction.fields.getTextInputValue("new_value0");  

        if (action === "site_wallpaper") {
            try {
                const isValidURL = value0.includes("http") || value0.includes("https");
                if (!isValidURL && value0) throw new Error("URL inválida, use uma URL válida");

                const response = await api_auth_utils.updateServer(server_id, {"site_wallpaper": value0}).catch(e => console.log(e)).then(true);
                if (!response) throw new Error("Erro ao atualizar o plano de fundo");

                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Plano de fundo atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o plano de fundo -> ${e.message}`, ephemeral: true });
            }
        }

        if (action === "site_color") {
            try {
                const isValidHex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(value0);
                if (!isValidHex) throw new Error("Cor inválida, use um código hexadecimal válido");
    
                const response = await api_auth_utils.updateServer(server_id, {"site_color": value0}).catch(e => console.log(e)).then(true);
                if (!response) throw new Error("Erro ao atualizar a cor temática");
    
                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Cor temática atualizada com sucesso", ephemeral: true });
            
            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar a cor temática -> ${e.message}`, ephemeral: true });
            }

        }

        if (action === "site_icon") {
            try {
                const isValidURL = value0.includes("http") || value0.includes("https");
                if (!isValidURL && value0) throw new Error("URL inválida, use uma URL válida");

                const response = await api_auth_utils.updateServer(server_id, {"site_icon": value0}).catch(e => console.log(e)).then(true);
                if (!response) throw new Error("Erro ao atualizar o logo");

                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Logo atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o logo -> ${e.message}`, ephemeral: true });
            }
        }

        if (action === "server_name") {
            try {
                if (value0.length > 20) throw new Error("Nome muito longo, use um nome menor");

                const response = await api_auth_utils.updateServer(server_id, {"server_name": value0}).catch(e => console.log(e)).then(true);
                if (!response) throw new Error("Erro ao atualizar o nome do servidor");

                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Nome do servidor atualizado com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar o nome do servidor -> ${e.message}`, ephemeral: true });
            }
        }

        if (action === "site_after_auth_message") {
            try {
                if (value0.length > 200) throw new Error("Mensagem muito longa, use uma mensagem menor");

                const response = await api_auth_utils.updateServer(server_id, {"site_after_auth_message": value0}).catch(e => console.log(e)).then(true);
                if (!response) throw new Error("Erro ao atualizar a mensagem após autenticação");

                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                await interaction.followUp({ content: "✅ | Mensagem após autenticação atualizada com sucesso", ephemeral: true });

            }catch(e){
                await client.easeClient.invokeInteraction(`on_click_customize_site:${server_id}`, interaction);
                return interaction.followUp({ content: `❌ | Erro ao atualizar a mensagem após autenticação -> ${e.message}`, ephemeral: true });
            }
        }
    }
}); 