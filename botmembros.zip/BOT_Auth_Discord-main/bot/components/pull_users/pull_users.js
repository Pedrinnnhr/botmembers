import { CreateButton, CreateEmbed, CreateModal, CreateRow, CreateSelect, InteractionHandler } from "ease-discord-js";
import { api_auth_utils, api_discord_utils } from "#utils";
import axios from "axios";

new InteractionHandler({
    customId: "pull_users",
    useParams: true,

    run: async (client, interaction, _currentPage = 1) => {
        const servers = await api_discord_utils.getGuilds().catch(e => console.log(`Erro ao buscar servidores: ${e?.response?.data || e.message}`))
        if (!servers) return interaction.followUp({content: "Erro ao buscar servidores", ephemeral: true})

        const verified_members = await api_auth_utils.getVerifiedUsers().catch(e => console.log(`Erro ao buscar usuários: ${e?.response?.data || e.message}`))
        if (!verified_members || !verified_members?.data) return interaction.followUp({content: "Erro ao buscar usuários", ephemeral: true})


        let servers_data = Object.keys(verified_members.data).map( server_id => {
            const server_info = verified_members.data[server_id];
            const verified_members_count = server_info.verified_users.length;

            const server_discord_info = servers.find(x => x.id === server_id);

            let label = "";
            let emoji = "";

            if (verified_members_count > 0 && !server_discord_info){
                emoji = "🟠";
                label = `${`[BOT NÃO PRESENTE] ${server_info.server_name}`} - Usuarios: ${verified_members_count}`
            }else if (verified_members_count > 0 && server_discord_info){
                emoji = "🟢";
                label = `${`${server_info.server_name}`} - Usuarios: ${verified_members_count}`
            }else if (verified_members_count <= 0){
                emoji = "🔴";
                label = `${`${server_info.server_name}`} - Usuarios: ${verified_members_count}`
            }

            return { label: label, value: server_id, description: `ID: ${server_id}`, emoji}
        })

        // Ordena os servidores por quantidade de usuários verificados
        servers_data = servers_data.sort((a, b) => { return b.emoji === "🟢" ? 1 : -1 })

        // adiciona em primeiro lugaar 
        servers_data.unshift({ label: `Qualquer servidor - ${verified_members.verifiedUsersCount} Usuários unicos`, value: "any", description: `Puxa qualquer usuário verificado`, emoji: "🟠"})

        const maxItemsPerPage = 15;
        const currentPage = Number(_currentPage);
        const nextPage = currentPage + 1;
        const previousPage = currentPage - 1;

        const totalServers = servers_data.length;
        const totalPages = Math.ceil(totalServers / maxItemsPerPage);
        const serversInCurrentPage = servers_data.slice((currentPage - 1) * maxItemsPerPage, currentPage * maxItemsPerPage);

        const messages = [
            `# Sistema de Puxar Membros`,
            `> - **Usuarios Unicos:** \`${verified_members.verifiedUsersCount}\`\n>  Esses são os usuarios elegiveis a puxar\n`,
            `> - **Usuarios Repetidos:** \`${verified_members.repeatedUsersCount}\`\n>  Esses são os usuários que estão em mais de um servidor.\n`,
            `> - **Total de Usuarios:** \`${verified_members.totalUsersCount}\`\n>  Total de usuários verificados no sistema.\nㅤ`,
            `📖 Pagina ${currentPage}/${totalPages}`,
        ]

        const components = [
            new CreateRow([
                CreateSelect.StringSelectMenuBuilder({customId: "select_server_to_pull", placeholder: "Selecione o servidor para puxar", options: serversInCurrentPage })
            ]),
            new CreateRow([
                new CreateButton({ label: " ", emoji: "⬅️", customId: `pull_users:${previousPage}`, disabled: currentPage === 1}),
                new CreateButton({ label: `Pagina ${currentPage}/${totalPages}`, style: "Secondary", customId: "234234234", disabled: true }),
                new CreateButton({ label: " ", emoji: "➡️", customId: `pull_users:${nextPage}`, disabled: currentPage === totalPages}),
                new CreateButton({ label: "Fila", customId: "pull_queue", emoji: "1237510930804506765"}),
                new CreateButton({ label: "Webhook", customId: `set_queue_webhook`, emoji: "1237510909291663490"}),
            ]),
            
            new CreateRow([
                new CreateButton({ label: "Voltar", style: "Danger", customId: "back_to_config", emoji: "1237510920003911791" }),
            ])
        ]

        if (interaction.deferred || interaction.replied){
            await interaction.editReply({ content: messages.join("\n"), embeds: [], components: components, files: [], ephemeral: true})
        }else{
            await interaction.update({ content: messages.join("\n"), embeds: [], components: components, files: [], ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "select_server_to_pull",

    run: async (client, interaction) => {
        try {
            const server_to_pull = interaction.values[0]
            if (!server_to_pull) throw new Error("Servidor não encontrado")
                
            let totalUsersAvailableToPull = 0;

            if (server_to_pull === "any"){
                const verified_members = await api_auth_utils.getVerifiedUsers().catch(e => console.log(`Erro ao buscar usuários: ${e?.response?.data || e.message}`))
                if (!verified_members || !verified_members?.data) throw new Error("Erro ao buscar usuários")

                totalUsersAvailableToPull = verified_members.verifiedUsersCount;
            }else{
                const server_info_api = await api_auth_utils.getServer(server_to_pull, [], true).catch(e => console.log(`Erro ao buscar informações do servidor: ${e?.response?.data || e.message}`))
                if (!server_info_api || !server_info_api.data) throw new Error("Erro ao buscar informações do servidor")

                totalUsersAvailableToPull = server_info_api?.data?.verified_users?.length || 0;
            }

            if (Number(totalUsersAvailableToPull) <= 0) throw new Error("Nenhum usuário verificado encontrado")

            const modal = new CreateModal({
                title: `Puxar usuários`,
                customId: `on_submit_pull_users_modal:${server_to_pull}:${totalUsersAvailableToPull}`,
                inputs: [
                    {type: "text", label: "Quantos usuarios deseja puxar ?", customId: "pull_quantity", style: "Short"},
                    {type: "text", label: "Qual o ID do servidor a receber os membros?", customId: "server_id", style: "Short", value: server_to_pull},
                ],
            })

            await modal.show(interaction)

        }catch(e){
            await client.easeClient.invokeInteraction("pull_users", interaction)
            await interaction.followUp({content: String(e.message), ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "set_queue_webhook",
    
    run: async (client, interaction) => {
        const config = await api_auth_utils.getApplicationConfig()

        const modal = new CreateModal({
            title: "Webhook da fila",
            customId: `on_submit_webhook_queue_modal`,
            inputs: [
                {type: "text", label: "Qual o Webhook do canal ?", customId: "channel_webhook", style: "Short"}
            ]
        })

        config?.queue_webhook ? modal.modal.components[0].components[0].data.value = config?.queue_webhook : null;
        await modal.show(interaction);
    }
})

new InteractionHandler({
    customId: "on_submit_webhook_queue_modal",

    run: async (_, interaction) => {
        const webhook = interaction.fields.getTextInputValue("channel_webhook");

        try {
            if (!webhook){
                throw new Error("Você esqueceu de colocar o webhook")
            }

            const isValidURL = webhook.includes("http") || webhook.includes("https");
            if (!isValidURL) throw new Error("URL inválida, use uma URL válida")

            const webhook_exists = await axios.get(webhook).catch( e => null )
            if (!webhook_exists) throw new Error("Webhook não existe, use um válido.") 

            await api_auth_utils.updateApplicationConfig({queue_webhook: webhook})
            await interaction.reply({ content: "✅ | Webhook alterado com sucesso.", ephemeral: true })

        }catch(e){
            return await interaction.reply({content: `❌ | ${e.message}`, ephemeral: true})
        }

    }
})

new InteractionHandler({
    customId: "on_submit_pull_users_modal",
    useParams: true,

    run: async (client, interaction, server_id_from, quantity_verified) => {
        const pull_quantity = interaction.fields.getTextInputValue("pull_quantity");
        const server_id_to = interaction.fields.getTextInputValue("server_id");

        try {
            if (!interaction.deferred) await interaction.deferUpdate();
            
            if (!pull_quantity || isNaN(pull_quantity)){
                throw new Error("Quantidade de usuários inválida, use apenas números.")
            }

            if (!server_id_to || isNaN(server_id_to)){
                throw new Error("ID do servidor inválido, use apenas números.")
            }

            if (Number(pull_quantity) > Number(quantity_verified)){
                throw new Error("Quantidade de usuários a puxar maior que a quantidade de usuários verificados.")
            } 

            const bot_in_server = await api_discord_utils.getGuild(server_id_to).catch(e => console.log(`Erro ao buscar bot no servidor: ${e?.response?.data || e.message}`))
            if (!bot_in_server) throw new Error(`Bot não encontrado no servidor informado: \`${server_id_to}\``) 

            const runningPulls = await api_auth_utils.getQueuePulls({status: "pending", origin: "manually"}).catch(e => console.log(`Erro ao buscar pulls pendentes: ${e?.response?.data || e.message}`))
            if (!runningPulls?.data) throw new Error("Erro ao buscar pulls pendentes")
            
            if (runningPulls.data.find(pull => pull.from === server_id_from && pull.to === server_id_to)){
                if (server_id_from === "any"){
                    throw new Error("Já existe uma pull pendente entre qualquer servidor e o servidor informado, aguarde o término para continuar.")
                }else{
                    throw new Error("Já existe uma pull pendente entre esses servidores, aguarde o término para continuar.")
                }
            }

            if (runningPulls.data.length > 3){
                throw new Error("Limite de 3 pulls pendentes atingido, aguarde o término de algum para continuar.")
            }

            await api_auth_utils.createQueuePull({ 
                origin: "manually",
                description: `Criado por ${interaction.user.username} (${interaction.user.id})`,
                from: server_id_from,
                to: server_id_to,
                quantity_total: pull_quantity,
            })

            await interaction.followUp({content: `✅ | Fila criada com sucesso.`, ephemeral: true})
            await client.easeClient.invokeInteraction("pull_users", interaction)
        }catch(e){
            await client.easeClient.invokeInteraction("pull_users", interaction)
            await interaction.followUp({content: `❌ | ${e.message}`, ephemeral: true})
        }
    }
})