import { CreateButton, CreateEmbed, CreateRow, CreateSelect, InteractionHandler } from "ease-discord-js";
import { api_auth_utils } from "#utils";

new InteractionHandler({
    customId: "pull_queue",
    useParams: true,

    run: async (client, interaction, queue_id) => {
        try {
            const [pendingQueue, runningQueue] = await Promise.all([
                api_auth_utils.getQueuePulls({ status: "pending" }).catch(e => console.log(`Erro ao buscar fila: ${e?.response?.data || e.message}`)),
                api_auth_utils.getQueuePulls({ status: "processing" }).catch(e => console.log(`Erro ao buscar fila: ${e?.response?.data || e.message}`))
            ]);

            if (!pendingQueue?.data) throw new Error("Erro ao buscar fila pendente");
            if (!runningQueue?.data) throw new Error("Erro ao buscar fila em andamento");

            const queues = [...pendingQueue.data, ...runningQueue.data];
            const options = queues.map(queue => ({ label: `ID: ${queue.id} -  Status: ${queue.status}`, value: String(queue.id), description: String(queue.description), emoji: { name: queue.status === "pending" ? "🟡" : "🟢" }}));

            const components = [
                ... queues.length > 0 ? [
                    new CreateRow([
                        CreateSelect.StringSelectMenuBuilder({ customId: "pull_queue_selected", placeholder: "Selecione uma fila", options: options})
                    ]),
                ] : [],

                new CreateRow([
                    new CreateButton({ label: "Atualizar", style: "Primary", customId: "pull_queue" + (queue_id ? `:${queue_id}` : "") }),
                    new CreateButton({ label: "Voltar", style: "Danger", customId: "pull_users" })
                ])
            ];

            const messages = [
                `- Segue abaixo a contagem de filas de espera para puxar:`,
                ` - Em Andamento: \`${runningQueue?.data?.length || 0}\``,
                ` - Pendente: \`${pendingQueue?.data?.length || 0}\`\n`,
                `As filas são processadas em ordem de chegada, e apenas uma fila é processada por vez para evitar problema com a API do Discord.`,
            ]

            return interaction.update({ content: messages.join("\n"), embeds: [], components: components });
        } catch (e) {
            console.log(e)
            return interaction.reply({ content: `❌ | ${e.message}`, ephemeral: true });
        }
    }
});

new InteractionHandler({
    customId: "pull_queue_selected",

    run: async (client, interaction) => {
        try {
            const queue_id = interaction.values[0];

            const queue = await api_auth_utils.getQueuePulls({ id: queue_id }).catch(e => console.log(`Erro ao buscar fila: ${e?.response?.data || e.message}`));
            if (!queue?.data?.[0]) throw new Error("Erro ao buscar fila");

            const description = [
                `- Dados da fila:`,
                ` - Andamento: \`${queue.data[0].quantity_pulled}/${queue.data[0].quantity_total}\``,
                ` - Descrição: \`${queue.data[0].description}\``,
                ` - Servidor de Origem: \`${queue.data[0].from}\``,
                ` - Servidor de Destino: \`${queue.data[0].to}\``,
                ` - Status: \`${queue.data[0].status}\``,
                ` - Data da Criação: \`${new Date(queue.data[0].createdAt).toLocaleString()}\`\nㅤ`,
            ]

            const embed = new CreateEmbed({
                author: { name: `Fila de espera de pulls #${queue.data[0].id}`, iconURL: client.user.displayAvatarURL() },
                description: description.join("\n"),
                timestamp: true,
                footer: { text: `ID: ${queue.data[0].id}` }
            });

            const components = [
                new CreateRow([
                    CreateSelect.StringSelectMenuBuilder({
                        customId: `pull_queue_select_queue_action:${queue_id}`,
                        placeholder: "Selecione uma ação",
                        options: [
                            { label: "Cancelar", value: "cancel", description: "Cancelar a fila, não terá como voltar atrás!", emoji: "❌"}
                        ]
                    })
                ]),
                new CreateRow([
                    new CreateButton({ label: "Voltar", style: "Danger", customId: "pull_queue" })
                ])
            ];

            return interaction.update({ embeds: [embed], components: components });
        } catch (e) {
            return interaction.reply({ content: e.message, ephemeral: true });
        }
    }
});

new InteractionHandler({
    customId: "pull_queue_select_queue",

    run: async (client, interaction) => {
        try {
            const option = interaction.values[0];
            await client.easeClient.invokeInteraction(`pull_queue:${option}`, interaction);
        } catch (e) {
            await client.easeClient.invokeInteraction("pull_queue", interaction);
            return interaction.reply({ content: e.message, ephemeral: true });
        }
    }
});

new InteractionHandler({
    customId: "pull_queue_select_queue_action",
    useParams: true,

    run: async (client, interaction, queue_id) => {
        try {
            const action = interaction.values[0];
            
            if (action === "cancel") {
                await api_auth_utils.updateQueuePull(queue_id, { 
                    status: "canceled",
                    reason_closure: `Cancelado por ${interaction.user.tag} (${interaction.user.id})`
                })

                await client.easeClient.invokeInteraction("pull_queue", interaction);
                return interaction.reply({ content: "Fila cancelada com sucesso", ephemeral: true });
            }
        } catch (e) {
            await client.easeClient.invokeInteraction("pull_queue", interaction);
            return interaction.reply({ content: e.message, ephemeral: true });
        }
    }
});
