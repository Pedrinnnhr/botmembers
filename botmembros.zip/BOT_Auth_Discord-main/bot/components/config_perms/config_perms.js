import { CreateButton, CreateEmbed, CreateRow, CreateSelect, InteractionHandler } from "ease-discord-js";
import { databases } from "#utils";
import deploy from "../../../deploy.json" with { type: "json" };

new InteractionHandler({
    customId: "config_perms",
    
    run: async (client, interaction) => {

        // Verificando se é o dono do BOT, pois ele é o unico que pode setar permissão.
        if (interaction.user.id !== deploy.owner_id){
            return interaction.reply({ content: "❌ | Você não possui permissão para acessar esse botão.", ephemeral: true})
        }

        const usersPermissions = databases.config.fetch("permissions") || [];

        let userPermissionString = "" 
        usersPermissions.map((user_id) => {
            userPermissionString += `- <@${user_id}> - ${user_id}\n`
        })

        const description = [
            "Usuarios com permissões:",
            `${userPermissionString || "- Nenhum"}`,
        ]


        const embed = new CreateEmbed({
            author: { name: "Configuração de Permissões", iconURL: client.user.displayAvatarURL() },
            description: description.join("\n"),
        })

        const components = [
            new CreateRow([
                new CreateButton({ label: "Adicionar membro", customId: "config_perms_users:add"}),
                new CreateButton({ label: "Remover membro", customId: "config_perms_users:remove"}),
                new CreateButton({ label: "Voltar", customId: "config_bot_panel", style: "Danger"})
            ])
        ]

        interaction.update({ content: "", embeds: [embed], components, files: [], ephemeral: true })
    }
})

new InteractionHandler({
    customId: "config_perms_users",
    useParams: true,

    run: async ( client, interaction, option ) => {
        const components = [
            new CreateRow(
                CreateSelect.UserSelectMenuBuilder({ customId: `on_select_user_perm:${option}`, placeholder: "Escolha um usuario"})
            ),
            new CreateRow(
                new CreateButton({ label: "Voltar", customId: "config_perms", style: "Danger"})
            )
        ]

        interaction.update({ embeds: [], content: `- Selecione um usuario para ${option === "add" ? "adicionar" : "remover"} permissão.`, components})
    }
})

new InteractionHandler({
    customId: "on_select_user_perm",
    useParams: true,

    run: async ( client, interaction, option ) => {
        const usersPermissions = databases.config.fetch("permissions") || [];

        if (option === "add"){
            if (usersPermissions.includes(interaction.values[0])){
                return interaction.reply({ content: "❌ | Esse usuario já possui permissão!", ephemeral: true})
            }

            databases.config.push(`permissions`, interaction.values[0])
            await client.easeClient.invokeInteraction(`config_perms`, interaction)

        }else if (option === "remove"){

            if (!usersPermissions.includes(interaction.values[0])){
                return interaction.reply({ content: "❌ | Esse usuario não possui permissão.", ephemeral: true})
            }

            databases.config.pull("permissions", (user_id) => user_id === interaction.values[0], true); // Multiple options = true. (default false)
            await client.easeClient.invokeInteraction(`config_perms`, interaction)
        }
    }
})