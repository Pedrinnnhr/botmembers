import { CreateButton, CreateRow, InteractionHandler, CreateModal } from "ease-discord-js";
import { getTotalSalesByServer, getCanvasChartBuffer, databases, getUserHasPermissionByID } from "#utils"
import { AttachmentBuilder } from "discord.js";

new InteractionHandler({
    customId: "statistics",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const sales = getTotalSalesByServer(server_id);
        const guild_info = client.guilds.cache.get(server_id)

        const contents = [
            `# Estatisticas`,
            `- Aqui você terá uma visão melhor a respeito das vendas do seu servidor \`${guild_info?.name || "BOT NÃO PRESENTE"}\`!\n`,
            `- **Valores recebidos:**`,
            ` - Vendas Automaticas: \`${(sales.auto).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\``,
            ` - Vendas Semi-Automaticas: \`${(sales.semiauto).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\``,
            ` - Automatica + Semi-Automatica: \`${(sales.total).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\``,
            ` - **Vendido esse MÊS: \`${(sales.soldThisMonth).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\`**`,
            ` - **Vendido HOJE: \`${(sales.soldToday).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\`**`,
            ` - **Saldo Atual: \`${(sales.balance).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\`**\n`,
            `\`📊\` O Grafico abaixo representa as vendas dos ultimos 5 dias`,  
        ]

        const labels = Object.keys(sales.lastFiveDaysByWeekdays).map((weekDay) => `${weekDay} (${sales.lastFiveDaysByWeekdays[weekDay].dayOfMonth})`)
        const values = Object.keys(sales.lastFiveDaysByWeekdays).map((weekDay) => (sales.lastFiveDaysByWeekdays[weekDay].totalSold).toFixed(2))

        const canvasChartBuffer = getCanvasChartBuffer({ prefix: "R$", labels: labels.reverse(), values: values.reverse(), type: "line", width: 440, height: 250, borderColor: 'rgb(75, 192, 192)', beginAtZero: true});
        const attachment = new AttachmentBuilder(canvasChartBuffer, {name: "chart.png"});

        const backCustomID = getUserHasPermissionByID(interaction.user.id) ? `back_to_sales_config_server:${server_id}` : `invoke-configloja-command`;
        const components = [
            new CreateRow([
                new CreateButton({ label: "Adicionar Saldo", customId: `change-balance-server:add:${server_id}`, emoji: "1235772114347491339"}),
                new CreateButton({ label: "Remover Saldo", customId: `change-balance-server:remove:${server_id}`, emoji: "1227681755297874062"}),
                new CreateButton({ label: "Baixar Extrato", customId: `change-balance-server:download:${server_id}`, emoji: "1237511034722320424"}),
                new CreateButton({ label: "Atualizar Painel", customId: `statistics:${server_id}`, emoji: "1237511023389315123"}),
                new CreateButton({ label: "Voltar", customId: backCustomID, style: "Secondary", emoji: "1237510920003911791"}),
            ])
        ]

        return interaction.update({ content: contents.join("\n"), components, files: [attachment] })
    }
})

new InteractionHandler({
    customId: "change-balance-server",
    useParams: true,

    run: async (client, interaction, action, server_id) => {
        if (action !== "download" && !getUserHasPermissionByID(interaction.user.id)){
            return interaction.reply({ content: `❌ | Você não possui permissão para usar essa função!`, ephemeral: true})
        }

        if (action === "add"){
            const modal = new CreateModal({
                title: "Alteração do Saldo",
                customId: `submit-change-balance-server:add:${server_id}`,
                inputs: [
                    {type: "text", label: "Quanto você deseja adicionar ao saldo?", customId: "value", style: "Short"},
                    {type: "text", label: "Qual o motivo ?", customId: "description", style: "Paragraph", placeholder: "Venda de anão"},
                ],
            })

            modal.show(interaction);
        }else if (action === "remove"){

            const modal = new CreateModal({
                title: "Alteração do Saldo",
                customId: `submit-change-balance-server:remove:${server_id}`,
                inputs: [
                    {type: "text", label: "Quanto você deseja remover do saldo?", customId: "value", style: "Short"},
                    {type: "text", label: "Qual o motivo ?", customId: "description", style: "Paragraph", placeholder: "Comprar bot na AppsSystem"},
                ],
            })

            modal.show(interaction);
        }

        if (action === "download"){
            const guild_name = client.guilds.cache.get(server_id) || "N/A"

            const extracts = databases.extracts.fetch(`extracts.${server_id}`) || [];
            const extractContent = JSON.stringify(extracts.reverse(), null, 2);

            const buffer = Buffer.from(extractContent, 'utf-8');
            const attachment = new AttachmentBuilder(buffer, {name: `extract_${server_id}.json`});

            await interaction.reply({ content: `✅ | Segue abaixo o extrato de movimentação desse servidor -> \`${guild_name}\``, files: [attachment], ephemeral: true });
        }
    }
})

new InteractionHandler({
    customId: "submit-change-balance-server",
    useParams: true,

    run: async (client, interaction, action, server_id) => {
        let value = interaction.fields.getTextInputValue("value");
        let value2 = interaction.fields.getTextInputValue("description");

        value = value.replace(",", ".")

        if (isNaN(value)){
            return interaction.reply({content: "❌ | O novo valor deve conter apenas numeros.", ephemeral: true})
        }

        try {
            if (action === "add"){
                databases.extracts.push(`extracts.${server_id}`, { action: "add", amount: parseFloat(value), transaction_origin: value2 || "N/A", date: new Date()})
            }else if (action === "remove"){
                databases.extracts.push(`extracts.${server_id}`, { action: "remove", amount: parseFloat(value), transaction_origin: value2 || "N/A", date: new Date()})
            }
    
            await client.easeClient.invokeInteraction(`statistics:${server_id}`, interaction)
            await interaction.followUp({ content: "✅ | Saldo alterado com sucesso!", ephemeral: true})
        }catch(e){
            interaction.reply({content: `❌ | Erro ao alterar seu saldo: ${e.message}`, ephemeral: true})
        }
    }
})