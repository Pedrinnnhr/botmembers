import { CreateButton, CreateEmbed, CreateModal, CreateRow, CreateSelect, InteractionHandler } from "ease-discord-js";
import { databases, getSaleEmbed, api_auth_utils, getUserHasPermissionByID } from "#utils";

const buttonsNameType = {
    "cinza": "Secondary",
    "azul": "Primary",
    "vermelho": "Danger",
    "verde": "Success"
}

new InteractionHandler({
    customId: "config_sales_server_embed",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const embedSettings = databases.sales_config.fetch(`servers.${server_id}.embed_settings`);
        
        const embed = new CreateEmbed({
            author: { name: `Configurações de vendas -> Customizando Embed`, iconURL: client.user.displayAvatarURL() },
            fields: [
                {name: `ID do canal`, value: `${embedSettings.channel_id || "Não definido"}`},
                {name: `Titulo`, value: String(embedSettings.title), inline: false},
                {name: `Descrição`, value: String(embedSettings.description), inline: false},
                {name: `Cor`, value: String(embedSettings.color), inline: false},
                {name: `Banner`, value: `${embedSettings.banner ? `[Clique aqui](${embedSettings.banner})` : "Não definido"}`, inline: false},
                {name: `Cor do botão`, value: String(embedSettings.button_color || "Azul"), inline: false},
                {name: `Emoji botão`, value: String(embedSettings.button_emoji || "Não definido"), inline: false},
                {name: `Texto do botão`, value: String(embedSettings.button_label), inline: false},
            ]
        })

        const selectComponent = CreateSelect.StringSelectMenuBuilder({
            customId: `on_select_config_sales_embed:${server_id}`,
            placeholder: "Selecione uma opção para configurada",
            options: [
                {label: "ID do Canal", value: "channel_id", description: "O ID do canal que será enviado a mensagem", emoji: "🗒️"},
                {label: "Titulo", value: "title", description: "O Titulo principal da embed", emoji: "📝"},
                {label: "Descrição", value: "description", description: "Descrição da embed", emoji: "📜"},
                {label: "Cor", value: "color", description: "Cor lateral da embed", emoji: "🎨"},
                {label: "Banner", value: "banner", description: "Imagem que aparecerá na parte de baixo", emoji: "🖼️"},
                {label: "Emoji do botão", value: "button_emoji", description: "Emoji do botão de compra", emoji: "🤨"},
                {label: "Cor do botão", value: "button_color", description: "Cor do botão de compra", emoji: "🎨"},
                {label: "Texto do botão", value: "button_label", description: "Texto que aparecerá no botão de compra", emoji: "🔘"},
            ]
        })

        const backCustomID = getUserHasPermissionByID(interaction.user.id) ? `back_to_sales_config_server:${server_id}` : `invoke-configloja-command`;

        const components = [
            new CreateRow(selectComponent),
            new CreateRow([
                new CreateButton({label: "Preview Da Embed", customId: `config_sales_server_embed_preview:${server_id}`, emoji: "1237510888253292614"}),
                new CreateButton({label: "Sincronizar mensagem", customId: `config_sales_server_send_message:${server_id}`, emoji: "1237511023389315123"}),
                new CreateButton({label: "Voltar", style: "2", customId: backCustomID, emoji: "1237510920003911791"})
            ])
        ]

        if (interaction.replied || interaction.deferred){
            interaction.editReply({content: "", embeds: [embed], components, ephemeral: true})
        }else{
            interaction.update({content: "", embeds: [embed], components, ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "on_select_config_sales_embed",
    useParams: true,

    run: async (client, interaction, server_id  ) => {

        const option = interaction.values[0];

        let placeholder = "";
        let label = null;
        let style = "Short"
        let required = true;

        if (option === "channel_id"){
            label = "Qual ID do Canal ?"
        }

        if (option === "button_label") {
            label = "Qual novo nome do botão ?"
        }

        if (option === "button_emoji"){
            label = "Qual o emoji do botão?"
            required = false;
        }

        if (option === "banner"){
            label = "Qual URL do Banner?"
            required = false;
        }

        if (option === "color"){
            label = "Qual a cor da embed?"
        }

        if (option === "description"){
            label = "Qual a Descrição da embed?"
            style = "Paragraph"
        }

        if (option === "button_color"){
            label = "Qual será a cor do botão?"
            placeholder = Object.keys(buttonsNameType).join(", ");
            required = true;
        }

        if (option === "title"){
            label = "Qual o titulo da embed?"
        }

        if (!label) return;

        const modal = new CreateModal({
            customId: `on_config_sales_server_modal_submit:${option}:${server_id}`,
            title: "Nova configuração",
            inputs: [
                {type: "text", customId: "value0", style, label, placeholder: placeholder || undefined},
            ]
        })

        const defaultValue = databases.sales_config.fetch(`servers.${server_id}.embed_settings.${option}`) || ""

        modal.modal.components[0].components[0].data.value = defaultValue;
        modal.modal.components[0].components[0].data.required = required;

        modal.show(interaction);
    }
})

new InteractionHandler({
    customId: "on_config_sales_server_modal_submit",
    useParams: true,

    run: async (client, interaction, option, server_id) => {
        let value = interaction.fields.getTextInputValue("value0");

        if (!server_id) return;
        if (!option) return;

        try {
            await interaction.deferUpdate();

            if (option === "color"){
                const isValidHex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(value);
                if (!isValidHex) throw new Error("Cor inválida, use um código hexadecimal válido")
            }
    
            if (option === "button_color"){
                if (!buttonsNameType[value]){
                    throw new Error(`Use uma das seguintes cores: \`${Object.keys(buttonsNameType).join(", ")}\``)
                }
            }

            if (option === "banner"){
                const isValidURL = value.includes("http") || value.includes("https");
                if (!isValidURL && value) throw new Error("URL inválida, use uma URL válida")
            }
    
            if (option === "channel_id"){
                const guildExists = client.guilds.cache.get(server_id);
                if (!guildExists) throw new Error("Esse bot não está no servidor onde existe esse canal.")
    
                const chananelExists = guildExists.channels.cache.get(value)
                if (!chananelExists) throw new Error("Esse canal não existe nesse servidor.")
            }
    
            databases.sales_config.set(`servers.${server_id}.embed_settings.${option}`, value || false )
            interaction.followUp({content: "✅ | Configuração alterada", ephemeral: true})
        }catch(e){
            interaction.followUp({content: `\`❌\` | ${e.message}`, ephemeral: true})
        }finally{
            await client.easeClient.invokeInteraction(`config_sales_server_embed:${server_id}`, interaction)
        }
    }
})

new InteractionHandler({
    customId: "config_sales_server_embed_preview",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const embed_settings = databases.sales_config.fetch(`servers.${server_id}.embed_settings`);
        if (!embed_settings) return;

        const verified_users = await api_auth_utils.getVerifiedUsers()
        if (!verified_users) throw new Error(`❌ | Erro ao buscar usuarios verificados da API.`)

        const embed = await getSaleEmbed(client, verified_users, server_id)
  
        const components = [
            new CreateRow(
                new CreateButton({label: String(embed_settings.button_label), customId: "buy_members", style: buttonsNameType[embed_settings.button_color] || "Success", emoji: embed_settings.button_emoji || null, disabled: true})
            )
        ]

        return interaction.reply({ embeds: [embed], components, ephemeral: true})
    }
})

new InteractionHandler({
    customId: "config_sales_server_send_message",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const embedSettings = databases.sales_config.fetch(`servers.${server_id}.embed_settings`);
        
        try {
            await interaction.deferReply({ephemeral: true});

            if (!embedSettings) throw new Error(`Configuração não encontrada`);
            if (!embedSettings.channel_id) throw new Error(`O Canal da mensagem ainda não foi configurado`)

            const verified_users = await api_auth_utils.getVerifiedUsers()
            if (!verified_users) throw new Error(`❌ | Erro ao buscar usuarios verificados da API.`)

            const embed = await getSaleEmbed(client, verified_users, server_id)

            const components = [
                new CreateRow(
                    new CreateButton({label: String(embedSettings.button_label), emoji: embedSettings.button_emoji || null, customId: "buy_members", style: "Success"})
                )
            ]

            const guild = await client.guilds.fetch(server_id);
            if (!guild) throw new Error("O Servidor não existe ou o BOT não está nele");

            const channel = await guild.channels.fetch(embedSettings.channel_id);
            if (!channel) throw new Error("O Canal não foi encontrado. Crie um novo e configure-o novamente");

            let editedMessage = null;

            if (embedSettings.message_id){  
                const message = await channel.messages.fetch(embedSettings.message_id).catch( e => null);
                if (message){
                    editedMessage = await message.edit({ embeds: [embed], components }).catch( e => null)
                }
            }

            if (!editedMessage){
                const message = await channel.send({ embeds: [embed], components });
                databases.sales_config.set(`servers.${server_id}.embed_settings.message_id`, message.id)
            }

            await interaction.editReply({ content: "✅ | Mensagem enviada com sucesso!" });
        }catch(e){
            return interaction.editReply({content: `❌ | ${e.message}`, ephemeral: true})
        }

    }
})