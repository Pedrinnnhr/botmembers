import { CreateButton, CreateRow, InteractionHandler, CreateModal, CreateSelect } from "ease-discord-js";
import { databases } from "#utils"
import { AttachmentBuilder } from "discord.js";

new InteractionHandler({
    customId: "config_resale",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const server_info = client.guilds.cache.get(server_id);
        const server_config = databases.sales_config.fetch(`servers.${server_id}`);

        if (!server_config){
            return interaction.reply({ content: "❌ | Configuração do servidor não encontrada", ephemeral: true })
        }

        const description = [
            `# Configurações da Revenda`,
            `- Abaixo configure o sistema de revenda do servidor \`${server_info?.name || "BOT NÃO PRESENTE"}\`\n`,
            `- **Configurações atuais:**`,
            ` - Comissão do servidor: \`${server_config?.commission || 0}%\``,
            ` - Usuarios com permissão: \`${server_config?.resellers?.length || 0}\``,
            ` - Enviar webhook de venda: \`${server_config.resale_webhook ? "SIM" : "NÃO"}\``
        ]

        const components = [
            new CreateRow([
                new CreateButton({ label: "Permissões", customId: `config_resellers:${server_id}`, emoji: "1237510877238919231"}),
                new CreateButton({ label: "Comissão", customId: `config_resellers_set:commission:${server_id}`, emoji: "💸"}),
                new CreateButton({ label: `Webhook (Clique para ${server_config.resale_webhook ? "Desativar" : "Ativar"})`, customId: `config_resellers_toggle_webhook:${server_id}`, emoji: "1237510909291663490"}),
                new CreateButton({ label: "Duvidas", customId: `config_resellers_doubts`, style: "2", emoji: "❔"}),
                new CreateButton({ label: "Voltar", customId: `back_to_sales_config_server:${server_id}`, style: "2", emoji: "1237510920003911791"})
            ]),
        ]

        if (interaction.deferred || interaction.replied){
            return interaction.editReply({ content: description.join("\n"), components, files: [] })
        }else{
            return interaction.update({ content: description.join("\n"), components, files: [] })
        }
    }
})

new InteractionHandler({
    customId: "config_resellers_set",
    useParams: true,

    run: async (client, interaction, configToSet, server_id) => {
        if (configToSet === "commission"){
            const commission = databases.sales_config.fetch(`servers.${server_id}.commission`) || "0";

            const modal = new CreateModal({
                title: "Configuração de Vendas",
                customId: `on_config_resale_modal:${server_id}:commission`,
                inputs: [
                    { type: "text", label: "Qual a nova porcentagem da comissão?", style: "Short", required: true, placeholder: "50%", customId: "new_value0"}
                ]
            })

            commission ? modal.modal.components[0].components[0].data.value = String(commission) : null;
            modal.show(interaction);
        }
        
        if (configToSet === "webhook"){
            const resale_webhook = databases.sales_config.fetch(`servers.${server_id}.resale_webhook`);

            const modal = new CreateModal({
                title: "Configuração de Vendas",
                customId: `on_config_resale_modal:${server_id}:resale_webhook`,
                inputs: [
                    { type: "text", label: "Qual será o novo webhook de revenda?", style: "Short", required: false, placeholder: "https://discord.com/api/webhooks/1252815798666399855/K0t9n6qmtkEMu4sad2", customId: "new_value0"}
                ]
            })

            resale_webhook ? modal.modal.components[0].components[0].data.value = String(resale_webhook) : null;
            modal.modal.components[0].components[0].data.required = false;

            modal.show(interaction);
        };
    }
})

new InteractionHandler({
    customId: `on_config_resale_modal`,
    useParams: true,

    run: async (client, interaction, server_id, newConfig) => {
        try {
            await interaction.deferUpdate()
            let newValue = interaction.fields.getTextInputValue("new_value0");

            if (!server_id) throw new Error("Parametro do id do servidor não recebido.")
            if (!newConfig) throw new Error("Configuração a ser alterada não recebida na interação.")

            if (newConfig === "max_order_porcent" && parseFloat(newValue) > 90){
                throw new Error("O Valor máximo é 90%, para evitar falhas ao vender membros.")
            }

            if (newConfig === "commission"){
                if (isNaN(newValue)){
                    throw new Error("Utilize apenas números!")
                }

                newValue = parseFloat(newValue);
                if (newValue > 100){
                    throw new Error("Utilize um valor menor ou igual a 100.")
                }

                if (newValue < 0){
                    throw new Error("Utilize um valor maior que 0.")
                }
            }

            databases.sales_config.set(`servers.${server_id}.${newConfig}`, newValue || false)
            await client.easeClient.invokeInteraction(`config_resale:${server_id}`, interaction)

            return interaction.followUp({content: `✅ | Configuração alterada com sucesso`, ephemeral: true})
        }catch(e){
            return interaction.followUp({content: `❌ | ${e.message}`, ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "config_resellers_doubts",
    run: async ( client, interaction ) => {
        const description = [
            `> **Permissões:** Configure os usuarios que poderão usar o comando /configloja\n`,
            `> **Webhook:** Adicione uma LOG de venda do servidor para os proprietarios da Auth.\n`,
            `> **Comissão:** Configure a porcentagem que a loja irá ganhar ao realizar uma venda, essa porcentagem **será transferida a conta do mercado pago do revendedor** caso ele configure o mercado pago, ou será acrescentada no saldo do servidor`,
        ]

        return interaction.reply({ content: description.join("\n"), ephemeral: true})
    }
})

new InteractionHandler({
    customId: "config_resellers_toggle_webhook",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const currentState = databases.sales_config.fetch(`servers.${server_id}.resale_webhook`) || false;
        databases.sales_config.set(`servers.${server_id}.resale_webhook`, !currentState);

        await client.easeClient.invokeInteraction(`config_resale:${server_id}`, interaction)
        await interaction.followUp({ content: "✅ | Configuração alterada com sucesso! ", ephemeral: true})
    }
})

new InteractionHandler({
    customId: "config_resellers",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const resellers = databases.sales_config.fetch(`servers.${server_id}.resellers`) || [];

        let resellersString = "" 
        resellers.map((user_id) => {
            resellersString += `- <@${user_id}> - ${user_id}\n`
        })

        const description = [
            "# Revendedores:",
            `${resellersString || "- Nenhum"}`,
        ]

        const components = [
            new CreateRow([
                new CreateButton({ label: "Adicionar membro", customId: `set-resellers:add:${server_id}`, emoji: "1235772114347491339"}),
                new CreateButton({ label: "Remover membro", customId: `set-resellers:remove:${server_id}`, emoji: "1232544264769114157"}),
                new CreateButton({ label: "Voltar", customId: `config_resale:${server_id}`, style: "2", emoji: "1237510920003911791"})
            ])
        ]

        return interaction.update({ content: description.join("\n"), components, files: [] })
    }
})

new InteractionHandler({
    customId: "set-resellers",
    useParams: true,

    run: async ( client, interaction, option, guild_id ) => {
        const components = [
            new CreateRow(
                CreateSelect.UserSelectMenuBuilder({ customId: `on_select_user_reseller:${option}:${guild_id}`, placeholder: "Escolha um usuario"})
            ),
            new CreateRow(
                new CreateButton({ label: "Voltar", customId: `config_resellers:${guild_id}`, style: "Danger"})
            )
        ]

        interaction.update({ embeds: [], content: `- Selecione um usuario para ${option === "add" ? "adicionar" : "remover"} permissão.`, components})
    }
})

new InteractionHandler({
    customId: "on_select_user_reseller",
    useParams: true,

    run: async ( client, interaction, option, guild_id ) => {
        const resellers = databases.sales_config.fetch(`servers.${guild_id}.resellers`) || [];

        if (option === "add"){
            if (resellers.includes(interaction.values[0])){
                return interaction.reply({ content: "❌ | Esse usuario já possui permissão!", ephemeral: true})
            }

            databases.sales_config.push(`servers.${guild_id}.resellers`, interaction.values[0])
            await client.easeClient.invokeInteraction(`config_resellers:${guild_id}`, interaction)

        }else if (option === "remove"){

            if (!resellers.includes(interaction.values[0])){
                return interaction.reply({ content: "❌ | Esse usuario não possui permissão.", ephemeral: true})
            }

            databases.sales_config.pull(`servers.${guild_id}.resellers`, (user_id) => user_id === interaction.values[0], true); // Multiple options = true. (default false)
            await client.easeClient.invokeInteraction(`config_resellers:${guild_id}`, interaction)
        }
    }
})