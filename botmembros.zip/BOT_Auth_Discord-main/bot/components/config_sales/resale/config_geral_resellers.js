import { CreateButton, CreateRow, InteractionHandler, CreateModal, CreateSelect } from "ease-discord-js";
import { ChannelType } from "discord.js"
import { databases } from "#utils"
import defaultConfig from "#root/defaultConfig.json" with { type: "json" }

new InteractionHandler({
    customId: "config-global-resale",
    useParams: true,

    run: async (client, interaction) => {
        const resale_config = databases.sales_config.fetch(`resale_config`) || {};

        const contents = [
            `# Sistema de revenda`,
            `- Configure aqui os **ajustes globais** do sistema de revenda, os valores configurados aqui serão repeitados no painel dos revendedores (comando /configloja).\n`,
        ]

        if (resale_config?.withdraw_notification_data){
            const guild = client.guilds.cache.get(resale_config.withdraw_notification_data.guild);

            if (guild){
                const channel = guild.channels.cache.get(resale_config.withdraw_notification_data.channel)
                if (channel){
                    contents.push(`- Notificações de Saque: \n - ${channel.url}`)
                }else{
                    contents.push("- `⚠️` - O Canal que foi configurado para o bot enviar as notificações de saque não existe mais. Sem ele, seus revendedores não irão poder solicitar o saque.")
                }

            }else{
                contents.push("- `⚠️` - O BOT não está mais presente no servidor que foi configurado para enviar as notificações de saque. Sem ele, seus revendedores não irão poder solicitar o saque.")
            }
        }

        if (!resale_config?.webhook){
            contents.push("- `⚠️` - O Webhook de revenda ainda não foi configurado, sem ele você não receberá logs das vendas de seu revendedores!")
        }

        if (!resale_config.withdraw_notification_data){
            contents.push("- `⚠️` - O Canal de Notificação de Saque ainda não foi definido! sem ele, seus revendedores não irão poder solicitar o saque.")
        }

        const components = new CreateRow([
            new CreateButton({ label: "Webhook Revenda", customId: "config-webhook-resale", emoji: "1237510909291663490"}),
            new CreateButton({ label: "Configurar Limites", customId: "config-resale-limits", emoji: "1256796341082918964"}),
            new CreateButton({ label: "Configurações de Saque", customId: "config-resale-withdraw-interval", emoji: "1257069259746709654"}),
            new CreateButton({ label: "Canal de Notificação de Saque", customId: "config-channel-notification-withdraw", emoji: "1237510909291663490"}),
            new CreateButton({ label: "Voltar", style: "Secondary", customId: "config_sales", emoji: "1237510920003911791"}),
        ])

        return interaction.update({ content: contents.join("\n"), components: [components]})
    }
})

new InteractionHandler({
    customId: "config-webhook-resale",

    run: async (client, interaction) => {
        const resale_webhook = databases.sales_config.fetch(`resale_config.webhook`);

        const modal = new CreateModal({
            title: "Configuração de Vendas",
            customId: `on-submit-modal-resale_webhook`,
            inputs: [
                { type: "text", label: "Qual será o novo webhook de revenda?", style: "Short", required: false, placeholder: "https://discord.com/api/webhooks/1252815798666399855/K0t9n6qmtkEMu4sad2", customId: "new_value0"}
            ]
        })

        resale_webhook ? modal.modal.components[0].components[0].data.value = String(resale_webhook) : null;
        modal.modal.components[0].components[0].data.required = false;

        modal.show(interaction);
    }
})

new InteractionHandler({
    customId: "config-resale-withdraw-interval",
    
    run: async (client, interaction) => {
        const actualConfig = databases.sales_config.fetch("resale_config.withdraw_settings") || {};

        const modal = new CreateModal({
            title: "Configurar Solicitação de Saque",
            customId: "on-submit-modal-withdraw-interval",
            inputs: [
                {type: "text", label: "Intervalo em Dias (para solicitar)", customId: "withdraw-days", style: "Short", required: true},
                {type: "text", label: "Intervalo em Horas (para solicitar)", customId: "withdraw-hours", style: "Short", required: true},
                {type: "text", label: "Intervalo em Minutos (para solicitar)", customId: "withdraw-minutes", style: "Short", required: true},
                {type: "text", label: "Valor minimo (para solicitar)", customId: "withdraw-min-value", style: "Short", required: true},
            ],
        })

        modal.modal.components[0].components[0].data.value = String(actualConfig.withdraw_days || defaultConfig.withdraw_days)
        modal.modal.components[1].components[0].data.value = String(actualConfig.withdraw_hours || defaultConfig.withdraw_hours)
        modal.modal.components[2].components[0].data.value = String(actualConfig.withdraw_minutes || defaultConfig.withdraw_minutes)
        modal.modal.components[3].components[0].data.value = String(actualConfig.withdraw_min_value || defaultConfig.withdraw_min_value)

        modal.show(interaction);
    }
})

new InteractionHandler({
    customId: "on-submit-modal-withdraw-interval",

    run: async (client, interaction) => {
        const withdraw_days = interaction.fields.getTextInputValue("withdraw-days");
        const withdraw_hours = interaction.fields.getTextInputValue("withdraw-hours");
        const withdraw_minutes = interaction.fields.getTextInputValue("withdraw-minutes");
        const withdraw_min_value = interaction.fields.getTextInputValue("withdraw-min-value");

        if (isNaN(withdraw_days) || isNaN(withdraw_hours) || isNaN(withdraw_minutes) || isNaN(withdraw_min_value)){
            return interaction.reply({content: "❌ | Utilize apenas números!", ephemeral: true})
        }

        databases.sales_config.set(`resale_config.withdraw_settings`, {withdraw_days, withdraw_hours, withdraw_minutes, withdraw_min_value});

        await client.easeClient.invokeInteraction("config-global-resale", interaction)
        interaction.followUp({content: "✅ | Valores alterado com sucesso!", ephemeral: true})
    }
})

new InteractionHandler({
    customId: "config-resale-limits",
    
    run: async (client, interaction) => {
        const actualConfig = databases.sales_config.fetch("resale_config.resellers_limits") || {};

        const modal = new CreateModal({
            title: "Configurando limite dos revendedores",
            customId: "on-submit-modal-resale-limits",
            inputs: [
                {type: "text", label: "Preço minimo por membro", customId: "min-price-per-member", style: "Short", required: true},
                {type: "text", label: "Preço máximo por membro", customId: "max-price-per-member", style: "Short", required: true},
                {type: "text", label: "Pedido Minimo", customId: "min-order", style: "Short", required: true},
            ],
        })

        modal.modal.components[0].components[0].data.value = String(actualConfig.min_price_per_member || defaultConfig.min_price_per_member)
        modal.modal.components[1].components[0].data.value = String(actualConfig.max_price_per_member || defaultConfig.max_price_per_member)
        modal.modal.components[2].components[0].data.value = String(actualConfig.min_order || defaultConfig.min_order)

        modal.show(interaction);
    }
})

new InteractionHandler({
    customId: "on-submit-modal-resale-limits",

    run: async (client, interaction) => {
        const max_price_per_member = parseFloat(interaction.fields.getTextInputValue("max-price-per-member"));
        const min_price_per_member = parseFloat(interaction.fields.getTextInputValue("min-price-per-member"));
        const min_order = parseFloat(interaction.fields.getTextInputValue("min-order"));

        if (isNaN(max_price_per_member) || isNaN(min_price_per_member) || isNaN(min_order)){
            return interaction.reply({content: "❌ | Utilize apenas números!", ephemeral: true});
        }

        if (max_price_per_member < min_price_per_member){
            return interaction.reply({content: "❌ | O Preço máximo por membro deve ser maior que o preço minimo.", ephemeral: true});
        }

        // Analisar e ajustar as configurações dos servidores existentes
        const servers = databases.sales_config.fetch("servers");
        Object.keys(servers).forEach((server_id) => {
            const server = servers[server_id];

            console.log(server.price_per_member, min_price_per_member, max_price_per_member)
            if (server.price_per_member > max_price_per_member) {
                databases.sales_config.set(`servers.${server_id}.price_per_member`, max_price_per_member);
            }

            if (server.price_per_member < min_price_per_member) {
                databases.sales_config.set(`servers.${server_id}.price_per_member`, min_price_per_member);
            }
        });

        // Definir os novos limites de revenda
        databases.sales_config.set(`resale_config.resellers_limits`, {max_price_per_member, min_price_per_member, min_order});

        await client.easeClient.invokeInteraction("config-global-resale", interaction);
        interaction.followUp({content: "✅ | Valores alterados com sucesso!", ephemeral: true});
    }
});

new InteractionHandler({
    customId: "config-channel-notification-withdraw",
    run: async (client, interaction) => {
        const contents = [
            `# Notificação de Saque`,
            `- Selecione o canal que será enviado a notificação de saque das suas lojas/revendas. `
        ]

        return interaction.update({content: contents.join("\n"), components: [
            new CreateRow([
                CreateSelect.ChannelSelectMenuBuilder({customId: "select-channel-notication-withdraw", placeholder: "Selecione um canal", type: ChannelType.GuildText}),
            ]),
            new CreateRow([
                new CreateButton({ label: "Voltar", style: "Secondary", customId: "config-global-resale", emoji: "1237510920003911791"}),
            ])
        ]});
    }
})

new InteractionHandler({
    customId: "select-channel-notication-withdraw",
    run: async (client, interaction) => {
        databases.sales_config.set(`resale_config.withdraw_notification_data`, {guild: interaction.guild.id, channel: interaction.values[0]})
        await client.easeClient.invokeInteraction("config-global-resale", interaction)
        interaction.followUp({ content: "✅ | Canal atualizado com sucesso!", ephemeral: true})
    }
})