import { CreateButton, CreateEmbed, CreateRow, CreateSelect, CreateModal, InteractionHandler } from "ease-discord-js";
import { databases } from "#utils"
import axios from "axios"

const check_token_timers = {};

new InteractionHandler({
    customId: "config_sales_config_bank",

    run: async (client, interaction) => {
        const bank_config = databases.sales_config.fetch("bank_config") || {};

        const messages = [
            `# Configuração do Banco`,
            `- **Token:** \n - ${bank_config.mp_token ? ( bank_config.tokenType === "+18" ? `||${bank_config.mp_token}||` : "Token de menor" ) : "Não configurado"}`,
            `- **Modo de venda:** \n - ${bank_config.semi_auto ? "Semi Automatico" : "Automatico"}`,
        ]

        const options = [
            {label: "Token", description: "Altere o token do mercado pago", value: "mp_token", emoji: "🔑"},
            {label: "Modo de venda", description: `Clique para trocar para ${bank_config.semi_auto ? "Automatico" : "Semi-Automatico"}`, value: "sales_mode", emoji: "🔁"}
        ]

        if (bank_config.semi_auto){
            messages.push(`- **Pix Copia e Cola:** \n - ${ bank_config.pix_copy_and_paste || "Não configurado" }`)
            options.push({label: "Pix Copie e Cola", description: "Altere o pix copia e cola (apenas semi automatico)", value: "copy_and_paste", emoji: "📱"})
        }

        const selectComponent = CreateSelect.StringSelectMenuBuilder({
            customId: "on_select_bank_config",
            placeholder: "Selecione alguma opção",
            options
        })

        const components = [
            new CreateRow(selectComponent),
            new CreateRow([
                new CreateButton({ label: "Bloquear Banco", customId: "config_blocked_banks"}),
                new CreateButton({ label: "Voltar", style: "Danger", customId: "config_sales:1"})
            ])
        ]

        if (interaction.replied || interaction.deferred){
            interaction.editReply({content: messages.join("\n"), embeds: [], components})
        }else{
            interaction.update({content: messages.join("\n"), embeds: [], components})
        }
    }
})

new InteractionHandler({
    customId: "on_select_bank_config",

    run: async (client, interaction) => {
        const option = interaction.values?.[0];

        if (option === "mp_token"){
            const components = [
                new CreateRow([
                    new CreateButton({ label: "Token de Maior (+18)", customId: "sales_config_set_tokenType:+18" }),
                    new CreateButton({ label: "Token de Menor (-18)", customId: "sales_config_set_tokenType:-18" }),
                    new CreateButton({ label: "Voltar", customId: "config_sales_config_bank", style: "Danger"})
                ])
            ]

            return interaction.update({content: "- Qual tipo de token deseja usar?", embeds: [], components})
        }

        if (option === "copy_and_paste"){
            const existQrCode = databases.sales_config.fetch("bank_config.copy_and_paste") || null;

            const modal = new CreateModal({
                title: "Configuração do QR-Code",
                customId: `on_config_bank_submit_modal:copy_and_paste`,
                inputs: [
                    { type: "text", label: "Qual novo Pix Copia e Cola?", style: "Short", required: true, placeholder: "LINK AQUI", customId: "new_value0"}
                ],
            });

            existQrCode ? modal.modal.components[0].components[0].data.value = existQrCode : null;
            modal.show(interaction);
            return;
        }

        if (option === "sales_mode"){
            const semi_auto_on = databases.sales_config.fetch("bank_config.semi_auto") || false;
            databases.sales_config.set(`bank_config.semi_auto`, !semi_auto_on)

            await client.easeClient.invokeInteraction("config_sales_config_bank", interaction)
            return;
        }
    }
})

new InteractionHandler({
    customId: "sales_config_set_tokenType",
    useParams: true,

    run: async (client, interaction, tokenType) => {

        if (tokenType === "+18"){
            const bank_config = databases.sales_config.fetch("bank_config") || null;

            const modal = new CreateModal({
                title: "Configuração do token",
                customId: `on_config_bank_submit_modal:mp_token`,
                inputs: [
                    { type: "text", label: "Qual novo token?", style: "Short", required: true, placeholder: "APP_USR-4132923940953-051813-ab5622e7a36-38434353", customId: "new_value0"}
                ],
            });

            bank_config.mp_token && bank_config.tokenType === "+18" ? modal.modal.components[0].components[0].data.value = bank_config.mp_token : null;
            modal.show(interaction);
            return;

        }else if (tokenType === "-18"){

            const components = [
                new CreateRow([
                    new CreateButton({ label: "Autorizar Mercado Pago", style: 5, url: `https://api.barraapps.cloud/oauth/mp/${interaction.guild.id}`}),
                    new CreateButton({ label: "Voltar", style: "Danger", customId: "back_to_config_token"})
                ])
            ]

            if (check_token_timers[interaction.user.id]){
                clearInterval(check_token_timers[interaction.user.id].interval)
                clearInterval(check_token_timers[interaction.user.id].timeout)
            }

            var timeLimit = 5 * 60 * 1000;

            const forFormat = Date.now() + timeLimit;
            const timestamp = Math.floor(forFormat / 1000)

            check_token_timers[interaction.user.id] = {};
            check_token_timers[interaction.user.id].interval = setInterval(() => {veryfyMinorToken(interaction)}, 5000);

            check_token_timers[interaction.user.id].timeout = setTimeout(() => {
                clearInterval(check_token_timers[interaction.user.id]?.interval)
                delete check_token_timers[interaction.user.id];
            }, timeLimit)
        
            return interaction.update({ content: `Autorizar seu **Mercado Pago** á **Appsystems**\n\n**Status:** Aguardando você autorizar.\nEssa mensagem vai expirar em <t:${timestamp}:R>`, components, ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "on_config_bank_submit_modal",
    useParams: true,

    run: async (client, interaction, option) => {
        const valueToChange = interaction.fields.getTextInputValue("new_value0");

        if (option === "block_bank"){
            databases.sales_config.set(`bank_config.blocked_banks`, valueToChange)
            return;
        }

        if (option === "mp_token"){
            await interaction.deferUpdate({ephemeral: true})

            const isValidToken = await axios.get(`https://api.mercadopago.com/v1/payment_methods`, { headers: {
                Authorization: `Bearer ${valueToChange}`
            }}).catch(e => false)

            if (!isValidToken){
                return interaction.followUp({content: "❌ | Token inválido!", ephemeral: true})
            }

            databases.sales_config.set(`bank_config.mp_token`, valueToChange)
            databases.sales_config.set(`bank_config.tokenType`, "+18")

            await interaction.followUp({content: "✅ | Token alterado!", ephemeral: true})
            await client.easeClient.invokeInteraction("config_sales_config_bank", interaction)
        }

        if (option === "copy_and_paste"){
            await interaction.deferUpdate();

            databases.sales_config.set(`bank_config.pix_copy_and_paste`, valueToChange)

            await client.easeClient.invokeInteraction("config_sales_config_bank", interaction)
            await interaction.followUp({content: "✅ | Pix alterado com sucesso!", ephemeral: true})
        }
    }
})

const veryfyMinorToken = async (interaction) => {
    try {
        const response = await axios.get(`https://api.barraapps.cloud/oauth/mp/token/${interaction.guild.id}`, { headers: { authorization: "batata123"}});
        const geral = response.data;

        const token = geral.access_token;

        if (token){

            if (check_token_timers[interaction.user.id]){
                clearInterval(check_token_timers[interaction.user.id].interval);
                clearTimeout(check_token_timers[interaction.user.id].timeout);
                delete check_token_timers[interaction.user.id];
            }

            databases.sales_config.set(`bank_config.mp_token`, token);
            databases.sales_config.set(`bank_config.tokenType`, "-18");

            const components = [ 
                new CreateRow([
                    new CreateButton({ label: "Voltar", style: "Danger", customId: "config_sales_config_bank"})
                ])
            ]

            interaction.editReply({ content: `- Autorização bem sucedida! Você já pode usar seu token.`, components})
        }
    }catch(e){
        console.log("Erro ao verificar token!, tentando novamente ... " + e.message)
    }
};

new InteractionHandler({
    customId: "back_to_config_token",
    run: async (client, interaction) => {
        interaction.values = [];
        interaction.values[0] = "mp_token"

        if (check_token_timers[interaction.user.id]){
            clearInterval(check_token_timers[interaction.user.id].interval);
            clearTimeout(check_token_timers[interaction.user.id].timeout);
            delete check_token_timers[interaction.user.id];
        }

        client.easeClient.invokeInteraction("on_select_bank_config", interaction)
    }
})