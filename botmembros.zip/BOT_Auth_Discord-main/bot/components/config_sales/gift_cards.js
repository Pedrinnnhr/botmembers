import { CreateButton, CreateModal, CreateRow, InteractionHandler } from "ease-discord-js";
import { api_auth_utils, databases } from "#utils";
import { AttachmentBuilder } from "discord.js"

const maxGiftCardPerApplication = 500;
const defaultMessage = "Olá, você acaba de adquirir ${members_quantity} membros reais de discord ! para puxar seus membros acesse: ${siteToRedeem}/${code}"
const siteToRedeem = `https://www.barraapps.cloud/gifts/redeem`


new InteractionHandler({
    customId: "config-gift-cards",

    run: async (client, interaction) => {
        const gift_cards = await api_auth_utils.getAllGiftCards() || [];
        const groups = [];

        gift_cards.map((gift) => {
            if (!groups.includes(gift.group)){
                groups.push(gift.group)
            }
        })

        const contents = [
            `# Gift Cards`,
            `- Crie presentes para ser resgatados a partir de um link`,
            ` - Essa é excelente opção para quem deseja vender no automatico usando lojas como a \`GGMAX\`\n`,
            `- \`🎁\` GiftCards: **${gift_cards.length} unidades**`,
            `- \`⭐\` Grupos criados: \`${groups.join(",")}\``,
        ]

        const components = [
            new CreateRow([
                new CreateButton({ label: "Adicionar gift", customId: "add-gift-stock", emoji: "1235772114347491339"}),
                new CreateButton({ label: "Estoque", customId: "download-all-gift", emoji: "1237511034722320424"}),
                new CreateButton({ label: "Remover gift", customId: "remove-gift", emoji: "1227681755297874062"}),
                new CreateButton({ label: "Config Webhook", style: "2", customId: "config-webhook", emoji: "1237510877238919231"}),
                new CreateButton({ label: "Voltar", style: 2, customId: "config_sales", emoji: "1237510920003911791"})
            ]),
        ]

        return await interaction.update({ content: contents.join("\n"), files: [], components})
    }
})

new InteractionHandler({
    customId: "config-webhook",

    run: async (client, interaction) => {
        const application_config = await api_auth_utils.getApplicationConfig();
        if (!application_config) return interaction.reply({ content: "Não foi possivel encontrar a configuração da sua aplicação", ephemeral: true })

        const modal = new CreateModal({
            title: "Configurando webhook",
            customId: "on-submit-gift-config-webhook",
            inputs: [
                {type: "text", label: "Configurando webhook", customId: "value0", style: "Short"},
            ],
        })

        application_config?.gift_card_webhook ? modal.modal.components[0].components[0].data.value = application_config.gift_card_webhook : null;
        return await modal.show(interaction)
    }
})

new InteractionHandler({
    customId: "on-submit-gift-config-webhook",

    run: async (client, interaction) => {
        const newValue = interaction.fields.getTextInputValue("value0");

        try {
            if (!newValue) throw new Error("Você precisa fornecer um webhook.")

            const webhookValid = newValue.includes("discord.com/api/webhooks/");
            if (!webhookValid) throw new Error(`Esse webhook é inválido`);

            await api_auth_utils.updateApplicationConfig({gift_card_webhook: newValue});
            return interaction.reply({ content: `✅ | Webhook alterado com sucesso! `, ephemeral: true})
        }catch(e){
            return interaction.reply({ content: `❌ | ${e.response?.data?.message || e.message}`, ephemeral: true })
        }
    }
})

new InteractionHandler({
    customId: "clear-all-gifts",
    useParams: true,

    run: async (client, interaction, confirmed) => {
        if (!confirmed){
            const contents = [
                `# Limpando estoque`,
                `- Você realmente deseja excluir todos os gift cards ? Esse ato não poderá ser revertido.`
            ]

            const components = [
                new CreateRow([
                    new CreateButton({ label: "Sim", customId: "clear-all-gifts:true", emoji: "1237510996537507963"}),
                    new CreateButton({ label: "Não, quero voltar", style: "Danger", customId: "download-all-gift", emoji: "1237511012425404509" })
                ])
            ]

            return await interaction.update({ content: contents.join("\n"), files: [], components})
        };

        try {
            const exclude = await api_auth_utils.removeAllGiftCard();
            await client.easeClient.invokeInteraction("download-all-gift", interaction)
            return interaction.followUp({ content: `✅ | \`${exclude.quantity}\` Gifts foram excluidos com sucesso!`, ephemeral: true})
        }catch(e){
            await client.easeClient.invokeInteraction("download-all-gift", interaction)
            return interaction.followUp({ content: `❌ | ${e.response?.data?.message || e.message}`, ephemeral: true })
        }
    }
})

new InteractionHandler({
    customId: "download-all-gift",
    run: async (client, interaction) => {
        const currentStructure = databases.config.fetch("gift_message_structure") || defaultMessage;
        const gift_cards = await api_auth_utils.getAllGiftCards() || [];

        const contents = [
            `# Baixando lista de presentes`,
            `- Configure aqui o formato que você deseja baixar seus gifts`,
            ` - Você possui \`${gift_cards.length}\` Gift Cards ativo.\n`,
            `- Variaveis: `,
            " - ${members_quantity} = Quantidade de membros",
            " - ${code} = Código",
            " - ${siteToRedeem} = Site par resgatar",
            " - ${group} = Grupo",
            " - ${createdAt} = Data da criação",
            " - ${redirect_url} = URL de redirencionamento\n",
            `- Formato Atual:\n -   \`${currentStructure}\``
        ]

        const components = [
            new CreateRow([
                new CreateButton({ label: "Configurar Formato", customId: "gift-config-message", emoji: "1237510877238919231"}),
                new CreateButton({ label: "Baixar Lista Formatada", customId: "download-gift-stock", emoji: "1237511034722320424"}),
                new CreateButton({ label: "Baixar Lista JSON", customId: "download-gift-stock2", emoji: "1237511034722320424"}),
                new CreateButton({ label: "Limpar estoque", style: "Danger", customId: "clear-all-gifts", emoji: "1237510974685319220"}),
                new CreateButton({ label: "Voltar", style: "2", customId: "config-gift-cards", emoji: "1237510920003911791" })
            ])
        ]

        return await interaction.update({ content: contents.join("\n"), files: [], components})
    }
})

new InteractionHandler({
    customId: "gift-config-message",

    run: async (client, interaction) => {
        const message = databases.config.fetch("gift_message_structure") || defaultMessage;

        const modal = new CreateModal({
            title: "Configurando mensagem",
            customId: "on-submit-gift-config-message",
            inputs: [
                {type: "text", label: "Configurando mensagem", customId: "value0", style: "Paragraph"},
            ],
        })

        modal.modal.components[0].components[0].data.value = message;
        return await modal.show(interaction)
    }
})

new InteractionHandler({
    customId: "on-submit-gift-config-message",

    run: async (client, interaction) => {
        const newMessage = interaction.fields.getTextInputValue("value0");
        if (!newMessage) return;

        databases.config.set("gift_message_structure", String(newMessage));
        await client.easeClient.invokeInteraction("download-all-gift", interaction)
        await interaction.followUp({ content: `✅ | Configuração bem sucedida`, ephemeral: true})
    }
})

new InteractionHandler({
    customId: "download-gift-stock",
    run: async (client, interaction) => {
        const structure = databases.config.fetch("gift_message_structure") || defaultMessage;
        const gift_cards = await api_auth_utils.getAllGiftCards() || [];

        const gift_groups = {};
        let txtContent = "";

        gift_cards.map( gift => {
            if (!gift_groups[gift.group]){
                gift_groups[gift.group] = [];
            }

            gift_groups[gift.group].push(gift)
        })

        // Ordena os grupos com base na quantidade de membros (members_quantity)
        const orderedGroups = Object.entries(gift_groups).sort(([,a], [,b]) => {
            const sumA = a.reduce((acc, curr) => acc + curr.members_quantity, 0);
            const sumB = b.reduce((acc, curr) => acc + curr.members_quantity, 0);
            return sumB - sumA; // Ordena do maior para o menor
        });

        for (const [group, giftCards] of orderedGroups) {
            txtContent += `\n\n[[ GRUPO: ${group} ]]\n\n`;

            giftCards.forEach(gift => {
                let message = structure;
                message = message.replace("${members_quantity}", gift.members_quantity);
                message = message.replace("${code}", gift.code);
                message = message.replace("${redirect_url}", gift.redirect_url);
                message = message.replace("${createdAt}", gift.createdAt);
                message = message.replace("${group}", gift.group);
                message = message.replace("${siteToRedeem}", siteToRedeem);

                txtContent += `${message}\n`;
            });
        }

        const attachment = new AttachmentBuilder(Buffer.from(txtContent, "utf-8"), {name: "giftcards.txt"});
        await interaction.reply({ content: `✅ | Segue abaixo os gift cards ativos`, files: [attachment], ephemeral: true });
    }
})

new InteractionHandler({
    customId: "download-gift-stock2",
    run: async (client, interaction) => {
        const gift_cards = await api_auth_utils.getAllGiftCards() || [];
        const giftCardsContent = JSON.stringify(gift_cards, null, 2);

        const buffer = Buffer.from(giftCardsContent, 'utf-8');
        const attachment = new AttachmentBuilder(buffer, {name: `giftcards.json`});

        await interaction.reply({ content: `✅ | Segue abaixo os gift cards ativos`, files: [attachment], ephemeral: true });
    }
})



new InteractionHandler({
    customId: "add-gift-stock",
    run: async (client, interaction) => {
        const modal = new CreateModal({
            title: "Adicionando estoque gift",
            customId: "submit-stock-gift",
            inputs: [
                {type: "text", label: "Grupo", customId: "group", style: "Short", placeholder: "GGMAX"},
                {type: "text", label: "Quantidade de membros", customId: "members_quantity", style: "Short", placeholder: "100"},
                {type: "text", label: "Quantidade de presentes", customId: "gift_quantity", style: "Short", placeholder: "1"},
                {type: "text", label: "Redirecionamento após resgate (opcional, URL)", customId: "redirect_url", style: "Short", placeholder: "https://barraapps.cloud/discord", required: false},
            ],
        })

        modal.modal.components[3].components[0].data.required = false;

        return await modal.show(interaction)
    }
})

new InteractionHandler({
    customId: `submit-stock-gift`,

    run: async (client, interaction) => {
        const group = interaction.fields.getTextInputValue("group");
        const members_quantity = interaction.fields.getTextInputValue("members_quantity");
        const gift_quantity = interaction.fields.getTextInputValue("gift_quantity");
        const redirect_url = interaction.fields.getTextInputValue("redirect_url");

        try {
            const gift_cards = await api_auth_utils.getAllGiftCards() || [];          
            if ((gift_cards.length + parseInt(gift_quantity)) > maxGiftCardPerApplication){
                throw new Error(`O Limite máximo de gift cards é ${maxGiftCardPerApplication}. você ainda pode adicionar \`${maxGiftCardPerApplication - gift_cards.length}\` Gifts cards, para liberar mais espaço exclua alguns gift ou limpe os gift resgatados`)
            }
            
            if (!group || !members_quantity || !gift_quantity){
                throw new Error("Preencha as informações corretamente!")
            }

            if (isNaN(members_quantity)) throw new Error(`Insira um numero válido com a quantidade de membros`)
            if (isNaN(gift_quantity)) throw new Error(`Insira um numero válido com a quantidade de gifts`)

            const listToCreateGif = []

            for (let i = 0; i < parseInt(gift_quantity); i++) {
                listToCreateGif.push({ members_quantity, group, redirect_url});
            }

            await api_auth_utils.addGiftCard(listToCreateGif);
            await client.easeClient.invokeInteraction("config-gift-cards", interaction)
            return interaction.followUp({ content: `✅ | Foi adicionado \`${gift_quantity}\` Gift cards com sucesso. Clique em "Estoque" para pegar os links. `, ephemeral: true})
        }catch(e){
            return interaction.reply({ content: `❌ | ${e.response?.data?.message || e.message}`, ephemeral: true })
        }
    }
})

new InteractionHandler({
    customId: "remove-gift",

    run: async (client, interaction) => {
        const contents = [
            `# Removendo GIFT Card`,
            `- Você pode excluir gift card em massa a partir do \`GRUPO\` dele ou remover apenas um gift pelo \`Código\` dele.`,
            `- Selecione a opção abaixo de como deseja proceder\n`,
            `\`⚠️\` Essa ação não poderá ser desfeita !`
        ]

        const components = [
            new CreateRow([
                new CreateButton({ label: "Remover por Código (Unitario)", style: "Danger", customId: "remove-gift-by:code", }),
                new CreateButton({ label: "Remover por Grupo (Em massa)", style: "Danger", customId: "remove-gift-by:group", }),
                new CreateButton({ label: "Voltar", style: 2, customId: "config-gift-cards", emoji: "1237510920003911791"})
            ])
        ]

        return await interaction.update({ content: contents.join("\n"), files: [], components})
    }
})

new InteractionHandler({
    customId: "remove-gift-by",
    useParams: true,

    run: async (client, interaction, method) => {
        if (method === "code"){

            const modal = new CreateModal({
                title: "Remover Gift por Código",
                customId: "submit-remove-gift-by:code",
                inputs: [
                    {type: "text", label: "Código do GIFT a ser excluido", customId: "value0", style: "Short", placeholder: "7929e75c-13e5-4eed-bed4-0a2e70fe4e6c"},
                ],
            })
    
            return await modal.show(interaction)

        }else if (method === "group"){
            const modal = new CreateModal({
                title: "Remover Gift pelo Grupo",
                customId: "submit-remove-gift-by:group",
                inputs: [
                    {type: "text", label: "Grupo do GIFT a ser excluido", customId: "value0", style: "Short", placeholder: "GRUPO01"},
                ],
            })
    
            return await modal.show(interaction)
        }
    }
})

new InteractionHandler({
    customId: "submit-remove-gift-by",
    useParams: true,

    run: async (client, interaction, method) => {
        const value = interaction.fields.getTextInputValue("value0");

        if (method === "code"){

            try {
                await api_auth_utils.removeGiftCardByCode(value);
                return interaction.reply({ content: `✅ | Gift \`${value}\` excluido com sucesso!`, ephemeral: true })
            }catch(e){
                return interaction.reply({ content: `❌ | Erro: ${e.response?.data?.message || e.message}`, ephemeral: true})
            }

        }else if (method === "group"){
            try {
                const exclude = await api_auth_utils.removeGiftCardInMassByGroup(value);
                return interaction.reply({ content: `✅ | \`${exclude.quantity}\` Gifts foram excluidos com sucesso!`, ephemeral: true})
            }catch(e){
                return interaction.reply({ content: `❌ | Erro: ${e.response?.data?.message || e.message}`, ephemeral: true})
            }
        }
    }
})