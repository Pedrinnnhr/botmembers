import { CreateButton, CreateEmbed, CreateModal, CreateRow, CreateSelect, InteractionHandler } from "ease-discord-js";
import { databases, getUserHasPermissionByID } from "#utils"
import defaultConfig from "#root/defaultConfig.json" with { type: "json" };

new InteractionHandler({
    customId: "config_sales_select_server",

    run: async (client, interaction) => {
        const bank_config = databases.sales_config.fetch("bank_config")

        if (!bank_config){
            return interaction.reply({ content: `❌ | Antes de configurar os servidores, configure o banco primeiro.`, ephemeral: true})
        }

        const configured_servers = databases.sales_config.fetch("servers") || [];

        const server_id = interaction.values[0]
        const existServer = configured_servers[server_id] || false;

        if (!existServer){
            initilizeNonExistingServer(client, interaction, server_id)
        }else{
            initilizeExistingServer(client, interaction, server_id, existServer)
        }
    }
})

async function initilizeExistingServer(client, interaction, server_id, server_config){
    const server_info = await client.guilds.cache.get(server_id);

    const messages = [
        `# Configurações do servidor`,
        `- Aqui você poderá configurar a mensagem, preços e outras opções relacionada a venda de membros no servidor \`${server_info?.name || "BOT NÃO PRESENTE"}\`\n`,
        `- Configurações atuais:`,
        ` - Vendas: ${server_config.sales_on ? "`Ativa`" : "`Desativado`"}`,
        ` - Sistema de Refil: ${server_config.refil_on ? "`Ativo`" : "`Desativado`"}`,
        ` - Pedido minimo: \`${server_config.minimum_order} Membros\``,
        ` - Cargo de cliente: \`${server_config.clientRole || "Não configurado"}\``,
        ` - Cargo da equipe: \`${server_config.teamRole || "Não configurado"}\``,
        ` - Porcentagem máxima por pedido: \`${server_config.max_order_porcent}%\``,
        ` - Preço por membro: \`${parseFloat(server_config.price_per_member).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL', maximumSignificantDigits: 3})}\``,
        ` - Preço por membro (com refil): \`${parseFloat(server_config.price_per_member_refil).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL', maximumSignificantDigits: 3})}\``,
    ]

    if (!server_config.webhook){
        messages.push(`\n\`⚠️\` **Webhook não foi configurado, sem ele você não receberá notificação das suas vendas!**`)
    }

    const selectComponent = CreateSelect.StringSelectMenuBuilder({
        customId: `sales_config_server_select:${server_id}`,
        placeholder: `Selecione alguma configuração`,
        options: [
            { label: "Status", description: `Clique para ${server_config.sales_on ? "Desativar" : "Ativar"} as vendas nesse servidor`, emoji: server_config.sales_on ? "🟢":"🔴", value: "sales_on"},
            { label: "Webhook", description: `Receba as Logs de pagamento realizada no seu servidor`, emoji: "1237510909291663490", value: "webhook"},
            { label: "Sistema de Refil", description: `Clique para ${server_config.refil_on ? "Desativar" : "Ativar"} o sistema de refil nesse servidor`, emoji: server_config.refil_on ? "🟢":"🔴", value: "refil_on"},
            { label: "Pedido minimo", description: `Altere o valor minimo que o cliente pode comprar`, emoji: "🤏🏼", value: "minimum_order"},
            { label: "Cargo de cliente", description: `Altere o cargo da cliente do seu servido`, emoji: "👩‍👧‍👦", value: "clientRole"},
            { label: "Cargo da equipe", description: `Altere o cargo de equipe do seu servidor`, emoji: "👔", value: "teamRole"},
            { label: "Porcentagem máxima de venda", description: `Quantos porcento dos membros da auth você quer vender?`, emoji: "🔣", value: "max_order_porcent"},
            { label: "Configurar embed", description: "Configure como será o anuncio de venda dos membros", emoji: "📝", value: "embed"},
            { label: "Preço por membro", description: "Defina por qual valor você vai vender cada membro", emoji: "💵", value: "price_per_member"},
            { label: "Preço por membro com refil", description: "Defina por qual valor você vai vender cada membro com refil", emoji: "💶", value: "price_per_member_refil"},
        ]
    })

    const components = [
        new CreateRow(selectComponent),
        new CreateRow([
            new CreateButton({label: "Estatisticas", customId: `statistics:${server_id}`, emoji: "1256804128311738380"}),
            new CreateButton({label: "Configurar Revenda", customId: `config_resale:${server_id}`, emoji: "1256804158242160692"}),
            new CreateButton({label: "Excluir configuração", style: "Danger", customId: `try_exclude_sales_config_server:${server_id}`, emoji: "1232544264769114157"}),
            new CreateButton({label: "Voltar", style: "2", customId: "config_sales", emoji: "1237510920003911791"})
        ])
    ]

    if (interaction.replied || interaction.deferred){
        interaction.editReply({ content: messages.join("\n"), embeds: [], files: [], components, ephemeral: true})
    }else{
        interaction.update({ content: messages.join("\n"), embeds: [], files: [], components, ephemeral: true})
    }
}

async function initilizeNonExistingServer(client, interaction, server_id){
    const resaleConfig = databases.sales_config.fetch("resale_config");

    const firstConfig = {
        sales_on: true,
        minimum_order: resaleConfig?.resellers_limits?.min_order || defaultConfig.min_order,
        max_order_porcent: 80,
        price_per_member: resaleConfig?.resellers_limits?.min_price_per_member || defaultConfig.min_price_per_member,
        price_per_member_refil: 0.06,
        resale_webhook: true,
        commission: 50,
        refil_on: false,
        embed_settings: {
            title: "Compra de M3mbr0s",
            button_label: "Comprar membro",
            banner: false,
            description: `- M3mbr0s Reais\n- 100% Brasileiros\n- Qualidade Premium\n- Melhor preço do mercado\n- Entrega rápida`,
            color: "#0098d9",
            auto_update: true,
        },
    }

    const components = [
        new CreateRow([
            new CreateButton({label: "Configurar", emoji: "1237510877238919231", onClick: (client, interaction) => {
                databases.sales_config.set(`servers.${server_id}`, firstConfig);
                client.easeClient.invokeInteraction(`back_to_sales_config_server:${server_id}`, interaction)
            }}),
            new CreateButton({label: "Sair do servidor", style: "Danger", emoji: "1232544264769114157", customId: `leave_main_bot_server:${server_id}`}),
            new CreateButton({label: "Não, desejo voltar", style: "2", emoji: "1237510920003911791",  customId: "config_sales"})
        ])
    ]

    if (interaction.replied || interaction.deferred){
        interaction.editReply({ content: `- Parece que esse servidor ainda não foi configurado, deseja iniciar configuração dele agora?`, embeds: [], components})
    }else{
        interaction.update({ content: `- Parece que esse servidor ainda não foi configurado, deseja iniciar configuração dele agora?`, embeds: [], components})
    }
}

new InteractionHandler({
    customId: "try_exclude_sales_config_server",
    useParams: true,

    run: async (client, interaction, guild_id) => {
        if (!guild_id)
            return;

        const components = [
            new CreateRow([
                new CreateButton({ label: "Sim", customId: `confirm_exclude_sales_config_server:${guild_id}`, emoji: "1237510996537507963"}),
                new CreateButton({ label: "Não, quero voltar", customId: `back_to_sales_config_server:${guild_id}`, style: "Danger", emoji: "1237511012425404509"})
            ])
        ]

        interaction.update({ content: `- Você realmente deseja excluir as configurações desse servidor ? esse procedimento será permanente.`, embeds: [], components })
    }
})

new InteractionHandler({
    customId: "confirm_exclude_sales_config_server",
    useParams: true,

    run: async (client, interaction, guild_id) => {
        if (!guild_id){
            return;
        }

        databases.sales_config.delete(`servers.${guild_id}`)
        await client.easeClient.invokeInteraction("config_sales", interaction)
    }
})

new InteractionHandler({
    customId: "leave_main_bot_server",
    useParams: true,

    run: async (client, interaction, guild_id) => {
        
        const guild = client.guilds.cache.get(guild_id)
        if (!guild){
            return interaction.reply({ content: "❌ | Servidor não encontrado! ", ephemeral: true})
        }

        await guild.leave()
        client.easeClient.invokeInteraction("config_sales", interaction)
    }
})

new InteractionHandler({
    customId: "back_to_sales_config_server",
    useParams: true,

    run: async (client, interaction, server_id) => {
        interaction.values = [];
        interaction.values.push(server_id)
        client.easeClient.invokeInteraction("config_sales_select_server", interaction)
    }
})

new InteractionHandler({
    customId: "sales_config_server_select",
    useParams: true, 

    run: async (client, interaction, server_id) => {
        const option = interaction.values[0];

        const modalBaseConfig = {
            title: "Configuração de Vendas",
            customId: `on_config_sales_server_modal:${server_id}`,
            inputs: [
                { type: "text", label: "", style: "Short", required: true, placeholder: "", customId: "new_value0"}
            ]
        }
        
        if (option === "price_per_member"){
            const price_per_member = databases.sales_config.fetch(`servers.${server_id}.price_per_member`)

            modalBaseConfig.customId += `:price_per_member`
            modalBaseConfig.inputs[0].label = "Digite o novo preço por membro";
            modalBaseConfig.inputs[0].placeholder = "Digite o novo preço por membro";

            const modal = new CreateModal(modalBaseConfig);
            price_per_member ? modal.modal.components[0].components[0].data.value = String(price_per_member) : null;

            return await modal.show(interaction);
        }

        if (option === "price_per_member_refil"){
            const price_per_member_refil = databases.sales_config.fetch(`servers.${server_id}.price_per_member_refil`)

            modalBaseConfig.customId += `:price_per_member_refil`
            modalBaseConfig.inputs[0].label = "Digite o novo preço por membro com refil";
            modalBaseConfig.inputs[0].placeholder = "Digite o novo preço por membro com refil";

            const modal = new CreateModal(modalBaseConfig);
            price_per_member_refil ? modal.modal.components[0].components[0].data.value = String(price_per_member_refil) : null;

            return await modal.show(interaction);
        }
        
        
        if (option === "max_order_porcent"){
            const max_order_porcent = databases.sales_config.fetch(`servers.${server_id}.max_order_porcent`)

            modalBaseConfig.customId += `:max_order_porcent`
            modalBaseConfig.inputs[0].label = "Digite a nova porcentagem";
            modalBaseConfig.inputs[0].placeholder = "80%";

            const modal = new CreateModal(modalBaseConfig);
            max_order_porcent ? modal.modal.components[0].components[0].data.value = String(max_order_porcent) : null;

            return await modal.show(interaction);
        }
        
        if (option === "minimum_order"){
            const minimum_order = databases.sales_config.fetch(`servers.${server_id}.minimum_order`)

            modalBaseConfig.customId += `:minimum_order`
            modalBaseConfig.inputs[0].label = "Digite a quantidade do pedido minimo";
            modalBaseConfig.inputs[0].placeholder = "100";

            const modal = new CreateModal(modalBaseConfig);
            minimum_order ? modal.modal.components[0].components[0].data.value = String(minimum_order) : null;

            return await modal.show(interaction);
        }

        if (option === "sales_on"){
            await interaction.deferUpdate();

            const sales_on = databases.sales_config.fetch(`servers.${server_id}.sales_on`);

            databases.sales_config.set(`servers.${server_id}.sales_on`, !sales_on)

            const backCustomID = getUserHasPermissionByID(interaction.user.id) ? `back_to_sales_config_server:${server_id}` : `invoke-configloja-command`;
            await client.easeClient.invokeInteraction(backCustomID, interaction)

            await interaction.followUp({content: `✅ | Vendas ${sales_on ? "Desativada" : "Ativada"}`, ephemeral: true})

            return;
        }

        if (option === "refil_on"){
            await interaction.deferUpdate();

            const refil_on = databases.sales_config.fetch(`servers.${server_id}.refil_on`);

            databases.sales_config.set(`servers.${server_id}.refil_on`, !refil_on)

            const backCustomID = getUserHasPermissionByID(interaction.user.id) ? `back_to_sales_config_server:${server_id}` : `invoke-configloja-command`;
            await client.easeClient.invokeInteraction(backCustomID, interaction)
            await interaction.followUp({content: `✅ | Sistema de refil ${refil_on ? "Desativado" : "Ativado"}`, ephemeral: true})

            return;
        }

        if (option === "teamRole"){
            const teamRole = databases.sales_config.fetch(`servers.${server_id}.teamRole`)

            modalBaseConfig.customId += `:teamRole`
            modalBaseConfig.inputs[0].label = "ID do cargo de equipe (vazio pra remover)";
            modalBaseConfig.inputs[0].placeholder = "1247728313519046689";
            modalBaseConfig.inputs[0].required = false;

            const modal = new CreateModal(modalBaseConfig);
            modal.modal.components[0].components[0].data.required = false;

            teamRole ? modal.modal.components[0].components[0].data.value = String(teamRole) : null;

            return await modal.show(interaction);
        }

        if (option === "clientRole"){
            const clientRole = databases.sales_config.fetch(`servers.${server_id}.clientRole`)

            modalBaseConfig.customId += `:clientRole`
            modalBaseConfig.inputs[0].label = "ID do cargo de cliente (vazio pra remover)";
            modalBaseConfig.inputs[0].placeholder = "1247728313519046689";
            modalBaseConfig.inputs[0].required = false;

            const modal = new CreateModal(modalBaseConfig);
            modal.modal.components[0].components[0].data.required = false;

            clientRole ? modal.modal.components[0].components[0].data.value = String(clientRole) : null;

            return await modal.show(interaction);
        }

        if (option === "webhook"){
            const server_config = databases.sales_config.fetch(`servers.${server_id}`);
            if (!server_config){
                return interaction.reply({ content: `❌ | Configuração do servidor não encontrada`, ephemeral: true })
            }
    
            const modal = new CreateModal({
                title: "Configuração de Vendas",
                customId: `on_config_sales_server_modal:${server_id}:webhook`,
                inputs: [
                    { type: "text", label: "Qual novo webhook?", style: "Short", required: true, placeholder: "https://discord.com/api/webhooks/1250961970849382612/8ABkAjipdpJPsOD", customId: "new_value0"}
                ]
            })
    
            server_config.webhook ? modal.modal.components[0].components[0].data.value = String(server_config.webhook) : null;
            await modal.show(interaction)
        }

        if (option === "embed"){
            client.easeClient.invokeInteraction(`config_sales_server_embed:${server_id}`, interaction)
            return;
        }
    }
})

new InteractionHandler({
    customId: `on_config_sales_server_modal`,
    useParams: true,

    run: async (client, interaction, server_id, newConfig) => {
        const resaleConfig = databases.sales_config.fetch("resale_config") || {};
        const isApplicationOwner = getUserHasPermissionByID(interaction.user.id);
        const backCustomID = isApplicationOwner ? `back_to_sales_config_server:${server_id}` : `invoke-configloja-command`;

        try {
            await interaction.deferUpdate()
            let newValue = interaction.fields.getTextInputValue("new_value0");

            if (!server_id) throw new Error("Parametro do id do servidor não recebido.")
            if (!newConfig) throw new Error("Configuração a ser alterada não recebida na interação.")

            if (newConfig === "max_order_porcent" && parseFloat(newValue) > 90){
                throw new Error("O Valor máximo é 90%, para evitar falhas ao vender membros.")
            }

            if (newConfig === "webhook"){
                const webhookValid = newValue.includes("discord.com/api/webhooks/");
                if (!webhookValid) throw new Error(`Esse webhook é inválido`);
            }

            if (newConfig === "price_per_member_refil" || newConfig === "price_per_member"){
                newValue = newValue.replace(",", ".")

                if (isNaN(newValue)){
                    throw new Error("Use um numero válido.")
                }

                newValue = parseFloat(newValue)
            }

            if (newConfig === "price_per_member"){
                if (!isApplicationOwner && newValue < parseFloat(resaleConfig?.resellers_limits?.min_price_per_member || defaultConfig.min_price_per_member)){
                    throw new Error(`O Valor deve ser no minimo R$ ${resaleConfig?.resellers_limits?.min_price_per_member || defaultConfig.min_price_per_member} por membro!`)
                }

                if (!isApplicationOwner && newValue > parseFloat(resaleConfig?.resellers_limits?.max_price_per_member || defaultConfig.max_price_per_member)){
                    throw new Error(`O Valor deve ser no máximo R$ ${resaleConfig?.resellers_limits?.max_price_per_member || defaultConfig.max_price_per_member} por membro!`)
                }
            }

            if (newConfig === "minimum_order"){
                if (isNaN(newValue)){
                    throw new Error("Use um numero válido.")
                }

                newValue = parseInt(newValue)
                if (!isApplicationOwner && newValue < (resaleConfig?.resellers_limits?.min_order || defaultConfig.min_order)){
                    throw new Error(`A Quantidade minima de membro deve ser ${resaleConfig?.resellers_limits?.min_order || defaultConfig.min_order}!`)
                }
            }

            if ( (newConfig === "teamRole" || newConfig === "clientRole") && !newValue){
                newValue = false;
            }

            databases.sales_config.set(`servers.${server_id}.${newConfig}`, newValue)
            await client.easeClient.invokeInteraction(backCustomID, interaction)

            return interaction.followUp({content: `✅ | Configuração alterada com sucesso`, ephemeral: true})
        }catch(e){
            return interaction.followUp({content: `❌ | ${e.message}`, ephemeral: true})
        }
    }
})