import { CreateButton, CreateEmbed, CreateModal, CreateRow, InteractionHandler } from "ease-discord-js";
import { QrCodePix } from 'qrcode-pix';
import { api_auth_utils, Payment, getPaymentInstace,  databases, api_discord_utils, getUserHasPermissionByID, getWebhookSalesEmbed } from "#utils";
import Discord, { PermissionFlagsBits, ChannelType, WebhookClient } from "discord.js"

const creating_payment_waiting = {};

new InteractionHandler({
    customId: "buy_members",
    useParams: true,

    run: async (client, interaction) => {
        
        try {
            await interaction.deferReply({ephemeral: true});

            const sales_config = databases.sales_config.fetch(`servers.${interaction.guild.id}`);
            if (!sales_config) return interaction.editReply({content: `❌ | Configuração de venda não encontrada`, ephemeral: true});

            if (!sales_config.sales_on){
                return interaction.editReply({content: `⚠️ | O Sistema de vendas de m3mbr0s não está ativo no momento.`, ephemeral: true});
            }

            const verified_users = await api_auth_utils.getVerifiedUsers()
            if (!verified_users) return interaction.editReply({content: `❌ | Erro ao buscar usuarios verificados da API.`, ephemeral: true});

            if (!sales_config.minimum_order) return interaction.editReply({content: `❌ | Erro ao buscar o estoque minimo`, ephemeral: true});

            if (parseInt(verified_users.verifiedUsersCount) < parseInt(sales_config.minimum_order)){
                return interaction.editReply({ content: "❌ | Sem estoque disponível", ephemeral: true})
            }

            const existThreadCreated = interaction.guild.channels.cache.find(x => x.isThread() && x.name === `🛒・membros・${interaction.user.id}`)
            if (existThreadCreated) throw new Error(`Você já possui canal criado, acesse ele aqui ${existThreadCreated.url}`)
    
            const thread = await interaction.channel.threads.create({
                name: `🛒・membros・${interaction.user.id}`,
                type: ChannelType.PrivateThread,
                members: [interaction.user.id],
                permissionOverwrites: [
                    {
                        id: interaction.user.id,
                        allow: [PermissionFlagsBits.SendMessagesInThreads],
                    },
                ],
            });
 
            // Criando a primeira entrada no banco de dados!!
            const cart_db = databases.carts.set(`servers.${interaction.guild.id}.${thread.id}`, {
                quantityMembers: sales_config.minimum_order,
                user: {id: interaction.user.id, username: interaction.user.username},
                date: new Date()
            })

            if (sales_config.teamRole){
                const mention = await thread.send(`<@&${sales_config.teamRole}>`);
                mention.delete().catch( e => null );
            }

            const embedCart = await getEmbedCart(interaction, cart_db);
            await thread.send(embedCart);

            updateDeleteTimer(interaction.guild.id, thread.id, 20 * 60)

            const components = [
                new CreateRow( 
                    new CreateButton({ label: "Ir para o canal", url: thread.url, style: 5})
                )
            ]

            const replyEmbed = new CreateEmbed({
                title: "Sistema de Carrinho",
                description: `✅ | <@${interaction.user.id}> seu carrinho foi criado com sucesso!`,
                color: `#00FF00`
            })

            await interaction.editReply({embeds: [replyEmbed], components })
        }catch(e){
            return interaction.editReply({content: `❌ | ${e.message}`})
        }
    }
})

new InteractionHandler({
    customId: "cart_change_quantity",
    useParams: true,

    run: async (client, interaction, type) => {
        if (creating_payment_waiting[interaction.user.id]){
            return interaction.reply({ content: "`⚠️` - Se tentar bugar dnv = Blacklist 🐂", ephemeral: true })
        }

        updateDeleteTimer(interaction.guild.id, interaction.channel.id, 20 * 60)

        const existCartCreated = databases.carts.fetch(`servers.${interaction.guild.id}.${interaction.channel.id}`)
        if (!existCartCreated) return interaction.reply({content: `❌ | Carrinho não encontrado`, ephemeral: true});

        const sales_config_server = databases.sales_config.fetch(`servers.${interaction.guild.id}`);
        if (!sales_config_server) return;

        const verified_users = await api_auth_utils.getVerifiedUsers()
        if (!verified_users) return interaction.reply({content: `❌ | Erro ao buscar usuarios verificados da API.`});

        const maxValue = Math.floor( (verified_users.verifiedUsersCount * sales_config_server.max_order_porcent) / 100 );
        const minValue = sales_config_server.minimum_order;

        if (type === "add"){
            const newValue = parseInt(existCartCreated.quantityMembers) + 1;

            if (newValue > parseInt(maxValue) || newValue < parseInt(minValue) || newValue <= 0){
                return interaction.reply({content: `❌ | A Quantidade deve estar entre ${minValue} e ${maxValue} membros`, ephemeral: true})
            }

            databases.carts.set(`servers.${interaction.guild.id}.${interaction.channel.id}.quantityMembers`, newValue);
        }

        if (type === "decrease"){
            const newValue = parseInt(existCartCreated.quantityMembers) - 1

            if (newValue > parseInt(maxValue) || newValue < parseInt(minValue) || newValue <= 0){
                return interaction.reply({content: `❌ | A Quantidade deve estar entre ${minValue} e ${maxValue} membros`, ephemeral: true})
            }

            databases.carts.set(`servers.${interaction.guild.id}.${interaction.channel.id}.quantityMembers`, newValue);
        }

        if (type === "change"){
            const modal = new CreateModal({
                title: "Test Modal",
                customId: "cart_change_quantity:submit_modal_change",
                inputs: [
                    {type: "text", label: "Quantos membros ?", customId: "members_quantity", style: "Short"},
                ],
            })

            await modal.show(interaction)
            return;
        }

        if (type === "submit_modal_change"){
            const newValue = interaction.fields.getTextInputValue("members_quantity");

            if (isNaN(newValue)){
                return interaction.reply({content: `❌ | Digite um número válido`, ephemeral: true})
            }

            if (parseInt(newValue) > parseInt(maxValue) || parseInt(newValue) < parseInt(minValue) || parseInt(newValue) <= 0){
                return interaction.reply({content: `❌ | A Quantidade deve estar entre ${minValue} e ${maxValue} membros`, ephemeral: true})
            }

            databases.carts.set(`servers.${interaction.guild.id}.${interaction.channel.id}.quantityMembers`, parseInt(newValue));
        }

        const newEmbed = await getEmbedCart(interaction, databases.carts.fetch(`servers.${interaction.guild.id}.${interaction.channel.id}`));
        interaction.update(newEmbed)
    }
})

// If refil is enabled;
new InteractionHandler({
    customId: "continue_purchase",
    run: async (client, interaction) => {
        const cart = databases.carts.fetch(`servers.${interaction.guild.id}.${interaction.channel.id}`)
        const sales_config = databases.sales_config.fetch(`servers.${interaction.guild.id}`);
        
        if (!cart){
            return interaction.reply({ content: `❌ | Carrinho não encontrado.`, ephemeral: true});
        }

        const contents = [
            `# Confirmação de Compra`,
            `- Olá, <@${interaction.user.id}> Como você deseja comprar ?\n`,
            `- \`🟢 Com refil: \``,
            ` - Você poderá repor todos os membros que sairam do seu servidor com membros novos`,
            `- \`🔴 Sem refil: \``,
            ` - Após efetuado o pagamento os membros entrarão no servidor e caso saiam você não poderá repor\n`,
            `- \`💵 Valores: \``,
            ` - \`🟢\` Com Refil: ${(cart.quantityMembers * sales_config.price_per_member_refil).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'}) }`,
            ` - \`🔴\` Sem Refil: ${(cart.quantityMembers * sales_config.price_per_member).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'}) }`,
        ]

        const components = [
            new CreateRow([
                new CreateButton({ label: "1 - Com Refil", style: "Success", customId: "confirm_purchase:true"}),
                new CreateButton({ label: "ㅤㅤㅤㅤ", style: "Secondary", disabled: true, customId: "continue_purchase"}),
                new CreateButton({ label: "2 - Sem Refil", style: "Danger", customId: "confirm_purchase:false"}),
                new CreateButton({ label: "Cancelar", style: "Danger", customId: "cancel_cart"}),
            ])
        ]

        return interaction.update({ content: contents.join("\n"), embeds: [], components})
    }
})

new InteractionHandler({
    customId: "cancel_cart",
    useParams: true,

    run: async (client, interaction, paymentRandonId) => {
        const cart = databases.carts.fetch(`servers.${interaction.guild.id}.${interaction.channel.id}`)

        if (!cart){
            return interaction.reply({ content: `❌ | Carrinho não encontrado.`, ephemeral: true});
        }

        if (cart.payment !== "approved-by-admin" && cart.payment !== "approved"){
            databases.carts.delete(`servers.${interaction.guild.id}.${interaction.channel.id}`)
        }

        databases.carts.delete(`delete_timestamp.${interaction.guild.id}.${interaction.channel.id}`)

        const embed = new CreateEmbed({
            title: `Canal sendo deletado`,
            description: `✅ | O Canal será deletado em 5 segundos!`,
            color: `#00FF00`
        })

        if (paymentRandonId){
            const paymentInstance = getPaymentInstace(paymentRandonId);
            paymentInstance?.cancelPayment();
        }


        if (interaction.deferred){
            await interaction.followUp({embeds: [embed], ephemeral: true});
        }else{
            await interaction.reply({embeds: [embed], ephemeral: true})
        }

        setTimeout(() => {
            interaction.channel.delete();
        }, 5000)
    }
})

new InteractionHandler({
    customId: "confirm_purchase",
    useParams: true,

    run: async (client, interaction, refil) => {

        try {
            creating_payment_waiting[interaction.user.id] = true;

            const withRefil = refil === "true" ? true : false;
            updateDeleteTimer(interaction.guild.id, interaction.channel.id, 20 * 60) // Renova o timer pra deletar o carrinho após 20 minutos.

            await interaction.deferUpdate();
            const server_db_path = `servers.${interaction.guild.id}.${interaction.channel.id}`;

            const cart_db = databases.carts.fetch(server_db_path);
            if (!cart_db) throw new Error("Carrinho não encontrado")

            const sales_config = databases.sales_config.fetch(`bank_config`);
            if (!sales_config) throw new Error("Configuração do banco não encontrado")
                
            const server_sale_config = databases.sales_config.fetch(`servers.${interaction.guild.id}`);
            if (!server_sale_config) throw new Error(`Servidor não foi configurado para venda de membros.`)

            const price = parseFloat(cart_db.quantityMembers) * parseFloat( withRefil ? server_sale_config.price_per_member_refil : server_sale_config.price_per_member)

            let payment_id = null;
            let qr_code_buffer = null;
            let pixCopyAndPaste = null;
            let paymentRandomID = null
            let webhook_owner;

            const resale_config = databases.sales_config.fetch(`resale_config`);
            const webhook_sales = server_sale_config.webhook ? new WebhookClient({ url: server_sale_config.webhook }) : null;

            /*
                Vamos verificar se está ativo o webhook de revenda desse servidor em especifico;
                Caso sim, vamos verificar se o webhook de revenda está configurado pelo dono da aplicação;
                Caso esteja configurado, vamos criar um objeto WebhookClient para enviar a notificação no canal
            */
            if (server_sale_config.resale_webhook){
                webhook_owner = resale_config?.webhook ? new WebhookClient({ url: resale_config.webhook }) : null;
            }

            if (!sales_config.semi_auto){
                if (!sales_config.mp_token) throw new Error("Token do mercado pago não configurado!")
    
                const paymentManager = new Payment({accessToken: sales_config.mp_token, /* optional -> */ blockedBanks: sales_config.blocked_banks})
    
                const payment = await paymentManager.create({
                    price: price,
                    description: `Compra de ${cart_db.quantityMembers} membros discord.`,
                    payerMail: `${interaction.user.id}@gmail.com`,
                    external_reference: interaction.channel.id,
    
                    onApproved: (_, approvedPayment) => {
                        databases.carts.set(`${server_db_path}.payment.status`, "approved")
                        databases.carts.set(`${server_db_path}.payment.bank`, approvedPayment.point_of_interaction?.transaction_data?.bank_info?.payer?.long_name || "Mercado Pago (N/A)")

                        const comission_server_amount = parseFloat(server_sale_config.commission) > 0 ? ((parseFloat(server_sale_config.commission)) / 100) * parseFloat(price) : 0;
                        const comission_owner_amount = parseFloat(price) - comission_server_amount;

                        if (webhook_owner){
                            try {
                                const embedOwner = getWebhookSalesEmbed({ isOwner: true, interaction, payment, approvedPayment, cart: cart_db, comission_server_amount, comission_owner_amount, price})
                                webhook_owner.send({ embeds: [embedOwner] })
                            }catch(e){
                                console.log(e)
                            }
                        }

                        if (webhook_sales){
                            try {
                                const embedResale = getWebhookSalesEmbed({ isOwner: false, interaction, payment, approvedPayment, cart: cart_db, comission_server_amount, comission_owner_amount, price})
                                webhook_sales?.send({ embeds: [embedResale] })
                            }catch(e){
                                console.log(e)
                            }
                        }

                        databases.extracts.push(`extracts.${interaction.guild.id}`, { action: "add", amount: parseFloat(comission_server_amount), transaction_origin: `(COMISSÃO) - Venda para ${cart_db.user.username} (${cart_db.user.id}) - ${cart_db.quantityMembers} Membros`, date: new Date()});
                        databases.extracts.push(`extracts.main`, { action: "add", amount: parseFloat(comission_owner_amount), transaction_origin: `(REVENDA) - Venda para ${cart_db.user.username} (${cart_db.user.id}) - ${cart_db.quantityMembers} Membros ( guild: ${interaction.guild.id} )`, date: new Date()});
                        client.easeClient.invokeInteraction(`paymentApproved`, interaction)
                    },
    
                    onRefunded: async (approvedPayment, reason) => { 
                        await interaction.followUp({ content: `❌ | Banco bloqueado! Tente novamente com um banco diferente.\nErro: ${reason}`, ephemeral: true})

                        try {   
                            const embeds = new CreateEmbed({
                                author: { name: `${interaction.guild.name}・Compra de M3mbros REPROVADA!`, iconURL: interaction.user.displayAvatarURL()},
                                color: "#7B0000",
                                fields: [
                                    {name: `\`👥\`・Usuario:`, value: `<@${interaction.user.id}> - \`${interaction.user.id}\``},
                                    {name: `\`📝\`・Quantidade:`, value: `${cart_db.quantityMembers} Membro(s)`},
                                    {name: `\`🏦\`・Banco:`, value: `${approvedPayment.point_of_interaction?.transaction_data?.bank_info?.payer?.long_name || "N/A"}`},
                                    {name: `\`💵\`・Valor Total:`, value: `${price.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`},
                                    {name: `\`❓\`・Motivo:`, value: `${reason}`},
                                    {name: `\`🕦\`・Data:`, value: `<t:${Math.floor(new Date() / 1000)}:f> (<t:${~~(new Date() / 1000)}:R>)`},
                                ],
                            })
                
                            webhook_sales?.send({ embeds: [embeds] })

                        }catch(e){console.log(e)}

                        return client.easeClient.invokeInteraction(`cancel_cart:${paymentManager.randomId}`, interaction);
                     },
    
                    onTimeout: async () => {
                        await interaction.followUp({ content: `❌ | Tempo de pagamento esgotado!`, ephemeral: true}).catch(e => null)
                        return client.easeClient.invokeInteraction(`cancel_cart:${paymentManager.randomId}`, interaction);
                    },
                })

                qr_code_buffer = payment.point_of_interaction.transaction_data.qr_code_base64,
                pixCopyAndPaste = payment.point_of_interaction.transaction_data.qr_code,
                payment_id == payment.id;
                paymentRandomID = paymentManager.randomId;

            } else {
                const qrCodePix = QrCodePix({
                    version: '01',
                    key: sales_config.pix_copy_and_paste,
                    transactionId: interaction.user.id, //max 25 characters
                    value: price,
                });

                const qrCodeDataURL = await qrCodePix.base64();
                const base64String = qrCodeDataURL.split(',')[1]; // Remove o prefixo e fica só com a string base64

                qr_code_buffer = base64String
                pixCopyAndPaste = qrCodePix.payload();
            }

            databases.carts.set(`${server_db_path}.payment`, {
                id: payment_id,
                qr_code_buffer,
                pixCopyAndPaste,
                price,
                status: "pending",
            })

            databases.carts.set(`${server_db_path}.canUseRefil`, withRefil)

            const contents = [
                `# Pagamento`,
                `- Vamos finalizar o seu pagamento, você pode pagar escaneando o QR-Code ou através do PIX Copia e Cola.\n`,
                `\`📦\` Produto: *x${ cart_db.quantityMembers } Membro(s)*`,
                `\`💵\` Valor total: *${ price.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'}) }*\n`,
            ]

            if (sales_config.semi_auto){
                contents.push(`⚠️ Após feito o pagamento, envie uma foto no comprovante no CHAT para que um administrador possa aprovar seu pagamento.`)
            }else{
                contents.push(`⚠️ Seu pagamento deve demorar entre 3-15 segundos para ser aprovado. após aprovado, você poderá enviar os membros para seu servidor.`)
            }
           
            const components = [
                new CreateRow([
                    new CreateButton({ label: "Pix copia e cola", customId: "select_pix_copy_and_paste" }),
                    new CreateButton({ label: "Pix QR-Code", customId: "select_pix_qr_code"}),
                    new CreateButton({ label: "Aprovar Compra", customId: `approve_payment:${paymentRandomID || null}`, style: "Success"}),
                    new CreateButton({ label: "Cancelar", customId: `cancel_cart:${paymentRandomID || null}`, style: "Danger"})
                ])
            ]

            // Quando terminar de editar a mensagem remove o usuario do "creating_payment_waiting".
            return interaction.message.edit({ content: contents.join("\n"), embeds: [], components, ephemeral: true}).finally( () => delete creating_payment_waiting[interaction.user.id] )
        }catch(e){
            console.log(e)
            return interaction.editReply({content: `❌ | ${e.message}`, ephemeral: true, embeds: [], files: [], components: []})
        }
    }
})

new InteractionHandler({
    customId: "paymentApproved",

    run: async (client, interaction) => {
        const server_sale_config = databases.sales_config.fetch(`servers.${interaction.guild.id}`);
        if (!server_sale_config) return interaction.reply({ content: "❌ | Configuração do servidor não encontrada", ephemeral: true });

        const cart = databases.carts.fetch(`servers.${interaction.guild.id}.${interaction.channel.id}`)
        if (!cart) return interaction.reply({ content: "❌ | Carrinho não encontrado", ephemeral: true });

        if (server_sale_config.clientRole){
            const userToAddRole = interaction.guild.members.cache.get(cart.user.id);

            if (userToAddRole){
                userToAddRole.roles.add(server_sale_config.clientRole).catch( e => { console.log(`❌ | Erro ao adicionar cargo de verificado: ${e}`)})
            }else{
                console.log(`❌ | Erro ao adicionar cargo de verificado, pois o usuario a dar cargo não foi encontrado.`)
            }
        }

        databases.carts.delete(`delete_timestamp.${interaction.guild.id}.${interaction.channel.id}`);

        const contents = [
            `# 🎉 Pagamento Aprovado!`,
            `- **Eii <@${cart.user.id}> Seu pagamento foi aprovado com sucesso!**\n`,
            "- Para receber seus membros clique no botão 'Adicionar BOT' e adicione ele no seu servidor",
            "- Após adicionado, clique em 'Enviar membros' e informe o ID do seu servidor",
            "- **NÃO** remova o bot do seu servidor antes de concluir a entrega ou você poderá perder seus membros.\n",
            `\`🕦\` **O Tempo para entrega dos seus membros depende da demanda dos pedidos**`,
            `\`⚠️\` Após enviado, você poderá usar o comando **/pedidos** para ver o andamento.`,
        ]

        const bot_auth_config = await api_auth_utils.getApplicationConfig();
        if (!bot_auth_config?.bot_id) return interaction.reply({ content: `❌ | Configuração da auth não encontrada.`, ephemeral: true});

        const components = [
            new CreateRow(
                new CreateButton({ label: "Enviar membros", style: 1, customId: "send_members"}),
                new CreateButton({ label: "Adicionar BOT", style: 5, url: `https://discord.com/oauth2/authorize?client_id=${bot_auth_config.bot_id}&permissions=8&scope=bot`}),
            )
        ]

        if (interaction.replied || interaction.deferred){
            return interaction.editReply({ content: contents.join("\n"), embeds: [], components, ephemeral: true})
        }else{
            return interaction.update({ content: contents.join("\n"), embeds: [], components, ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "select_pix_copy_and_paste",

    run: async (client, interaction) => {
        const cart_db = databases.carts.fetch(`servers.${interaction.guild.id}.${interaction.channel.id}`);
        if (!cart_db) return interaction.reply({ content: `❌ | Carrinho não encontrado`, ephemeral: true});

        interaction.reply({content: cart_db.payment.pixCopyAndPaste, ephemeral: true})
    }
})

new InteractionHandler({
    customId: "select_pix_qr_code",

    run: async (client, interaction) => {
        const cart_db = databases.carts.fetch(`servers.${interaction.guild.id}.${interaction.channel.id}`);
        if (!cart_db) return interaction.reply({ content: `❌ | Carrinho não encontrado`, ephemeral: true});

        const buffer_base_64 = Buffer.from(cart_db.payment.qr_code_buffer, "base64");
        const attachment = new Discord.AttachmentBuilder(buffer_base_64, { name: "payment.png" }); 

        interaction.reply({files: [attachment], ephemeral: true})
    }
})

new InteractionHandler({
    customId: "approve_payment",
    useParams: true,

    run: async (client, interaction, paymentRandonId) => {
        if (!getUserHasPermissionByID(interaction.user.id)){
            return interaction.reply({ content: `❌ | Você não possui permissão para usar esse comando!`, ephemeral: true})
        }

        const modal = new CreateModal({
            title: "Aprovando pagamento",
            customId: `on-submit-approve-payment:${paymentRandonId}`,
            inputs: [
                {type: "text", label: "Deseja adicionar no extrato ? (SIM/NÃO)", customId: "add_extract", style: "Short"},
            ],
        })

        return await modal.show(interaction)
    }
})

new InteractionHandler({
    customId: "on-submit-approve-payment",
    useParams: true, 

    run: async (client, interaction, paymentRandonId) => {
        const response = interaction.fields.getTextInputValue("add_extract");
        if (!response) return interaction.reply({content: "❌ | Resposta não encontrada", ephemeral: true});

        let responseBoolean = undefined;

        if (response?.toLowerCase() === "sim"){
            responseBoolean = true
        }else if (response?.toLowerCase() === "não"){
            responseBoolean = false
        }
        
        if (responseBoolean === undefined){
            return interaction.reply({content: "❌ | Sua resposta deve ser `sim` ou `não`", ephemeral: true});
        }

        const cart_db_path = `servers.${interaction.guild.id}.${interaction.channel.id}`;

        // Cancelando pagamento
        if (paymentRandonId){
            const paymentInstance = getPaymentInstace(paymentRandonId)
            if (paymentInstance) paymentInstance.cancelPayment();
        }

        // Buscando carrinho
        const cart_exists = databases.carts.fetch(cart_db_path)
        if (!cart_exists) return interaction.reply({ content: `❌ | Carrinho não encontrado!`, ephemeral: true})

        // Buscando config do servidor
        const sales_config = databases.sales_config.toJSON();

        const server_sale_config = sales_config.servers[interaction.guild.id];
        if (!server_sale_config) return interaction.reply({ content: `❌ | Configuração do servidor não encontrada.`, ephemeral: true})

        const comission_server_amount = parseFloat(server_sale_config.commission) > 0 ? ((parseFloat(server_sale_config.commission)) / 100) * parseFloat(cart_exists.payment.price) : 0;
        const comission_owner_amount = parseFloat(cart_exists.payment.price) - comission_server_amount;

        const fields = [];
        fields.push({name: `\`👥\`・Usuario:`, value: `<@${cart_exists.user.id}> - \`${cart_exists.user.id}\``});
        fields.push({name: `\`🛡️\`・Responsável por aprovar:`, value: `<@${interaction.user.id}> - \`${interaction.user.id}\``});
        fields.push({name: `\`📝\`・Quantidade:`, value: `${cart_exists.quantityMembers} Membro(s)`});
        fields.push({name: `\`💵\`・Valor Total:`, value: `${cart_exists.payment.price.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`});
        fields.push({name: `\`💵\`・Comissão Recebida - revenda:`, value: `${comission_server_amount.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`});
        fields.push({name: `\`💵\`・Valor Recebido - proprietario:`, value: `${comission_owner_amount.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`});
        fields.push({name: `\`📓\`・Adicionar no Extrato ?`, value: `\`${responseBoolean ? "SIM" : "NÃO"}\``});
        fields.push({name: `\`🕦\`・Data:`, value: `<t:${Math.floor(new Date() / 1000)}:f> (<t:${~~(new Date() / 1000)}:R>)`});

        const embeds = new CreateEmbed({
            author: { name: `${interaction.guild.name}・Compra de M3mbros Aprovada!`, iconURL: interaction.user.displayAvatarURL()},
            color: "#0f67b6",
            fields
        })

        const webhook_sales = server_sale_config.webhook ? new WebhookClient({ url: server_sale_config.webhook }) : null;
        if (webhook_sales){
            webhook_sales.send({embeds: [embeds]})
        }

        if (server_sale_config.resale_webhook && sales_config?.resale_config?.webhook){
            const webhook_owner = new WebhookClient({ url: sales_config.resale_config.webhook });
            webhook_owner?.send({embeds: [embeds]})
        }

        if (responseBoolean){
            databases.extracts.push(`extracts.${interaction.guild.id}`, { action: "add", amount: parseFloat(comission_server_amount), transaction_origin: `(COMISSÃO) Venda para ${cart_exists.user.username} (${cart_exists.user.id}) - ${cart_exists.quantityMembers} Membros`, date: new Date() });
            databases.extracts.push(`extracts.main`, { action: "add", amount: parseFloat(comission_owner_amount), transaction_origin: `(REVENDA) Venda para ${cart_exists.user.username} (${cart_exists.user.id}) - ${cart_exists.quantityMembers} Membros`, date: new Date() });
        }

        databases.carts.set(`${cart_db_path}.payment.status`, responseBoolean ? "approved-by-admin" : "approved-by-admin-no-extract" )
        client.easeClient.invokeInteraction(`paymentApproved`, interaction);
    }
})

new InteractionHandler({
    customId: "send_members",
    run: async (client, interaction) => {

        const modal = new CreateModal({
            title: "Enviar membros",
            customId: "submit_modal_send_members",
            inputs: [
                {type: "text", label: "Qual ID do servidor?", customId: "server_id", style: "Short"},
            ],
        })    

        return modal.show(interaction);
    }
})

new InteractionHandler({
    customId: "submit_modal_send_members",

    run: async (client, interaction) => {
        
        const cart_info = databases.carts.fetch(`servers.${interaction.guild.id}.${interaction.channel.id}`);
        if (!cart_info || !cart_info.quantityMembers){
            return interaction.reply({ content: "❌ | Carrinho não encontrado", ephemeral: true})
        }


        const server_id = interaction.fields.getTextInputValue("server_id");
        if (!server_id) {
            return interaction.reply({ content: "❌ | Você precisa mandar um ID de servidor correto!"});
        }

        try {
            const server = await api_discord_utils.getGuild(server_id).catch( e => { throw new Error("Servidor não encontrado! Verifique se o BOT está no servidor.")} )

            const createQueue = await api_auth_utils.createQueuePull({ 
                origin: "sales",
                description: `Compra do usuario: ${interaction.user.username} (${interaction.user.id})`,
                from: "any",
                to: server_id,
                quantity_total: cart_info.quantityMembers,
            })

            databases.users_queue.push(`${interaction.guild.id}.${interaction.user.id}`, {
                to: server_id, 
                to_name: server.name || "N/A",
                id: createQueue.queue.id, 
                quantity: cart_info.quantityMembers, 
                canUseRefil: cart_info.canUseRefil || false, 
                isRefil: false,
                membersWhenCreating: server.approximate_member_count,
                cart_id: interaction.channel.id,
                date: new Date(),
            })

            await interaction.reply("✅ | Seu pedido foi adicionado a fila! Use o comando **/pedidos** para ver o andamento. Esse canal será excluido em 20 segundos!")

            setTimeout(() => {
                interaction.channel.delete().catch( e => null )
            }, 20000)
        }catch(e){
            return interaction.reply({ content: `❌ | ${e.message}`, ephemeral: true})
        }
    }
})

function updateDeleteTimer(guild_id, channel_id, secondsToAdd){
    const currentTimestamp = new Date().getTime();
    const deleteTimestamp = currentTimestamp + (secondsToAdd * 1000);
    
    databases.carts.set(`delete_timestamp.${guild_id}.${channel_id}`, deleteTimestamp);
}

async function getEmbedCart(interaction,cart_info){
    const sales_config_server = databases.sales_config.fetch(`servers.${interaction.guild.id}`);
    if (!sales_config_server) return;

    const verified_users = await api_auth_utils.getVerifiedUsers()
    if (!verified_users) return interaction.reply({content: `❌ | Erro ao buscar usuarios verificados da API.`});

    const maxValue = Math.floor( (verified_users.verifiedUsersCount * sales_config_server.max_order_porcent) / 100 );
    const minValue = sales_config_server.minimum_order;

    const contents = [
        `# Compra de M3mbros`,
        `- Olá, <@${interaction.user.id}> Nossos membros são 100% reais e podem gerar engajamento no seu servidor, escolha no botão abaixo quantos membros você deseja adquirir\n`,
        `- \`👥\` Quantidade: ${cart_info.quantityMembers} Membro(s)\n`,
        `- \`💵\` Valor:`
    ]

    if (sales_config_server.refil_on){
        contents.push(` - \`🟢\` Com Refil: ${(cart_info.quantityMembers * sales_config_server.price_per_member_refil).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`)
        contents.push(` - \`🔴\` Sem Refil: ${(cart_info.quantityMembers * sales_config_server.price_per_member).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`)
    }else{
        contents.push(` - ${(cart_info.quantityMembers * sales_config_server.price_per_member).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`)
    }

    contents.push(`\n⚠️ Você pode comprar entre ${minValue} á ${maxValue} membros.`)

    const message_components = [
        new CreateRow([
            new CreateButton({ label: " ", customId: `cart_change_quantity:decrease`, emoji: "1256797714650238978", style: "Danger"}),
            new CreateButton({ label: " ", customId: `cart_change_quantity:change`, emoji: "1256796387212001322", style: "Secondary"}),
            new CreateButton({ label: " ", customId: `cart_change_quantity:add`, emoji: "1256797373762633780", style: "Primary"}),
            new CreateButton({ label: "Cancelar", customId: "cancel_cart", style: "Danger"}),
            new CreateButton({ label: sales_config_server.refil_on ? "Continuar" : "Finalizar compra", emoji: "✅", customId: sales_config_server.refil_on ? "continue_purchase" : "confirm_purchase:false", style: "Success"})
        ]),
    ]

    return {content: contents.join("\n"), embeds: [], components: message_components};
}