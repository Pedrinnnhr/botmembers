import { CreateButton, CreateRow, CreateSelect, InteractionHandler } from "ease-discord-js";
import { databases, getMainTotalSales } from "#utils"

new InteractionHandler({
    customId: "config_sales",
    useParams: true, 

    run: async (client, interaction, _currentPage = 1) => {

        const guilds = client.guilds.cache;
        const sales_config = databases.sales_config.toJSON();
        const existentGuilds = sales_config.servers || {};
        const sales = getMainTotalSales();

        const messages = [
            `# Sistema de Vendas`,
            `- Configure o sistema de vendas aqui, [clique aqui](${`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`}) para adicionar seu servidor na lista`,
            `- Saldo atual: \`${sales.balance.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\``
        ]

        if (!sales_config?.resale_config?.webhook){
            messages.push(`\n- \`⚠️\` Webhook da revenda ainda não foi configurado!`)
        }

        const guilds_options = [];

        Object.keys(existentGuilds).forEach(guildID => {
            const guildDiscordConfig = guilds.find( x => x.id === guildID) || null;
            const guildName = guildDiscordConfig?.name || "N/A - BOT NÃO PRESENTE!";

            guilds_options.push({label: String(guildName), value: String(guildID), description: `ID: ${guildID}`, emoji: guildDiscordConfig ? "🟢" : "🟠"})
        });

        guilds.forEach(guild => {
            if (!existentGuilds[guild.id]){
                guilds_options.push({label: String(guild.name), value: String(guild.id), description: `ID: ${guild.id}`, emoji: "🔴"})
            }
        });

        const currentPage = Number(_currentPage);
        const maxGuildsPerPage = 24;
        const totalPages = Math.ceil(guilds.size / maxGuildsPerPage);

        const guilds_options_in_page = guilds_options.slice((currentPage - 1) * maxGuildsPerPage, currentPage * maxGuildsPerPage);

        const selectComponent = CreateSelect.StringSelectMenuBuilder({
            customId: "config_sales_select_server",
            placeholder: "Selecione um servidor",
            options: guilds_options_in_page
        })

        const components = [
            new CreateRow(selectComponent),
            new CreateRow([
                new CreateButton({ label: " ", emoji: "⬅️", customId: `config_sales:${currentPage - 1}`, disabled: currentPage === 1}),
                new CreateButton({ label: `Pagina ${currentPage}/${totalPages}`, style: "Secondary", customId: "234234234", disabled: true }),
                new CreateButton({ label: " ", emoji: "➡️", customId: `config_sales:${currentPage + 1}`, disabled: currentPage === totalPages}),
            ]),
            new CreateRow([
                new CreateButton({ label: "Configurar Banco", customId: "config_sales_config_bank", emoji: "1257066845744402505"}),
                new CreateButton({ label: "Sistema de Revendas", customId: "config-global-resale", emoji: "1256804158242160692"}),
                new CreateButton({ label: "Estatisticas", customId: `main-sales-statistics`, emoji: "1256804128311738380"}),
            ]),
            new CreateRow([
                new CreateButton({ label: "Duvidas", style: "2", onClick: ( (client, interaction) => { interaction.reply({ content: "- Função em desenvolvimento", ephemeral: true})}), emoji: "1256797333606109267"}),
                new CreateButton({ label: "Sistema de Presente", style: "2", customId: "config-gift-cards", emoji: "1256804084250574932"}),
                new CreateButton({ label: "Voltar para o começo", style: "2", customId: "back_to_config", emoji: "1237510920003911791"}),
            ])
        ]

        if (interaction.deferred || interaction.replied){
            await interaction.editReply({ content: messages.join("\n"), embeds: [], components, files: []})
        }else{
            await interaction.update({ content: messages.join("\n"), embeds: [], components, files: []})
        }
    }
})

new InteractionHandler({
    customId: "on-submit-modal-resale_webhook",

    run: async (client, interaction) => {
        try {
            await interaction.deferUpdate();
            let newValue = interaction.fields.getTextInputValue("new_value0");
    
            if (newValue){
                const webhookValid = newValue.includes("discord.com/api/webhooks/");
                if (!webhookValid) throw new Error(`Esse webhook é inválido`);
            }

            databases.sales_config.set(`resale_config.webhook`, newValue || false);
            await client.easeClient.invokeInteraction(`config_sales`, interaction)

            return interaction.followUp({content: `✅ | Configuração alterada com sucesso`, ephemeral: true})
        }catch(e){
            return interaction.followUp({content: `❌ | ${e.message}`, ephemeral: true})
        }
    }
})