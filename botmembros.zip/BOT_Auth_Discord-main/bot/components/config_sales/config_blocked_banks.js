import { CreateButton, CreateEmbed, CreateRow, CreateSelect, InteractionHandler } from "ease-discord-js";
import { databases } from "#utils";

const banks = [
    'Picpay Serviços S.A.',
    'Nu Pagamentos S.A.',
    'Mercadopago.com Representações Ltda.',
    'Banco do Brasil S.A.',
    'Caixa Econômica Federal',
    'Banco Itaú Unibanco S.A.',
    'Banco Bradesco S.A.',
    'Banco Inter S.A.',
    'Neon Pagamentos S.A.',
    'Original S.A.',
    'Next',
    'Agibank',
    'Santander (Brasil) S.A.',
    'C6 Bank S.A.',
    'Banrisul',
    'PagSeguro Internet ,S.A.',
    'BS2',
    'Modalmais',
]

new InteractionHandler({
    customId: "config_blocked_banks",

    run: async (client, interaction) => {
        const blocked_banks = databases.sales_config.fetch(`bank_config.blocked_banks`) || [];
        const options = [];

        banks.map(bank => {
            const bloqued = blocked_banks.includes(bank);
            return options.push({ label: bank, description: `Clique para ${bloqued ? "Desbloquear" : "Bloquear"}`, value: bank, emoji: `${bloqued ? `🔴` : `🟢`}`})
        })

        const selectComponent = CreateSelect.StringSelectMenuBuilder({
            customId: "on_select_bank_to_toggle",
            placeholder: "Lista de bancos",
            options
        })

        const components = [
            new CreateRow(selectComponent),
            new CreateRow(
                new CreateButton({ label: "Voltar", style: "Danger", customId: "config_sales_config_bank"})
            )
        ]

        if (interaction.replied || interaction.deferred){
            interaction.editReply({ content: `- Selecione o banco abaixo que você deseja bloquear ou desbloquear`, embeds: [], components, ephemeral: true})
        }else{
            interaction.update({ content: `- Selecione o banco abaixo que você deseja bloquear ou desbloquear`, embeds: [], components, ephemeral: true})
        }
    }
})

new InteractionHandler({
    customId: "on_select_bank_to_toggle",

    run: async (client, interaction) => {
        const value = interaction.values[0];
        if (!value) return;

        const blocked_banks = databases.sales_config.fetch(`bank_config.blocked_banks`) || [];

        if (blocked_banks.includes(value)){

            const new_blocked_banks = blocked_banks.filter(item => item !== value)
            databases.sales_config.set(`bank_config.blocked_banks`, new_blocked_banks)

        }else{
            const new_blocked_banks = blocked_banks;
            new_blocked_banks.push(value)

            databases.sales_config.set(`bank_config.blocked_banks`, new_blocked_banks)
        }

        client.easeClient.invokeInteraction(`config_blocked_banks`, interaction)
    }
})