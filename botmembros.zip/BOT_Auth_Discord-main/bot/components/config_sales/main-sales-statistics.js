import { CreateButton, CreateRow, InteractionHandler, CreateModal } from "ease-discord-js";
import { getMainTotalSales, getCanvasChartBuffer, databases, getUserHasPermissionByID } from "#utils"
import { AttachmentBuilder } from "discord.js";

new InteractionHandler({
    customId: "main-sales-statistics",
    useParams: true,

    run: async (client, interaction, server_id) => {
        const sales = getMainTotalSales(server_id);

        const contents = [
            `# Estatisticas Geral`,
            `- Aqui será as estatisticas de vendas geral, **sem contar com a comissão dos servidores!**\n`,
            `- **Valores recebidos:**`,
            ` - **Recebidos esse Mês: \`${(sales.soldThisMonth).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\`**`,
            ` - **Recebidos HOJE: \`${(sales.soldToday).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\`**`,
            ` - **Saldo Atual: \`${(sales.balance).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}\`**\n`,
            `\`📊\` O Grafico abaixo representa seus ganhos nos ultimos 5 dias!`,  
        ]

        const labels = Object.keys(sales.lastFiveDaysByWeekdays).map((weekDay) => `${weekDay} (${sales.lastFiveDaysByWeekdays[weekDay].dayOfMonth})`)
        const values = Object.keys(sales.lastFiveDaysByWeekdays).map((weekDay) => (sales.lastFiveDaysByWeekdays[weekDay].totalSold))

        const canvasChartBuffer = getCanvasChartBuffer({ prefix: "R$", labels: labels.reverse(), values: values.reverse(), type: "line", width: 440, height: 250, borderColor: 'rgb(255, 255, 255)', beginAtZero: true});
        const attachment = new AttachmentBuilder(canvasChartBuffer, {name: "chart.png"});

        const components = [
            new CreateRow([
                new CreateButton({ label: "Adicionar Saldo", customId: `change-main-balance:add`, emoji: "1235772114347491339"}),
                new CreateButton({ label: "Remover Saldo", customId: `change-main-balance:remove`, emoji: "1227681755297874062"}),
                new CreateButton({ label: "Baixar Extrato", customId: `change-main-balance:download`, emoji: "1237511034722320424"}),
                new CreateButton({ label: "Atualizar Painel", customId: `main-sales-statistics`, emoji: "1237511023389315123"}),
                new CreateButton({ label: "Voltar", customId: "config_sales", style: "Secondary", emoji: "1237510920003911791"}),
            ])
        ]

        return interaction.update({ content: contents.join("\n"), components, files: [attachment] })
    }
})

new InteractionHandler({
    customId: "change-main-balance",
    useParams: true,

    run: async (client, interaction, action) => {
        if (action === "add"){
            const modal = new CreateModal({
                title: "Alteração do Saldo",
                customId: `submit-change-main-balance:add`,
                inputs: [
                    {type: "text", label: "Quanto você deseja adicionar ao saldo?", customId: "value", style: "Short"},
                    {type: "text", label: "Qual o motivo ?", customId: "description", style: "Paragraph", placeholder: "Venda de anão"},
                ],
            })

            modal.show(interaction);
        }else if (action === "remove"){

            const modal = new CreateModal({
                title: "Alteração do Saldo",
                customId: `submit-change-main-balance:remove`,
                inputs: [
                    {type: "text", label: "Quanto você deseja remover do saldo?", customId: "value", style: "Short"},
                    {type: "text", label: "Qual o motivo ?", customId: "description", style: "Paragraph", placeholder: "Comprar bot na AppsSystem"},
                ],
            })

            modal.show(interaction);
        }

        if (action === "download"){
            const extracts = databases.extracts.fetch(`extracts.main`) || [];
            const extractContent = JSON.stringify(extracts.reverse(), null, 2);

            const buffer = Buffer.from(extractContent, 'utf-8');
            const attachment = new AttachmentBuilder(buffer, {name: `extract_main.json`});

            await interaction.reply({ content: `✅ | Segue abaixo o extrato de movimentação`, files: [attachment], ephemeral: true });
        }
    }
})

new InteractionHandler({
    customId: "submit-change-main-balance",
    useParams: true,

    run: async (client, interaction, action) => {
        let value = interaction.fields.getTextInputValue("value");
        let value2 = interaction.fields.getTextInputValue("description");

        value = value.replace(",", ".")

        if (isNaN(value)){
            return interaction.reply({content: "❌ | O novo valor deve conter apenas numeros.", ephemeral: true})
        }

        try {
            if (action === "add"){
                databases.extracts.push(`extracts.main`, { action: "add", amount: parseFloat(value), transaction_origin: value2 || "N/A", date: new Date()})
            }else if (action === "remove"){
                databases.extracts.push(`extracts.main`, { action: "remove", amount: parseFloat(value), transaction_origin: value2 || "N/A", date: new Date()})
            }
    
            await client.easeClient.invokeInteraction(`main-sales-statistics`, interaction)
            await interaction.followUp({ content: "✅ | Saldo alterado com sucesso!", ephemeral: true})
        }catch(e){
            interaction.reply({content: `❌ | Erro ao alterar seu saldo: ${e.message}`, ephemeral: true})
        }
    }
})