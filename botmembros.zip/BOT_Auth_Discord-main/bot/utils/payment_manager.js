import axios from 'axios';
import { Payment, MercadoPagoConfig } from "mercadopago";
import { v4 as uuidv4 } from 'uuid';

const paymentManagerInstances = {};

export default class PaymentManager {
    constructor ( options ){
        this.client = new MercadoPagoConfig({ accessToken: options.accessToken });
        this.accessToken = options?.accessToken;

        this.check_interval = options?.check_interval || 7000;
        this.cancel_time = options?.cancel_time || 16 * 60000;
        this.blockedBanks = options?.blockedBanks || [];
        this.randomId = uuidv4();

        if (!this.accessToken){
            throw new Error("accessToken is missing")
        }

        if (this.blockedBanks && !Array.isArray(this.blockedBanks) ){
            throw new Error("blockedBanks need be array")
        }

        paymentManagerInstances[this.randomId] = this;
    }

    create = async ( paymentData ) => {
        const { price, description, payerMail, external_reference } = paymentData;

        if (!price){
            throw new Error("price is missing")
        }
    
        if (!description){
            throw new Error("description is missing")
        }
    
        if (!payerMail){
            throw new Error("payer mail is missing");
        }
    
        if (!external_reference){
            throw new Error("External reference is missing");
        }
    
        this.paymentData = paymentData;
    
        const payment_data_mp = {
            transaction_amount: parseFloat(price.toFixed(2)),
            description: description,
            payment_method_id: 'pix',
            external_reference: external_reference,
            payer: {
                email: payerMail,
            },
        }
    
        this.paymentManager = new Payment(this.client);
        this.payment =  await this.paymentManager.create({body: payment_data_mp});
    
        // On payment approved
        this.verifyPaymentInterval = setInterval(async () => {
            const approvedPayment = await this.getPaymentStatus();
    
            if (approvedPayment){
                this.internalOnPaymentApproved(approvedPayment);
            }

        }, this.check_interval)
    
        // Timer to cancel payment by timeout
        this.timeoutCancel = setTimeout( () => {
            this.internalOnTimeout();
        }, this.cancel_time)
    
        return this.payment;
    }

    internalOnPaymentApproved = async (approvedPayment) => {

        clearInterval(this.verifyPaymentInterval);
        clearTimeout(this.timeoutCancel);

        delete paymentManagerInstances[this.randomId];

        let paymentBankLongName = approvedPayment?.point_of_interaction?.transaction_data?.bank_info?.payer?.long_name;

        if (!paymentBankLongName){
            paymentBankLongName = "Bank name not informed"
        }

        if (this.blockedBanks && this.blockedBanks.map(bank => bank.toLowerCase()).includes(paymentBankLongName.toLowerCase())) {
            return this.refundPayment(approvedPayment, "Bank is blocked");
        }

        if (this.paymentData.onApproved){
            this.paymentData.onApproved(this.payment, approvedPayment);
        }
    }

    internalOnTimeout = async () => {
        clearInterval(this.verifyPaymentInterval);
        delete paymentManagerInstances[this.randomId];

        if (this.paymentData.onTimeout) {
            this.paymentData.onTimeout(this.payment);
        }
    }

    getPaymentStatus = async () => {
        try {
            const response = await axios.get(`https://api.mercadopago.com/v1/payments/search?external_reference=${this.payment.external_reference}`, { headers: {'Authorization': `Bearer ${this.accessToken}` }});
            console.log(`Buscando se o pagamento ${this.payment.id} foi aprovado.... `)
    
            if (response?.data?.results?.[0]?.status === "approved") {
                return response.data.results[0];
            }else{
                return false;
            }
    
        }catch(e){
            console.log("Erro ao obter o pagamento ~> " + e.message)
            return false;
        }
    }

    refundPayment = async (approvedPayment, reason) => {
        try {
            await axios.post(`https://api.mercadopago.com/v1/payments/${this.payment.id}/refunds`, {}, {
                headers: {
                    'Authorization': `Bearer ${this.accessToken}`
                }
            });
            
            if (this.paymentData.onRefunded){
                this.paymentData.onRefunded(approvedPayment, reason)
            }
        }catch(e){
            console.log(`Erro ao estornar o pagamento (${this.payment.id}) ~> ` + e.message)
        }
    }

    cancelPayment = async () => {
        delete paymentManagerInstances[this.randomId];
        console.log("pagamento cancelado. ", paymentManagerInstances)

        if (this.verifyPaymentInterval){
            clearInterval(this.verifyPaymentInterval);
        }

        if (this.timeoutCancel){
            clearTimeout(this.timeoutCancel)
        }
    }
}

export const getPaymentInstace = (randomId) => {
    return paymentManagerInstances[randomId];
}