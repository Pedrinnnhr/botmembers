import { CreateEmbed, CreateButton, CreateRow } from 'ease-discord-js';
import { api_auth_utils, databases } from './index.js';

export const getEmbedAuth = async (server_id) => {
    const server_info_api = await api_auth_utils.getServer(server_id, ["bot_id", "custom_domain"])
        .then(r => r.data)
        .catch(e => null);

    if (!server_info_api) throw new Error("Server not found");

    const server_embed_db = await databases.servers_embed.fetch(server_id)
    if (!server_embed_db) throw new Error("Embed config not found");

    const embedObject = {};

    if (server_embed_db.embed_title) embedObject.title = server_embed_db.embed_title;
    if (server_embed_db.embed_description) embedObject.description = server_embed_db.embed_description;
    if (server_embed_db.embed_color) embedObject.color = server_embed_db.embed_color
    if (server_embed_db.embed_footer) embedObject.footer = { text: server_embed_db.embed_footer };
    if (server_embed_db.embed_image_url) embedObject.image = server_embed_db.embed_image_url;
    if (server_embed_db.embed_timestamp) embedObject.timestamp = true

    const embed = new CreateEmbed(embedObject);
    const redirect_uri = (process.env.REDIRECT_URI).replace("$custom_url", server_info_api.custom_domain)

    const link_button = `https://discord.com/oauth2/authorize?client_id=${server_info_api.bot_id}&response_type=code&redirect_uri=${redirect_uri}&scope=email+guilds.join+identify`
    const button_label = server_embed_db.embed_button_name || "Clique Aqui";
    const button_emoji = server_embed_db.embed_button_emoji || null;

    const button_auth = new CreateButton({ label: button_label, style: "Link", url: link_button, emoji: button_emoji});

    const components = [new CreateRow([button_auth])];

    const componentToSendAPI = {
        embeds: [embedObject],
        components: [ 
            {
                type: 1, 
                components: [
                    {
                        label: button_label, 
                        url: link_button, 
                        emoji: button_emoji,
                        type: 2,
                        style: 5
                    }
                ] 
            }
        ],
    }

    return { components, files: [], embeds: [embed], componentToSendAPI };
}

export const getSaleEmbed = async (client, verified_users, server_id) => {
    const server_sale_config = databases.sales_config.fetch(`servers.${server_id}`);
    if (!server_sale_config) return;

    const maxValue = Math.floor( (verified_users.verifiedUsersCount * server_sale_config.max_order_porcent) / 100 );
    const footerText = parseInt(server_sale_config.minimum_order) < maxValue ? `Minimo: ${server_sale_config.minimum_order}, Máximo: ${maxValue}` : `Sem estoque disponível`;

    const embed_settings = server_sale_config.embed_settings;

    const embed = new CreateEmbed({
        author: {name: String(embed_settings.title), iconURL: client.user.displayAvatarURL()},
        description: String(embed_settings.description),
        color: String(embed_settings.color),
        image: embed_settings.banner || null,
        footer: { text: footerText },
        timestamp: true
    })  

    return embed;
}

export const setupDefaultEmbedConfig = async (server_id) => {
    const server_embed_db = await databases.servers_embed.fetch(server_id)
    if (server_embed_db) return;

    await databases.servers_embed.set(server_id, { 
        embed_title: "Verificação de segurança", 
        embed_description: "Para ter acesso a todos os canais do servidor, verifique-se antes!", 
        embed_color: "#ffffff", 
        embed_footer: null, 
        embed_image_url: null, 
        embed_timestamp: false, 
        embed_button_emoji: "🛡️",
        embed_button_name: "Verificar-se",
    });

    return databases.servers_embed.fetch(server_id);
}