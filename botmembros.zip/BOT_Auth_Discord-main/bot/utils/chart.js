import { createCanvas } from "canvas";
import { Chart, registerables} from "chart.js";
Chart.register(...registerables);

let currentChartInstance = null;

const getCanvasChartBuffer = (data) => {

    if (currentChartInstance){
      currentChartInstance.destroy();
    }

    const labels = data.labels;
    const values = data.values; 
    const type = data.type || "line";
    const width = data.width || 800;
    const height = data.height || 600;

    const currentCanvas = createCanvas(width, height)
    const ctx = currentCanvas.getContext('2d')
    ctx.fillStyle="rgb(0,0,255,)"  

    const plugin = {
        id: 'customCanvasBackgroundColor',
        beforeDraw: (chart, args, options) => {
          const {ctx} = chart;
          ctx.save();
          // ctx.globalCompositeOperation = 'destination-over';
          // ctx.fillStyle = options.color || '#141414';
          // ctx.fillRect(0, 0, chart.width, chart.height);
          ctx.restore();
        }
    };

    currentChartInstance = new Chart(ctx, {
        type: type,
        data: {
          labels: labels,
          datasets: [{
            label: '',
            data: values,
            borderWidth: 2,
            borderColor: data.borderColor || null,
          }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: data.beginAtZero,
                    ticks: {
                      callback: function(value, index, values) {
                          return `${data?.prefix || ""} ${parseFloat(value).toFixed(0)}`;
                      }
                  }
                }
            },
        },
        plugins: [plugin],
    });



    return currentCanvas.toBuffer('image/png', { quality: data.quality || 1});
}

export default getCanvasChartBuffer;