import deploy from "../../deploy.json" with { type: "json" }

import { CreateEmbed } from "ease-discord-js";
import { getEmbedAuth, setupDefaultEmbedConfig, getSaleEmbed } from './embed.js';
import api_auth_utils from './api_auth_utils.js';
import api_discord_utils from './api_discord_utils.js';
import getCanvasChartBuffer from './chart.js'; 
import databases from "../../databases/index.js"
import Payment, { getPaymentInstace } from './payment_manager.js';
import { getTotalSalesByServer, getMainTotalSales } from "./customDatabaseFetch.js"

export {
    api_auth_utils,
    api_discord_utils,
    getCanvasChartBuffer,
    setupDefaultEmbedConfig, 
    getEmbedAuth,
    getSaleEmbed,
    databases,
    Payment,
    getPaymentInstace,
    getUserHasPermissionByID,
    getWebhookSalesEmbed,
    getTotalSalesByServer,
    getMainTotalSales
}

const getUserHasPermissionByID = (_user_id) => {
    const owner_id = String(deploy.owner_id);
    const user_id = String(_user_id);

    if (owner_id === user_id){
        return true;
    }

    const permissions = databases.config.fetch("permissions");
    if (permissions.includes(user_id)){
        return true;
    }


    return false;
}

const getWebhookSalesEmbed = (data) => {
    const { interaction, payment, approvedPayment, isOwner, cart, comission_server_amount, comission_owner_amount, price } = data;
    const fields = [];

    isOwner ? fields.push({name: `\`👩‍👧‍👦\`・Servidor:`, value: `${interaction.guild.name} - \`${interaction.guild.id}\``}) : null;
    fields.push({name: `\`👥\`・Usuario:`, value: `<@${interaction.user.id}> - \`${interaction.user.id}\``});
    fields.push({name: `\`📝\`・Quantidade:`, value: `${cart.quantityMembers} Membro(s)`});
    fields.push({name: `\`🪪\`・ID Do Pagamento:`, value: `${payment.id}`});
    fields.push({name: `\`🏦\`・Banco:`, value: `${approvedPayment.point_of_interaction?.transaction_data?.bank_info?.payer?.long_name || "N/A"}`});
    fields.push({name: `\`💵\`・Valor Total:`, value: `${price.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`});
    fields.push({name: `\`💷\`・Comissão Recebida`, value: `${comission_server_amount.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`});
    isOwner ? fields.push({name: `\`💶\`・Valor Recebido:`, value: `${comission_owner_amount.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}`}) : null;
    fields.push({name: `\`🕦\`・Data:`, value: `<t:${Math.floor(new Date() / 1000)}:f> (<t:${~~(new Date() / 1000)}:R>)`});

    const embed = new CreateEmbed({
        author: { name: `${interaction.guild.name}・Compra de M3mbros Aprovada!`, iconURL: interaction.user.displayAvatarURL()}, color: "#0f67b6", fields
    })

    return embed;
}