import axios from 'axios';
import dotenv from 'dotenv'; dotenv.config({path: `.env.${process.env.NODE_ENV || 'development'}`});
import { api_auth_utils } from '#utils';

let _axios;

const updateAxios = async () => {
    const app_info = await api_auth_utils.getApplicationConfig();
    if (!app_info) throw new Error("Application info not found");

    _axios = axios.create({
        baseURL: `https://discord.com/api/v10/`,
        headers: {
            Authorization: `Bot ${app_info.bot_token}`
        }
    });
}


export default {
    getGuilds: async function() {
        await updateAxios();

        const response = await _axios.get(`/users/@me/guilds`);
        return response.data;
    },

    getGuild: async function(guild_id) {
        await updateAxios();

        const response = await _axios.get(`/guilds/${guild_id}?with_counts=true`);
        return response.data;
    },

    getMe: async function() {
        await updateAxios();

        const response = await _axios.get(`/applications/@me`);
        return response.data;
    },

    getRole: async function(guild_id, role_id) {
        await updateAxios();

        const response = await _axios.get(`/guilds/${guild_id}/roles`);
        return response.data.find(role => role.id === role_id);
    },

    sendOrEditMessageInChannel: async function(channel_id, content, message_id) {
        await updateAxios();

        if (content?.embeds){
            content.embeds.map(embed => {
                if (embed.color) embed.color = hexToDiscordColor(embed.color);
                if (embed.timestamp) embed.timestamp = new Date().toISOString();
                if (embed.image) embed.image = { url: embed.image };
            });
        }

        if (content.components) {
            content.components.map(component => {
                if (component.type === 1) {
                    component.components.map(sub_component => {
                        if (sub_component.type === 2) {
                            if (sub_component.emoji) {
                                sub_component.emoji = { name: sub_component.emoji, id: null }
                            }
                        }
                    });
                }
            });
        }
        
        const existMessage = await _axios.get(`/channels/${channel_id}/messages/${message_id}`).then(r => r.data).catch(() => null);

        if (message_id && existMessage) {
            return await _axios.patch(`/channels/${channel_id}/messages/${message_id}`, content).then(r => r.data);
        }else{
            return await _axios.post(`/channels/${channel_id}/messages`, content).then(r => r.data);
        }
    },

    getChannel: async function(channel_id) {
        await updateAxios();

        const response = await _axios.get(`/channels/${channel_id}`);
        return response.data;
    },

    getChannelInGuild: async function (guild_id, channel_id) {
        await updateAxios();

        if (!guild_id){
            throw new Error("guild_id (param1) is missing")
        }

        const response = await _axios.get(`/channels/${channel_id}`);
        if (String(response?.data?.guild_id) === String(guild_id)){
            return true;
        }else{
            return false;
        }

    },

    leaveGuildByID: async function (guild_id){
        await updateAxios();

        const leave = _axios.delete(`/users/@me/guilds/${guild_id}`);
        return leave.data;
    }
}

// Chat GPTECO
function hexToDiscordColor(hex) {
    if (hex.startsWith('#')) {
        hex = hex.slice(1);
    }

    return parseInt(hex, 16);
}