import { databases } from "#utils";
import Decimal from "decimal.js";

const weekdays = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];

export const getTotalSalesByServer = (server_id) => {
    const sales_server = databases.carts.fetch(`servers.${server_id}`) || {};
    const extracts_server = databases.extracts.fetch(`extracts.${server_id}`) || [];

    let balance = new Decimal(0);
    let semiauto = new Decimal(0);
    let auto = new Decimal(0);
    let total = new Decimal(0);
    let soldToday = new Decimal(0);
    let soldThisMonth = new Decimal(0);

    // Obter a data de hoje e os últimos cinco dias da semana
    const today = new Date();
    const lastFiveDays = [];

    for (let i = 0; i < 5; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);

        lastFiveDays.push({
            date: date,
            weekday: weekdays[date.getDay()],
            dayOfMonth: date.getDate(), // Número do dia do mês
            totalSold: new Decimal(0)
        });
    }

    Object.entries(sales_server).forEach(([key, cart]) => {
        const cartDate = new Date(cart.date);

        const paymentApproved = cart?.payment?.status === "approved-by-admin" || cart?.payment?.status === "approved";
        const cartPrice = new Decimal(cart?.payment?.price || 0);

        // Verificar se o carrinho foi criado hoje
        if (cartDate.toDateString() === today.toDateString() && paymentApproved) {
            soldToday = soldToday.plus(cartPrice);
        }

        // Atualizar o total das vendas por status de pagamento
        if (cart?.payment?.status === "approved-by-admin") {
            semiauto = semiauto.plus(cartPrice);
        }

        if (cart?.payment?.status === "approved") {
            auto = auto.plus(cartPrice);
        }

        if (paymentApproved) {
            total = total.plus(cartPrice);
        }

        // Atualizar a quantidade de vendas nos últimos cinco dias
        lastFiveDays.forEach(day => {
            if (cartDate.toDateString() === day.date.toDateString() && paymentApproved) {
                day.totalSold = day.totalSold.plus(cartPrice);
            }
        });

        // Atualizar a quantidade de vendas do mês atual
        if (cartDate.getMonth() === today.getMonth() && cartDate.getFullYear() === today.getFullYear() && paymentApproved) {
            soldThisMonth = soldThisMonth.plus(cartPrice);
        }
    });

    const lastFiveDaysByWeekdaysFormatted = {};
    lastFiveDays.map(day => {
        lastFiveDaysByWeekdaysFormatted[day.weekday] = { totalSold: parseFloat(day.totalSold), dayOfMonth: day.dayOfMonth };
    });

    extracts_server.forEach((extract) => {
        const amount = new Decimal(extract.amount);
        if (extract.action === "add") {
            balance = balance.plus(amount);
        } else if (extract.action === "remove") {
            balance = balance.minus(amount);
        }
    });

    return { 
        auto: parseFloat(auto), 
        semiauto: parseFloat(semiauto), 
        total: parseFloat(total), 
        lastFiveDaysByWeekdays: lastFiveDaysByWeekdaysFormatted, 
        soldToday: parseFloat(soldToday), 
        soldThisMonth: parseFloat(soldThisMonth), 
        balance: parseFloat(balance) 
    };
};


export const getMainTotalSales = () => {
    const main_sales_extracts = databases.extracts.fetch("extracts.main") || [];

    let balance = new Decimal(0);
    let soldToday = new Decimal(0);
    let soldThisMonth = new Decimal(0);

    // Obter a data de hoje e os últimos cinco dias da semana
    const today = new Date();
    const lastFiveDays = [];

    // Inicializando a lista "lastFiveDays" com os ultimos 5 dias da semana;
    for (let i = 0; i < 5; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);

        lastFiveDays.push({
            date: date,
            weekday: weekdays[date.getDay()],
            dayOfMonth: date.getDate(), // Número do dia do mês
            totalSold: new Decimal(0)
        });
    }

    main_sales_extracts.forEach((extract) => {
        const extract_date = new Date(extract.date);
        console.log(extract_date);

        const isToday = (extract_date.toDateString() === today.toDateString());
        const isThisMonth = (extract_date.getMonth() === today.getMonth() && extract_date.getFullYear() === today.getFullYear());

        // Vamos fazer um loop nos ultimos 5 dias, e vamos comparar se o dia do extrato atual (extract.data) bate com um dos ultimos 5 dias, caso sim, vamos adicionar ou remover do saldo do dia.
        lastFiveDays.forEach(day => {
            if (extract_date.toDateString() === day.date.toDateString()) {
                const amount = new Decimal(extract.amount);
                if (extract.action === "add") {
                    day.totalSold = day.totalSold.plus(amount);
                } else if (extract.action === "remove") {
                    day.totalSold = day.totalSold.minus(amount);
                }
            }
        });

        const amount = new Decimal(extract.amount);
        if (extract.action === "add") {
            balance = balance.plus(amount);
            if (isToday) {
                soldToday = soldToday.plus(amount);
            }
            if (isThisMonth) {
                soldThisMonth = soldThisMonth.plus(amount);
            }
        } else if (extract.action === "remove") {
            balance = balance.minus(amount);
            if (isToday) {
                soldToday = soldToday.minus(amount);
            }
            if (isThisMonth) {
                soldThisMonth = soldThisMonth.minus(amount);
            }
        }
    });

    const lastFiveDaysByWeekdaysFormatted = {};
    lastFiveDays.forEach(day => {
        lastFiveDaysByWeekdaysFormatted[day.weekday] = { totalSold: day.totalSold.toFixed(2), dayOfMonth: day.dayOfMonth };
    });

    return {
        balance: parseFloat(balance),
        lastFiveDaysByWeekdays: lastFiveDaysByWeekdaysFormatted,
        soldToday: parseFloat(soldToday),
        soldThisMonth: parseFloat(soldThisMonth)
    };
};
