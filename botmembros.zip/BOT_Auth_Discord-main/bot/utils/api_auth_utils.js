import deploy from "#root/deploy.json" with {type: "json"};
import axios from 'axios';
import dotenv from 'dotenv'; dotenv.config({path: `.env.${process.env.NODE_ENV || 'development'}`});

const application_id = deploy.application_id;
const api_manager_url = process.env.API_AUTH_MANAGER_URL;
const api_manager_token = process.env.API_AUTH_MANAGER_TOKEN;

const _axios = axios.create({
    baseURL: api_manager_url,
    headers: {
        Authorization: api_manager_token
    }
});

const caching = new Map();

export default {
    getAllGiftCards: async function(){
        const response = await _axios.get(`/v1/auth/gift_cards/${application_id}`);
        return response?.data?.data
    },

    addGiftCard: async function(list){
        const response = await _axios.put(`/v1/auth/gift_cards/${application_id}/create`, {gift_cards: list});
        return response.data;
    },

    removeGiftCardByCode: async function (gift_code){
        const response = await _axios.delete(`/v1/auth/gift_cards/${application_id}/code/${gift_code}`);
        return response.data;
    },

    removeGiftCardInMassByGroup: async function (group){
        const response = await _axios.delete(`/v1/auth/gift_cards/${application_id}/group/${group}`);
        return response.data;
    },

    removeAllGiftCard: async function (){
        const response = await _axios.delete(`/v1/auth/gift_cards/${application_id}/clear/all`);
        return response.data;
    },

    getApplicationConfig: async function() {
        const response = await _axios.get(`/v1/auth/applications/${application_id}`);
        return response?.data?.data;
    },

    updateApplicationConfig: async function(object_to_update) {
        const response = await _axios.post(`/v1/auth/update/${application_id}`, {changes: object_to_update});
        return response.data;
    },

    getAllServers: async function() {
        const response = await _axios.get(`/v1/auth/${application_id}/servers`);
        return response.data;
    },

    getServer: async function(server_id, attributes_array, verifiedUsers = false) {
        const attributes_query = attributes_array ? attributes_array.join(',') : [];
        const response = await _axios.get(`/v1/auth/server/${server_id}?attributes=${attributes_query}&verifiedUsers=${verifiedUsers}`);

        return response.data;
    },

    updateServer: async function(server_id, object_to_update) {
        if (!server_id) throw new Error("Server ID missing");
        if (!object_to_update) throw new Error("Object to update missing");

        const response = await _axios.post(`/v1/auth/server/${server_id}/${application_id}/update`, {changes: object_to_update});
        return response.data;
    },

    deleteServer: async function(server_id){
        await _axios.delete(`/v1/auth/applications/servers/${application_id}/${server_id}`)
    },

    deleteUsers: async function(whereConditions){
        if (!whereConditions) throw new Error("Faltou a condição para deletar usuarios autenticados.")

        await _axios.delete(`/v1/auth/applications/${application_id}/verified_users`, {
            data: {
                where: whereConditions,
            }
        })

        return true;
    },

    getVerifiedUsers: async function(server_id) {

        const cache = getExistentValueInCache(`verified_users`)
        if (cache) return cache;

        const response = await _axios.get(`/v1/auth/verified_users/${application_id}/${server_id || ""}`);
        caching.set(`verified_users`, { value: response.data, createdAt: new Date() });

        return response.data;
    },

    getQueuePulls: async function(queryParams = {}) {
        /* 
            Só vamos usar o cache quando não estivermos usando o "queryParams", pois não queremos usar o cache
            com dados filtrados, apenas para a query completa. isso trará uma complexidade menor pro código
        */
        const useCache = Object.entries(queryParams).length === 0

        if (useCache){
            const cache = getExistentValueInCache(`queue_pulls`, 5);
            if (cache) return cache;
        }

        const paramsToQuery = new URLSearchParams(queryParams);
        const response = await _axios.get(`/v1/auth/queue_pulls/${application_id}/?${paramsToQuery.toString()}`);

        if (useCache){
            caching.set(`queue_pulls`, { value: response.data, createdAt: new Date() });
        }
        return response.data;
    },

    createQueuePull: async function(object_to_create) {
        const response = await _axios.put(`/v1/auth/queue_pulls/${application_id}/create`, object_to_create);
        return response.data;
    },

    updateQueuePull: async function(queue_id, object_to_update) {
        const response = await _axios.post(`/v1/auth/queue_pulls/${queue_id}/update`, {changes: object_to_update});
        return response.data;
    }
}

function getExistentValueInCache(key, validTimeSeconds = 60) { 
    const cache = caching.has(key) ? caching.get(key) : null;
    if (!cache || !cache.createdAt) {
        return null;
    }

    if (cache.createdAt.getTime() + (validTimeSeconds * 1000) > Date.now()) {
        return cache.value;
    } else {
        return null;
    }
}
