import {JsonDatabase} from "wio.db";

export default {
    servers_embed: new JsonDatabase({ databasePath:"./databases/servers_embed.json"}),
    sales_config: new JsonDatabase({ databasePath:"./databases/sales_config.json" }),
    config: new JsonDatabase({ databasePath:"./databases/config.json"}),
    carts: new JsonDatabase({ databasePath: "./databases/carts.json"}),
    users_queue: new JsonDatabase({ databasePath: "./databases/users_queue.json"}),
    extracts: new JsonDatabase({ databasePath:"./databases/extracts.json" }),
}