
import { EaseClient } from "ease-discord-js";
import { GatewayIntentBits } from "discord.js"
import { databases, getSaleEmbed, api_auth_utils } from "#utils";
import deploy from "./deploy.json" with { type: "json" };

export const easeClient = new EaseClient(deploy.token);

easeClient.set("commandsPath", "./bot/commands");
easeClient.set("componentsPath", "./bot/components");
easeClient.set("intents", [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildPresences]);
easeClient.setDefault("button", {style: "Primary"})

easeClient.login();

easeClient.client.on('ready', async (client) => {
    console.log(`Logged in as ${client.user.tag}!`);
    initialize(client);
});

easeClient.client.on("guildCreate", async (guild) => {

    const slashsArray = [];
    for (const [key, value] of (easeClient.commands).entries()) {
        slashsArray.push(value)
    }   

    guild?.commands?.set(slashsArray)
})

const initialize = async (client) => {
    const fetch_rich_presence = await databases.config.fetch("rich_presence");

    if (fetch_rich_presence){
        client.user.setActivity(fetch_rich_presence, { type: 3 });
    }

    await updateSalesEmbeds(client);
    deleteInactiveCarts(client);

    setInterval( () => {
        updateSalesEmbeds(client);
    }, 120 * 1000) // Atualizando as embeds a cada 2 minutos! (120 segundos);

    setInterval(() => {
        deleteInactiveCarts(client);
    }, 30*1000) // 30 seconds
}

async function updateSalesEmbeds(client){
    const servers = databases.sales_config.fetch(`servers`);
    
    if (servers){
        const verified_users = await api_auth_utils.getVerifiedUsers()
        if (!verified_users) return console.log(`❌ | Erro ao buscar usuarios verificados da API.`)

        Object.keys(servers).forEach(async server_id => {
            const server_info = servers[server_id];
    
            const embed_settings = server_info.embed_settings
            if (embed_settings.channel_id && embed_settings.message_id){
    
                const guild = client.guilds.cache.get(server_id);
                if (!guild) return;
    
                const channel = await guild.channels.fetch(embed_settings.channel_id);
                if (!channel) return;
    
                const message = await channel.messages.fetch(embed_settings.message_id).catch( e => null);
                if (!message) return;
    
                const embed = await getSaleEmbed(client, verified_users, server_id);
                if (!embed) return;
    
                message.edit({embeds: [embed]})
            }
        });
    }
}

function deleteInactiveCarts(client) {
    const deleteTimestampDatabase = databases.carts.fetch("delete_timestamp");

    if (deleteTimestampDatabase){

        Object.keys(deleteTimestampDatabase).forEach( guild_id => {
            const guild = client.guilds.cache.get(guild_id);

            if (guild){
                const channels = deleteTimestampDatabase[guild_id];

                Object.keys(channels).forEach( channel_id => {

                    const timestamp = channels[channel_id];
                    const currentTime = new Date();

                    if ( currentTime.getTime() > timestamp){

                        const channel = guild.channels.cache.get(channel_id);
                        if (channel){
                            channel.delete().catch(e => null)
                        }

                        databases.carts.delete(`delete_timestamp.${guild_id}.${channel_id}`);
                        databases.carts.delete(`servers.${guild_id}.${channel_id}`)
                        
                        console.log(`Delete Channel By Inactivity: ${channel_id}`)
                    }
                } )
                
            }
        })
    }        
}

process.on('unhandledRejection', (error) => {
    console.log('Unhandled promise rejection:', error);
});

process.on('uncaughtException', (error) => {
    console.log('Uncaught exception:', error);
});